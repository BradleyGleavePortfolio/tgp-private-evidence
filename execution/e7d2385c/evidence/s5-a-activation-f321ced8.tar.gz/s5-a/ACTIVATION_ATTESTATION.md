# S5 reviewer A — same-review activation applicability

**Verdict: GRANTABLE for one real fresh51 `full` execution on the exact hooked head. The previously missing runner/PG prerequisite is CLOSED. No A/B finding; no new controls, installation, harness change or source review is required. This is NOT a test result or final acceptance.** ([independent current bindings](activation-evidence/independent-bindings.txt), [original source judgment](REPORT.md), [frozen activation](activation-inputs/readiness/ACTIVATION_AND_EXPECTED_ACCEPTANCE.md))

Independent nonbuilder A, individual/cumulative T4, parent-model inheritance without asserted runtime ID. Read-only Git/hash/file inspection; no proof stage, candidate tooling, binary execution, DB connection, install or process census by this reviewer.

## Exact binding and prerequisite closure

- New prerequisite manifest `080b9574a6d4cda950d16baa3f4b19c5672086c2303643b18cb6cd3201024b11`: **42/42 entries independently verified**. ([verification](activation-evidence/preparation-manifest-check.txt))
- Source remains clean `98d39610f511505558373f3a59fa019804c94bd7`, tree `67fc1db5f353f0d363fe7134a78d455c0decfb55`, parent `143d451ead6ccdbebd92ca3031ba7a89867d6cfc`; spec, bootstrap and installed-lock hashes match the already-reviewed actual hooked source. ([independent current bindings](activation-evidence/independent-bindings.txt))
- Materialized `/home/user/workspace/execution/s5-r4/{run-proof.sh,s5-fixture.sh,launch-full.sh}` compare byte-for-byte to this review's archived copies: runner `19ab936a1562061caf4f8ee8426a5e18a998b22f3d33093a45a02b64ee3fc2c5`, fixture `3a7d57bf951ab27e2161dc91db1d816f31d4af079ede076e7a2dfd1c44f3a721`, launcher `a03836d524bafc28572b1e600f34148d8e9ddea38391ffc427c26f5399b9f728`; no path derivation or semantic change needs review. ([comparison and hashes](activation-evidence/independent-bindings.txt))
- Actual PostgreSQL `postgres` hash `23cd174849b273064c47d581b55be596be2f5cf0ee5d3e76c0146e2464bf873a` and `initdb` hash `b7db9bc2463a4ffbe1e405977512afb50c9846fd3af2b694e315e6d5a270882a` match the named prior S1/S2 substrate records and current provenance; setup-10 and setup-20 raw statuses are both zero. ([actual hashes](activation-evidence/independent-bindings.txt), [S1 provenance](activation-inputs/PG17-S1-PROVENANCE.txt), [S2 provenance](activation-inputs/PG17-S2-PROVENANCE.txt), [current provenance](activation-inputs/PG17-CURRENT-PROVENANCE.txt), [client setup](activation-inputs/logs/setup-10.stdout), [server setup](activation-inputs/logs/setup-20.stdout))
- The recorded client is PostgreSQL 18.6 via the default `/usr/bin/psql` wrapper, not a substituted PG18 server; the runner and bootstrap enforce actual server version 170006, marker, directory and role facts before mutation. ([client setup](activation-inputs/logs/setup-10.stdout), [runner preflight](inputs/runner/run-proof.sh), [bootstrap](inputs/source/test/utils/g2-pg17-bootstrap.sh))
- The preparation readiness/release records report fresh data-directory absence, no quarantine/listener/server, source cleanliness and ended setup ownership; I reuse those attributable observations instead of duplicating a census. ([readiness](activation-inputs/readiness/READINESS.txt), [release](activation-inputs/RUNTIME_RELEASE.txt))

The original source-phase seal `be4cc1089c710df91254f1dcefe1e3bec0a56db5f8840915e4cf9a3096613044` remains unchanged; this is an additive applicability attestation, not a restarted audit. ([original manifest](MANIFEST.sha256), [observed seal](activation-evidence/independent-bindings.txt))

## Exact execution unlocked

Under the parent's sole runtime ownership, activate **once**, with ordinary noninteractive Bash/job control off, using the prepared command:

```sh
G2_PG17_PASSWORD=s5_local_synthetic STAGE=full bash /home/user/workspace/execution/s5-r4/launch-full.sh
```

This is the fixture's public synthetic password, not a real credential; the command selects the previously reviewed fresh init → bootstrap → actual 51-case live spec → stop path with existing inner/outer bounds. ([frozen activation](activation-inputs/readiness/ACTIVATION_AND_EXPECTED_ACCEPTANCE.md), [fixture literal](inputs/runner/s5-fixture.sh), [runner](inputs/runner/run-proof.sh))

No `npm-ci.sh`, new baseline controls, separate hook reruns, retries, `resume`, reset or destruction is unlocked by this reviewer attestation. Ordinary parent authority still governs execution and any later destructive cleanup.

## C — qualify and proceed

1. **Observed HEAD rather than baked-in HEAD guard:** the runner stamps its actual source/tree/dirty/dependency identity, and this exact activation binds an independently verified, exclusively owned clean candidate. Accept only the expected stamp and unchanged post-run source; a mismatched stamp is inapplicable evidence, not a pass. No arbitrary runner pinning change is necessary for this one execution. ([stamp implementation](inputs/runner/run-proof.sh), [actual bindings](activation-evidence/independent-bindings.txt), [frozen acceptance](activation-inputs/readiness/ACTIVATION_AND_EXPECTED_ACCEPTANCE.md))
2. **Readiness prose overstates npm-root equality:** section 4.3 says “npm-root facts before == after,” but `full` intentionally creates its previously absent O checkout, package manifests and shared node_modules symlink. Treat those declared `$S/old-root-925780e0` changes as expected; the real requirement is no unintended npm install/manifest drift in other roots, with O matching its pinned checkout/shared-dependency rules. This is a qualification of recorded acceptance prose, not a new test or harness edit. ([activation section 4.3](activation-inputs/readiness/ACTIVATION_AND_EXPECTED_ACCEPTANCE.md), [runner stamp/oldroot/after facts](inputs/runner/run-proof.sh), [old-root helper](inputs/source/test/utils/g2-pg17-old-root.sh), [bootstrap dependency sharing](inputs/source/test/utils/g2-pg17-bootstrap.sh))
3. Prior C qualifications—including the unexpected-fork fallback and timeout-origin label—remain bounded to their documented claims and do not create another execution cycle. ([source-phase findings](FINDINGS.md))

## Evidence still required

The real proof has **not** run in this evidence packet: no fresh51 success, full bootstrap success, clean proof stop, or product acceptance is claimed. ([preparation boundary](activation-inputs/RECEIPT.md))

Append one actual-result attestation here after reading the selected suite's **51 passed / 51 total, no skip**, raw child statuses, `FIRST_RC/PROOF_EXIT`, stop/liveness/quarantine state, launcher sentinel and exact post-run source/dependency identity; preserve any nonzero/timeout/unknown result without relabeling or replay. The run buys the real PG17.6 foundation decision, not importer/customer release acceptance.
