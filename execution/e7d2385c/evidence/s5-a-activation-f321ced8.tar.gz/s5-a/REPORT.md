# S5 independent A — exact hooked source and fresh51 runner

**Source phase: CLOSED, no new A/B finding. One real fresh51 is source-grantable; activation still needs the named runner/PG prerequisite packet. NOT final acceptance.** The inspected candidate is the actual two-file commit, not a builder's proposed tree; the archived runner reaches the real live spec rather than substituting a control. ([independent identities](evidence/independent-identities.txt), [source diff](evidence/actual-head-parent.patch), [runner lines 411–463](inputs/runner/run-proof.sh))

Reviewer A; independent nonbuilder; individual/cumulative T4; parent-model inheritance, actual runtime model identity not asserted. Static review only: no candidate execution, installation, test, hook, DB connection, process census, correction, or candidate/private/peer mutation. S6 packet `0266ff53` remains untouched. This review does not replace the independent B review.

## Exact reviewed inputs

Private intake: `cc62002bfd08c3cb677025b651965d36e6a1aaec`; continuation manifest `4007b242146cd6a547ae31306dd3c02cda3200c9dda65574bef8c39822095371`, independently checked **136/136** entries. ([frozen receipt](inputs/continuation/RECEIPT.md), [manifest verification](evidence/continuation-manifest-check.txt))

| Binding | Exact value |
|---|---|
| Actual HEAD | `98d39610f511505558373f3a59fa019804c94bd7` |
| Actual tree | `67fc1db5f353f0d363fe7134a78d455c0decfb55` |
| Parent | `143d451ead6ccdbebd92ca3031ba7a89867d6cfc` |
| Full parent diff SHA-256, core.abbrev=8 | `9f37223b889b31580ba8024b14d86ac3d0fb9feab08ef4b250292d50a735921d` |
| `test/rls-g2-pg17-etq0.spec.ts` SHA-256 | `2b7d1969f64ca837caa075e5bec91174242355804db8d37daa672cc240568e7f` |
| `test/utils/g2-pg17-bootstrap.sh` SHA-256 | `d3348db89674450e976f0c7784403822fd86435b9aafb4ff4f25fdcb45bb5340` |
| Archived `run-proof.sh` SHA-256 | `19ab936a1562061caf4f8ee8426a5e18a998b22f3d33093a45a02b64ee3fc2c5` |
| Archived `s5-fixture.sh` SHA-256 | `3a7d57bf951ab27e2161dc91db1d816f31d4af079ede076e7a2dfd1c44f3a721` |
| Archived `launch-full.sh` SHA-256 | `a03836d524bafc28572b1e600f34148d8e9ddea38391ffc427c26f5399b9f728` |

These values come from independent read-only Git/hash observations; the worktree had no tracked or untracked delta and the changed set was exactly the two named files. ([independent identities](evidence/independent-identities.txt))

## Source judgment

- **Teardown authority is correctly placed.** Final spec lines 65–171 keep authorization false through all SELECT/file/Git identity, ownership, marker, history, O-source and role gates, set it at line 141 before the first GRANT at 144, and return from `afterAll` before SQL when authorization was not reached; an authorized partial setup still enters the unchanged cleanup body. ([complete final spec](inputs/source/test/rls-g2-pg17-etq0.spec.ts), [baseline](inputs/baseline/test/rls-g2-pg17-etq0.spec.ts), [original correction](inputs/s5-r4-dirty-from-143d451e.patch))
- **The lifecycle claim matches installed Jest, not merely comments:** its beforeAll failure is attached to descendant tests while afterAll still runs for a non-skipped describe, making the explicit gate necessary and sufficient for the reviewed refused-setup cleanup boundary. ([pinned Jest implementation, lines 158–180, 792–810, 889–903](inputs/dependencies/jestAdapterInit.js))
- **Bootstrap provenance now fails on missing inputs and identifies the actual runtimes:** lines 162–172 use required hash assignments under `set -euo pipefail`; lines 186–210 enforce both generated engines and the candidate runtime's pinned resolution, while the O runtime is the copied custom-output runtime. ([complete bootstrap](inputs/source/test/utils/g2-pg17-bootstrap.sh), [actual generated candidate import](inputs/dependencies/generated-candidate-index.js), [pinned generator, lines 13415–13425, 13564–13576, 13639–13672](inputs/dependencies/prisma-client-generator.js))
- **Five aliases are semantic-neutral:** the literal declaration remains; `source_platform` and `updated_at` property keys are still excluded from the same rest objects; no assertion/expression/control-flow/config/cast change accompanies them, and the last formatter delta is one reflow. ([binding-only diff](inputs/continuation/preimage/binding-only-vs-index-756a.patch), [formatter-only diff](inputs/continuation/preimage/formatter-only-delta.patch))

I read the complete final spec and bootstrap, the relevant parent source, the imported harness/target/old-root integration, actual hook output and pinned dependency implementation; I did not reopen unchanged accepted S1–S4 behavior.

## Actual hooked-head evidence

The actual commit object has Bradley Gleave as both author and committer; the frozen message/no-trailer checks and parent/tree/diff checks passed, and the real 07R log shows configured pre-commit R75, pinned Prettier, max-warnings-zero ESLint and `tsc --noEmit`, followed by commit-msg and commit `98d39610`; caller 07R/08/09/10 statuses were zero. ([actual identities](evidence/independent-identities.txt), [07R raw log](inputs/continuation/logs/07R-identity-and-hooked-commit.log), [08 raw log](inputs/continuation/logs/08-post-commit-identity.log), [caller receipt](inputs/continuation/caller-phase2.receipt))

The production-readiness hook was an absent-script **no-op**, not production evidence; the two real R75 range checks passed, and earlier failing packets are not converted into successes. ([07R raw log](inputs/continuation/logs/07R-identity-and-hooked-commit.log), [range log](inputs/continuation/logs/10-check-r75-range.log), [frozen receipt](inputs/continuation/RECEIPT.md))

Independent current hashes agree with the frozen lock, installed lock, Prisma CLI, both engine copies and pinned formatter; the generator runtime source also explains its copied preamble rather than requiring a speculative compatibility fix. ([hash observations](evidence/independent-identities.txt), [pinned generator](inputs/dependencies/prisma-client-generator.js))

## One real fresh51: grantability and remaining prerequisite

The archived `full` path is appropriate to the requested decision: fresh init only, one canonical lock, independent O checkout, marked loopback PG17.6 identity plus zero-session preflight, real bootstrap with 164 prior migrations, then the actual live spec via `jest.rls.config.js --runInBand --testTimeout=180000`, followed by stop and distinct first/cleanup/outer status records. ([runner](inputs/runner/run-proof.sh), [fixture](inputs/runner/s5-fixture.sh), [launcher](inputs/runner/launch-full.sh), [old-root helper](inputs/source/test/utils/g2-pg17-old-root.sh), [live configuration](inputs/source/jest.rls.config.js))

The spec statically registers 51 cases (22 single cases plus 29 parameterized cases); that is intended selection, **not a reported execution result**. Its real migration/writer/reader/rollback assertions remain the intended proof, with simulated operator drain explicitly not proof of a real deployment drain. ([complete spec](inputs/source/test/rls-g2-pg17-etq0.spec.ts))

**Activation prerequisite, not a new product finding:** at source-phase cutoff only the archived scripts were published, not a final runnable command/derivation and recovered PG17.6/psql provenance. The archive still names `execution/s5-r4`, the old `execution/test-validation.lock`, `/home/user/pg17` and default `/usr/bin/psql`; the source-only grant must not be mistaken for authority to execute those historical paths. ([archived runner lines 44–73, 95](inputs/runner/run-proof.sh), [launcher lines 15–17](inputs/runner/launch-full.sh), [restoration boundary](inputs/continuation/RECEIPT.md))

Minimum next action: publish the already-assigned exact runner/fixture/launcher placement or literal path-only derivation, one actual `full` command and the recovered binary/client provenance; bind that activation to unchanged head/tree/dependency pins and the sole current runtime owner. Verify only that changed applicability in an additive attestation to **this** review, then run the one real fresh51; do not add controls, repeat hooks/setup, or re-audit accepted source.

**Missing evidence:** no fresh real PG17.6 `full` result on `98d39610` is in this review; no 51/51 pass, full bootstrap/runtime provenance, clean real stop, or final acceptance is claimed. ([continuation boundary](inputs/continuation/RECEIPT.md))

Final same-review attestation must read the actual selected test counts/assertion outcomes, raw first exit, cleanup and launcher records, final candidate/dependency identity and runtime release; any timeout, skip, partial run, failed stop or unknown result stays explicit rather than inheriting an old resume pass.
