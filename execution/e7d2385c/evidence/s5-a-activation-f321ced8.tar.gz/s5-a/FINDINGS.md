# S5 independent A — source-phase findings

**A: none newly found. B: none newly found. Source + actual hooked-head closure: YES. One fresh51: source-grantable, with published exact activation/substrate applicability still pending. Final acceptance: NO, runtime evidence missing.** ([review report](REPORT.md), [independent identities](evidence/independent-identities.txt), [archived full path](inputs/runner/run-proof.sh))

## C — record, qualify, continue only

### S5-A-C01 — authentic hook evidence has a narrow boundary

`prod-readiness-quick` did not validate production; it returned zero for an absent optional script, while the substantive formatting/lint/type/R75/message hooks actually executed against the committed two-file tree. Do not promote the hook log into release or fresh51 evidence; no rerun or repair follows from this qualification. ([07R raw log](inputs/continuation/logs/07R-identity-and-hooked-commit.log), [hook configuration](inputs/source/lefthook.yml))

### S5-A-C02 — recovery/editor/network hygiene is not a new source defect

The restoration used a fresh fetch of the same baseline rather than the old local clone, an engine download with the same pinned resulting hash, and the platform's visible exact-string edit operation rather than the named patch tool; the preserved five-line diff and independently verified final source/engine identities support continuing, not reopening source/setup. ([frozen receipt](inputs/continuation/RECEIPT.md), [binding diff](inputs/continuation/preimage/binding-only-vs-index-756a.patch), [independent hashes](evidence/independent-identities.txt))

### S5-A-C03 — O-runtime prefix check is not an arbitrary-code authenticity check

Bootstrap lines 189–197 compare the O runtime's suffix to the complete pinned runtime but do not separately restrict the prefix to the comment preamble; the pinned generator actually prepends that preamble during the immediately preceding local generation, so the reviewed controlled fixture has no demonstrated invalid proof path from this wider predicate. Qualify the check accordingly; no new control or fix is required for fresh51. ([bootstrap](inputs/source/test/utils/g2-pg17-bootstrap.sh), [generator lines 13105–13121 and 13639–13672](inputs/dependencies/prisma-client-generator.js))

### S5-A-C04 — runner fallback does not support a broader supervision claim

Archived `run-proof.sh:208` replaces its positional arguments with `/proc` fields, then compares the PPID field to the state field rather than the original requested parent; its unexpected-fork fallback at 250–253 therefore must not be claimed as proven descendant cleanup. The exact fresh path uses noninteractive Bash without job control and expects in-process `setsid` at 243–249; no reachable fork-fallback failure on that intended invocation was established, so this is a bounded qualification, not a demand for another supervisor/control/fixer cycle. ([archived runner](inputs/runner/run-proof.sh), [archived launcher](inputs/runner/launch-full.sh))

### S5-A-C05 — a timeout remains failure, not proof of its precise origin

Launcher lines 25–29 label both propagated inner rc124 and outer-timeout rc124 as `OUTER_BOUND_HIT`; it still quarantines and records nonzero rather than masking a pass. Use the runner's deadline/first-exit records to distinguish origin; this imprecise label does not block the intended fresh proof. ([launcher](inputs/runner/launch-full.sh), [runner lines 258–267 and 288–306](inputs/runner/run-proof.sh))

## Pending, not a finding

The archived source pins are frozen, but the current runnable path/command and PG17.6/client recovery packet were not yet published at source-phase cutoff; the existing receipt explicitly disclaims fresh51, so activation applicability and the actual real result remain separate next evidence. ([report](REPORT.md), [continuation receipt](inputs/continuation/RECEIPT.md))

Do not create a new audit lane for that evidence: append applicability and later actual-result attestation here; preserve this source verdict and existing accepted evidence.
