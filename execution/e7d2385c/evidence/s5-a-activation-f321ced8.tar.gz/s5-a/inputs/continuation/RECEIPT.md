# S5 exact candidate continuation — receipt (EXEC-e7d2385c): exact recovery, fresh minimum setup, five binding aliases, genuine hooked commit 98d39610

Builder/executor (not an auditor) under parent EXEC-e7d2385c; intake private `cc62002bfd08c3cb677025b651965d36e6a1aaec`. Tier T4 individual/cumulative; requested Claude Fable 5 / High (runtime identity not observable, not asserted). Executed 2026-09-23T19:40Z–19:55Z in a fresh sandbox (no inherited worktrees/installs). One activation per step; no retry, reset, amend, bypass, hook/config weakening, or repair. No remote push, no real PostgreSQL proof, no T0/baseline/private controls rerun. Nothing under `repos/tgp-private-evidence`, peer paths or old packets was written; the private checkout is a blob:none clone and was only used to locate paths — every private byte was retrieved by `gh api … contents/<exact path>?ref=cc62002b` (no branch inventory or history sweep).

Sole writes: `worktrees/s5-r4/**`, `execution/e7d2385c/s5-continuation/**` (this root: `retrieved/`, `recovery/`, `logs/`, `tooling/`, `steps/`, `candidate/`, `test-validation.lock{,.holders}`), plus ordinary platform side effects (`~/.npm` cache and `_logs`, `~/.cache/prisma` engine cache).

## A. Source recovery (exact, from named archived bytes) — `recovery/`, `logs/R1…`, `logs/R2…`

| Fact | Value | Archived pin | Match |
|---|---|---|---|
| Bundle `2026-09-21/remediation/s5-r3/b3-pinned-resume/checkpoint-5-B3/s5-r3-candidate.bundle` | sha256 `e42aa021…bf48`, `git bundle verify` okay, requires c23b9d9f | SHA256SUMS / restore S1 | ✔ |
| Baseline object database | depth-1 fetch of public `growth-project-backend` commit `c23b9d9f` (only substitution vs archived S1, which byte-copied an already-present `source/backend/.git`); remote removed → 0 remotes; `refs/heads/main`=c23b9d9f | restore S1 | ✔ layout identical |
| HEAD | **`143d451ead6ccdbebd92ca3031ba7a89867d6cfc`** detached; clean tree `d0e122d3…2c6b`; parent b94c2488; 32 commits c23b..HEAD; 2114 tracked = 2114 files; fsck ok | S1 | ✔ |
| Lock blob / sha256 | `354de3da…` / `b7fed5ed…9c55` | S1 | ✔ |
| Clean fingerprint | `01ba4719…546b` | S1 | ✔ |
| Frozen patch `2026-09-22/remediation/s5-r4/checkpoint-1/s5-r4-dirty-from-143d451e.patch` | sha256 `c36258b3…5491`; applied to worktree; post-image blobs spec `ff5a38b8` (sha256 `01f3cfc0` = archived staged preimage), bootstrap `100755 85a636ba`; status pin `' M'`×2 | S2 | ✔ |
| `core.abbrev=8` (archived decision (a)) | `.git/config` sha256 `6ae9e03f…9254`; `git diff HEAD` == patch bytes; dirty fingerprint **`6850b32e…6aa0`** = `PIN_DIRTY_FINGERPRINT` | S3 | ✔ |
| Original prep staged tree (verified via temporary index only) | `3d30aeb0…7871` | prep e9f4a5d5 | ✔ |
| Archived 06F formatting-only delta `s5-hooked-candidate-continuation/preimage/formatting-only-vs-index-3d30.patch` | sha256 `c43b4d1b…d21d`; applied to spec → sha256 **`338defe8…6430`**, blob `2cc0a3dc` | continuation 9d47c0dc | ✔ |
| **Recovered staged tree** (both files `git add`) | **`756a0d7966c9125749339abbcfd681eb7e713ede`**; full parent diff sha256 **`2c92a964…46df`** byte-identical to archived `preimage/new-two-file-parent.patch`; numstat 971/356 + 34/4; worktree == index | continuation 9d47c0dc | ✔ |

No formatter, install or product authorship was used for recovery; the staged tree was rebuilt purely from archived patch bytes and verified against the archived tree/diff hashes. Retrieved-file integrity: prep `MANIFEST.sha256` (e9f4a5d5) OK for all 21 retrieved prep files; continuation manifest file hash `9d47c0dc…` matches.

## B. Fresh-sandbox minimum setup (new environment, not a repeat acceptance test) — `steps/F*`, `steps/0[234]*`, `candidate/logs/`, `candidate/caller-phaseF.receipt`

Runner: continuation `step.sh` (ea6e8b33) with ONLY workspace substitutions (`steps/step.sh.diff-vs-continuation`): O/P/TOOL/LOCK roots → this root (old canonical lock path is outside this builder's write scope and absent here), holder label slot-H2 → slot-H3. Post-condition files for 02/03/04 differ from the frozen originals only in the recovered-state pins (tree d0e122d3→756a0d79, status `' M'`→`'M '`, fingerprint 6850b32e→66ba4d8f; `*.post.diff-vs-original`). Command files 02/03/04 are byte-identical originals. Detached caller `caller-phaseF.sh`, actual waited exits:

| step | command (exact) | raw | postchecks | result |
|---|---|---|---|---|
| F0 tooling (bound 300) | `npm ci --ignore-scripts --no-audit --no-fund` in `tooling/prettier-3.9.6` from the archived manifests (package.json `6c39ea3d`, lock `3e2189ff`) — one registry read | 0 | original 01-tool-reverify.post: **CLI sha256 `6e922134…906e`**, 3.9.6, entries `.bin .package-lock.json prettier` | 0 |
| F1 npm ci (bound 1200) | `npm ci --no-audit --no-fund --ignore-scripts --loglevel=error` (exact canonical-setup command) | 0, `added 1117 packages in 5m` | **`node_modules/.package-lock.json` sha256 `05bc530a…7b44`**, 651 entries / 463,269,112 bytes (identical to canonical setup), 7 strict pins OK (jest 30.4.2, ts-jest 29.4.9, typescript 5.9.3, @prisma/client 6.19.3, prisma 6.19.3, lefthook 2.1.9, eslint 10.5.0), prettier absent from app graph, hooks 0, client absent, tree/status/lock unchanged | 0 |
| 02 prisma generate (bound 300) | original | 0, `Generated Prisma Client (v6.19.3)`; engine cache was empty → **engine fetched from binaries.prisma.sh (disclosed network event)** | engine sha256 **`a2924eab…a7d8`** (= pinned), client engine equal, ledger model has `source_platform`, tree/status/fingerprint unchanged | 0 |
| 03 lefthook install (bound 60, offline) | original | 0, `sync hooks: ✔️(pre-commit, commit-msg)` | real hooks present naming lefthook, `core.hooksPath` unset, no local overrides | 0 |
| 04 link formatter (bound 10, offline) | original | 0 | `node_modules/.bin/prettier` → pinned CLI | 0 |

Prisma CLI sha256 `c2a77456…e1a0` (= grant pin). node v20.20.1 / npm 10.8.2 / git 2.53.0 identical to the prior environment.

## C. Candidate: five binding aliases + pinned format + genuine hooked commit — `candidate/`

### C1. Preimage and the five edits (grant §Concrete defect and minimum correction)
- B0 preserved the exact recovered staged spec `preimage/rls-g2-pg17-etq0.spec.ts.staged-338defe8` and parent diff `preimage/recovered-two-file-parent-2c92a964.patch`.
- Five edits applied by visible manual patch (edit tool, exact-string replacement; 5 replacements): `const families = [...]` → `const _families = [...]` (L176); `const { source_platform, ...rest } = r;` → `const { source_platform: _source_platform, ...rest } = r;` (L253, L452, L1269); `({ updated_at, ...rest }: any) => rest` → `({ updated_at: _updated_at, ...rest }: any) => rest` (L307). No property-key, omission, expression, assertion, control-flow, cast, config, hook or suppression change; existing `varsIgnorePattern: '^_'` policy used, not changed.
- B1 proof (`candidate/logs/B1…`): **binding-only diff** `preimage/binding-only-vs-index-756a.patch` sha256 `ed1e596c…853a`, numstat **5/5**, single path; each of the five removed/added line pairs matched exactly; reversing only the three alias insertions reproduces sha256 `338defe8` byte-for-byte; no other `_families/_source_platform/_updated_at` uses; bootstrap untouched. Pre-format edited spec sha256 `0f624f2c…453e`.

### C2. 06L — pinned Prettier 3.9.6 once (bound 60, offline) — `candidate/logs/06L-format-spec.log`
`node "$TOOL/node_modules/prettier/bin/prettier.cjs" --write test/rls-g2-pg17-etq0.spec.ts` raw **0** (479 ms); `--check` raw **0** (`All matched files use Prettier code style!`). **Formatter-only delta** `preimage/formatter-only-delta.patch` sha256 `6ea68be8…7180`: exactly one reflow — the L307 `pages.map((p) => ({ ...p, persons: … }))` line (now >100 cols) split over four lines; no token change. Combined vs index 756a: numstat 8/5, single path. Whitespace-insensitive counts after formatting: `_families` literal 1, `source_platform: _source_platform, ...rest` 3, `updated_at: _updated_at, ...rest` 1, unaliased originals 0. Staged only the spec:
- **NEW_TREE `67fc1db5f353f0d363fe7134a78d455c0decfb55`**, spec blob `100644 b3af897e…cdc9`, spec sha256 **`2b7d1969…8e7f`**, full parent diff **`9f37223b…921d`** (`preimage/new-two-file-parent.patch`), numstat **975/357** spec + **34/4** bootstrap (unchanged `100755 85a636ba`), two paths, worktree == index, HEAD unchanged, lock unchanged.

### C3. 07R/08/09/10 — frozen before 07R (`steps/FROZEN_BEFORE_07R.sha256`, `steps/SUBSTITUTIONS.md`, `*.diff-vs-continuation`)
Substitutions only: 07R tree guard 756a0d79→67fc1db5 (1 line); 08 `%T`/tree-identical 756a0d79→67fc1db5, parent-diff sha 2c92a964→9f37223b (+label), spec numstat 971/356→975/357. 09/10 are the original prep files byte-for-byte (d5a0f8e0, eb072c6c). Message file: frozen prep `07-commit-message.txt` sha256 `1da44908…645b`, unchanged. Detached caller `caller-phase2.sh`, actual waited exits:

| step | raw | what actually ran | result |
|---|---|---|---|
| **07R identity-and-hooked-commit** (bound 1200, offline) | **0** | `git config --local user.name/email` (Bradley) → `git var` author = committer `Bradley Gleave <bradley@bradleytgpcoaching.com>`; tree guard 67fc1db5 passed; message-hash guard passed; `LEFTHOOK_VERBOSE=1 git commit -F -` with real hooks `commit-msg pre-commit`, `LEFTHOOK`/`LEFTHOOK_EXCLUDE` unset | **`[detached HEAD 98d39610] … 2 files changed, 1009 insertions(+), 361 deletions(-)`** |
| 08 post-commit-identity (bound 30) | 0 | all postchecks rc 0 (below) | 0 |
| 09 bundle (bound 60) | 0 | `git bundle create c23b9d9f..HEAD`, verify okay | 0 |
| 10 check-r75-range (bound 60) | 0 | range 143d..HEAD exit 0 (`OK — no positive token change`); range c23b..HEAD exit 0 (`as any: +2 -2 net 0`) | 0 |

**Genuine hook output (lefthook 2.1.9, `candidate/logs/07R-identity-and-hooked-commit.log`)** — pre-commit, staged files = the two paths, `summary: (done in 48.70 seconds)`:
- ✔️ `prod-readiness-quick` 0.05 s — no-op (`scripts/prod-readiness-precheck.sh` absent at this head; not a production validation).
- ✔️ `banned-cast-tokens` (`node scripts/check-r75.js --mode=staged`) 0.32 s — `OK — no positive token change`.
- ✔️ `prettier` (`npx prettier --check test/rls-g2-pg17-etq0.spec.ts`) 1.99 s — `All matched files use Prettier code style!`.
- ✔️ **`eslint` (`npx eslint --no-warn-ignored --max-warnings 0 test/rls-g2-pg17-etq0.spec.ts`) 3.16 s — exit 0, no output** (the original 07 refusal — 5 `no-unused-vars` warnings — is gone).
- ✔️ **`tsc` (`npx tsc --noEmit`) 48.69 s — exit 0** with the step-02 generated client.
- commit-msg: ✔️ `no-ai-tokens` 0.02 s.
- npx resolutions: three npm debug logs (tsc exit 0, eslint exit 0, prettier exit 0), **0 `http fetch` lines**, `~/.npm/_npx` dirs 0; all tools resolved from `worktrees/s5-r4/node_modules` (+ pinned prettier link).

### C4. Exact new head (08 postchecks all rc 0; `candidate/identity.txt`, `POSTRUN_OBSERVATIONS.txt`)
- **HEAD `98d39610f511505558373f3a59fa019804c94bd7`**, tree **`67fc1db5f353f0d363fe7134a78d455c0decfb55`**, parent **`143d451ead6ccdbebd92ca3031ba7a89867d6cfc`**, detached; commit object sha256 `ff8fce75…1b6c`; gpgsig 0; committer ts 1790193165.
- author **and** committer `Bradley Gleave <bradley@bradleytgpcoaching.com>` (verified on the landed object); `%(trailers)` empty; banned-token grep in commit object 0; message == frozen file.
- `git diff 143d451e HEAD` sha256 **`9f37223b889b31580ba8024b14d86ac3d0fb9feab08ef4b250292d50a735921d`**; changed files exactly `test/rls-g2-pg17-etq0.spec.ts` (975/357) and `test/utils/g2-pg17-bootstrap.sh` (34/4, `100755 85a636ba` byte-identical to the frozen patch post-image).
- Deltas kept separate: original two-file patch `c36258b3` → archived formatting `c43b4d1b` (recovered 756a0d79 / `2c92a964`) → binding-only `ed1e596c` (5/5) → formatter-only `6ea68be8` (one reflow) → committed `9f37223b`.
- refs unchanged (`refs/heads/main`=c23b9d9f, `refs/restored/execute/20260921-s5-r3`=143d451e); porcelain 0; untracked 0; no `index.lock`, `.eslintcache`, tsbuildinfo or `dist`; `.git/config` 7 keys (4 defaults + `core.abbrev=8` + the two identity keys set by 07R).
- **Bundle** `candidate/bundle/s5-r4-hooked-98d39610-from-public-c23b9d9f.bundle` sha256 **`e624facc9f4dc08f92b930350fa7d01ee8262d28577d9013ec0ff9571c1dc9fb`**, contains `98d39610 HEAD`, requires c23b9d9f, verify okay.
- Unchanged dependency pins on the committed head: `package-lock.json` blob `354de3da` / sha256 `b7fed5ed…9c55`; installed record `05bc530a…7b44`; Prisma CLI `c2a77456…e1a0`; engine + client engine `a2924eab…a7d8`; pinned Prettier CLI `6e922134…906e`; lefthook 2.1.9 hooks real and active.

## D. Not done / not claimed / boundary
- No fresh51 real-PostgreSQL proof (no PostgreSQL binaries in this sandbox: `psql`/`pg_ctl`/`initdb` absent), no T0/baseline/private controls rerun, no jest/test run, no remote push/merge/deploy, no DB or customer action. This receipt is hooked-commit evidence only; not product acceptance.
- **Remaining fresh51 boundary**: the parent-granted real-database proof of head `98d39610` (spec `test/rls-g2-pg17-etq0.spec.ts` + `test/utils/g2-pg17-bootstrap.sh`) after the two independent exact-head/runner reviews. Restored proof inputs available here: worktree `worktrees/s5-r4` at HEAD 98d39610 (clean; `node_modules` 05bc530a; generated client + engine a2924eab; real hooks; prettier link), bundle above, and `retrieved/` (bundle e42aa021, patch c36258b3, prep e9f4a5d5 steps incl. `07-commit-message.txt`, continuation 9d47c0dc preimages/logs, setup receipt/provenance, tooling manifests). The archived proof runner files (`2026-09-22/remediation/s5-r4/checkpoint-1/{run-proof.sh,s5-fixture.sh,launch-full.sh,npm-ci.sh}`) were NOT retrieved (outside this task) and a PostgreSQL 17 substrate is absent — both are inputs the fresh51 grant must supply.
- Class C (record, continue): (1) baseline object database is a fresh depth-1 fetch of the same public commit rather than a byte copy of the old `source/backend/.git` — same commit, same resulting trees/blobs, verified by all archived hashes; (2) process-census lines that counted the census shell's own pattern (re-run 0); (3) Prisma engine fetched from binaries.prisma.sh during step 02 because the fresh sandbox had no engine cache — output engine hash equals the pin; (4) lock path substituted to this root (no S6 runtime contention exists by parent decree); (5) the five edits were applied with this platform's exact-string edit tool as the visible manual patch, recorded as a diff (B1) — no scripted/regex rewrite of the file.
- Runtime slot released: `candidate/RUNTIME_RELEASE.txt` (all 10 step invocations ended, lock fd holders 0, caller sessions empty, 0 attributable processes).

## E. Output manifest
`MANIFEST.sha256` (non-self-including) covers this root recursively except itself, `tooling/prettier-3.9.6/node_modules/**` (reproducible from the manifested package.json/lock; CLI hash recorded in F0 log), and the empty `test-validation.lock`.
