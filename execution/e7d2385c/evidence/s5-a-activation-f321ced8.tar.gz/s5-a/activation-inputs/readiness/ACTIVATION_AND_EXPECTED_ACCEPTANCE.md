# S5 fresh51 proof — exact runner, head, activation command and frozen expected acceptance (prepared 2026-09-23T20:05Z; NOT executed)

Status: preparation only. No runner stage has been invoked; no cluster exists; no jest ran; no npm/prisma generation re-ran. Activation is the parent's decision after two independent exact-head/runner reviews (A/B).

## 1. Exact inputs (byte identities)
| Input | Path | Identity |
|---|---|---|
| Source head (clean, detached) | `/home/user/workspace/worktrees/s5-r4` | HEAD `98d39610f511505558373f3a59fa019804c94bd7`, tree `67fc1db5f353f0d363fe7134a78d455c0decfb55`, parent `143d451e…`, `git status --porcelain` empty; author=committer Bradley Gleave; real lefthook `pre-commit`/`commit-msg`, `core.hooksPath` unset |
| Proof spec | `test/rls-g2-pg17-etq0.spec.ts` | sha256 `2b7d1969f64ca837caa075e5bec91174242355804db8d37daa672cc240568e7f`; 22 direct `it(` + 13 `it.each` (29 rows) = **51 cases**, 0 `.skip/.only` |
| Bootstrap | `test/utils/g2-pg17-bootstrap.sh` | blob `85a636ba75607604032cef7af1d285cb198ca263` (100755) |
| Runner (rev 7) | `/home/user/workspace/execution/s5-r4/run-proof.sh` | sha256 `19ab936a1562061caf4f8ee8426a5e18a998b22f3d33093a45a02b64ee3fc2c5` — byte-identical to private `2026-09-22/remediation/s5-r4/checkpoint-1/run-proof.sh`; lane constants unchanged (`W=/home/user/workspace/worktrees/s5-r4 X=/home/user/workspace/execution S=$X/s5-r4 PG17_HOME=/home/user/pg17 WORK_BUDGET=1560 REAP_BUDGET=20 STOP_BUDGET=45`) |
| Fixture (rev 2) | `/home/user/workspace/execution/s5-r4/s5-fixture.sh` | sha256 `3a7d57bf951ab27e2161dc91db1d816f31d4af079ede076e7a2dfd1c44f3a721` (identical) |
| Launcher (rev 2) | `/home/user/workspace/execution/s5-r4/launch-full.sh` | sha256 `a03836d524bafc28572b1e600f34148d8e9ddea38391ffc427c26f5399b9f728` (identical) |
| npm-ci.sh | `/home/user/workspace/execution/s5-r4/npm-ci.sh` | sha256 `951c20a3…badb`, mode 0644, present for reference ONLY — not run, not to be run (node_modules already at pinned record `05bc530a…7b44`) |
| PG 17.6 substrate | `/home/user/pg17/dist` + `/home/user/pg17/PROVENANCE.txt` | zonky `embedded-postgres-binaries-linux-amd64-17.6.0.jar` sha1 `8163322358dbe4e6c2abccc90f2e543f8cfc65db`, jar sha256 `23da5a04…1d29d`, txz `26fa6334…067c0`, **postgres `23cd174849b273064c47d581b55be596be2f5cf0ee5d3e76c0146e2464bf873a`, initdb `b7db9bc2463a4ffbe1e405977512afb50c9846fd3af2b694e315e6d5a270882a`** — all equal to the S1 R3 (2026-09-20) and S2 (2026-09-21) recorded values; `result=success` |
| psql client | `/usr/bin/psql` (runner default `G2_PG17_PSQL`) | `psql (PostgreSQL) 18.6 (Ubuntu 18.6-0ubuntu0.26.04.1)`, package `postgresql-client-18 18.6-0ubuntu0.26.04.1` — identical to the S2 lane |
| Dependencies (unchanged, not re-run) | `worktrees/s5-r4/node_modules` | `.package-lock.json` sha256 `05bc530a…7b44`; Prisma client generated, engine `a2924eab…`; jest/prisma present at `./node_modules/.bin` |

Runner pins (literals in run-proof.sh): host 127.0.0.1, port 54325, db `g2_s5_etq0_disposable`, admin `s5_super`, datadir `/home/user/pg17/clusters/s5`, server_version_num 170006, cluster marker `s5-disposable-pg17`, db marker `s5-g2-etq0-synthetic-disposable-fixture-safe-to-drop`. All literal cross-checks the runner's `offline_guard` performs were reproduced read-only and pass (readiness/READINESS.txt).

## 2. Classification of expected differences vs the archived checkpoint-1 context
- Runner rev 7 contains **no HEAD/tree/fingerprint pin**; `stamp()` observes them. Expected stamp on this lane: `HEAD=98d39610… TREE=67fc1db5… CLEAN=yes DIRTY_FINGERPRINT=none PACKAGE_LOCK_BLOB=354de3da… NODE_MODULES_PACKAGE_LOCK_SHA256=05bc530a…` (archived context was dirty 143d451e + fingerprint 6850b32e; the change is the hooked commit itself — class C, no runner edit needed).
- Root paths: identical to archived lane constants; **zero substitutions** in run-proof.sh / s5-fixture.sh / launch-full.sh.
- Worktree is a shallow repository (boundary c23b9d9f). `test/utils/g2-pg17-old-root.sh create` (used by stage `full`) was exercised once into a scratch path (`scratch/oldroot-clone-check-925780e0`, 1.3 s, `G2_PG17_OLD_ROOT_OK`, head 925780e0, 164 migrations): git falls back from local to transport clone for a shallow source, so the `full` stage's old-root creation is feasible. Class C.
- Setup scripts reused from S2 (`_common.sh af881779`, `setup-10-clients.sh 622f1997`, `setup-20-pg17.sh 96a2a443`) with only: lock/log root → this builder's root (peer canonical lock path not touched during prep) and `installed_by` label. Diffs in `infra/*.diff-vs-s2`.
- At proof time the runner itself will create/use the canonical `/home/user/workspace/execution/test-validation.lock` and `test-validation.lock.log` (currently absent) — parent activation scope, not this prep.

## 3. Exact activation (parent-driven; after A/B reviews)
```
# preconditions the runner enforces itself: /home/user/pg17/clusters/s5 ABSENT, execution/s5-r4/QUARANTINE ABSENT, lock free
G2_PG17_PASSWORD=s5_local_synthetic STAGE=full bash /home/user/workspace/execution/s5-r4/launch-full.sh
# returns immediately; prints pid/sentinel/log paths under /home/user/workspace/execution/s5-r4/logs/
# full = guard -> oldroot -> init(fresh) -> start -> preflight -> bootstrap -> live(51) -> stop ; inner budget 1560 s, outer TERM 1740 s / KILL +120 s
```
`s5_local_synthetic` is the synthetic superuser password literal in s5-fixture.sh (initdb `--pwfile`); it is not a secret. Post-run parent single stage (separately granted): `G2_PG17_DESTROY_CONFIRM=destroy:/home/user/pg17/clusters/s5 bash run-proof.sh destroy`.

## 4. Frozen expected acceptance (what a PASS must show; anything else is a FAIL to report, not to retry)
Files under `/home/user/workspace/execution/s5-r4/logs/`:
1. `full-<TS>.sentinel`: `FULL_EXIT=0 OUTER_BOUND=no`.
2. `exit-full-<TS>.log`: `PROOF_EXIT=0 FIRST_RC=0 STAGE=full STOP_RC=0 DAEMON=none SURVIVORS=none SIGNALLED=none … QUARANTINE=no`.
3. `env-full-<TS>.log`: `RUNNER_SHA256=19ab936a…`, `FIXTURE_SHA256=3a7d57bf…`, `HEAD=98d39610… TREE=67fc1db5… CLEAN=yes DIRTY_FINGERPRINT=none`, `PACKAGE_LOCK_BLOB=354de3da…`, `NODE_MODULES_PACKAGE_LOCK_SHA256=05bc530a…`, `PG_DIST=/home/user/pg17/dist postgres_sha256=23cd1748… version=postgres (PostgreSQL) 17.6`, `DATA_DIRECTORY_STATE=absent` (before), npm-root facts before == after.
4. `run-full-<TS>.log`: `OFFLINE_GUARD_OK`, `LOCK_HELD`, `LOCK_EXCLUSIVE_OK`, `PREFLIGHT version=170006 cluster=s5-disposable-pg17 datadir=/home/user/pg17/clusters/s5 listen=127.0.0.1 addr=127.0.0.1 port=54325 user=s5_super super=t hosted_roles=0 dbs=[postgres template0 template1] target_exists=0 … target_sessions=0`, `PREFLIGHT_OK`, each `END … rc=0 timed_out=0`.
5. `guard-unit-<TS>.log`: jest guard spec `test/scout/g2-pg17-db-guard.spec.ts` PASS.
6. `oldroot-<TS>.log`: `G2_PG17_OLD_ROOT_OK`, head 925780e0, migrations=164.
7. `fixture-<TS>.log`: `S5_FIXTURE_INIT_OK … pg_version=17`, `S5_FIXTURE_START_OK`, `S5_FIXTURE_STOP_OK`.
8. `bootstrap-<TS>.log`: `G2_PG17_BOOTSTRAP_OK` (marked database created, migrations applied, generated clients' engine equality).
9. `live-etq0-<TS>.log`: `Tests: 51 passed, 51 total`, `Test Suites: 1 passed, 1 total`, no `PG17_TEARDOWN_SKIPPED`, exit 0.
10. Source unchanged after the run: HEAD still `98d39610`, `git status --porcelain` empty, hooks files unchanged, `node_modules/.package-lock.json` still `05bc530a…`, no `execution/s5-r4/QUARANTINE`, `/home/user/pg17/clusters/s5/postmaster.pid` absent (stopped).
No acceptance case is redefined here; the 51 cases are those in the committed spec at 98d39610.

## 5. Not done (deliberately)
No `run-proof.sh` stage (not even `oldroot`/`guard`), no `initdb`, no server start, no migration, no jest, no npm/prisma re-run, no T0/controls, no push. Product source untouched (98d39610 remains).
