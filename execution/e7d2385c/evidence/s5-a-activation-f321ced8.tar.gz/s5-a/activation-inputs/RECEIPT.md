# S5 fresh51 proof preparation — receipt (EXEC-e7d2385c, T4): exact runner materialization, PG 17.6 substrate recovery, readiness freeze; NO proof executed

Builder/executor (not auditor). Requested Claude Fable 5 / High (runtime identity not observable). 2026-09-23T20:01Z–20:08Z. Sealed continuation packet `execution/e7d2385c/s5-continuation/` unchanged (manifest `4007b242…` re-verified OK after prep). Product source untouched: `worktrees/s5-r4` HEAD `98d39610`, clean, real hooks preserved.

## A. Exact retrieval (gh api contents, ref cc62002b; no branch/history sweep)
`retrieved/2026-09-22/remediation/s5-r4/checkpoint-1/`: **run-proof.sh `19ab936a…c2c5`** (rev 7), **s5-fixture.sh `3a7d57bf…a721`** (rev 2), **launch-full.sh `a03836d5…f728`** (rev 2), npm-ci.sh `951c20a3…badb` (read only), SHA256SUMS `1737068c…`, REPORT/RECREATE/HOOK_DEPENDENCY/CONTROL_REQUEST.md — `sha256sum -c` 8/8 OK.
Named S2/S1 substrate references: `2026-09-21/remediation/s2-composition/setup-and-runner-readiness/{infra/_common.sh af881779, infra/setup-10-clients.sh 622f1997, infra/setup-20-pg17.sh 96a2a443, infra/logs/setup-10-*.log, infra/logs/setup-20-*.log, PG17-PROVENANCE.txt a7282e42, READY_SETUP.txt, SHA256SUMS}` (hashes match its SHA256SUMS), `2026-09-20/remediation/s1-r3/revision-1/PG17_PROVENANCE.txt`, `2026-09-22/remediation/s2-setup-prep/proposal-1/{diffs/setup-20.diff, infra/_common.sh}` (read for comparison; the executed S2 originals were reused, not the unexecuted proposal).

## B. Materialization (authorized paths only)
- `/home/user/workspace/execution/s5-r4/`: run-proof.sh, s5-fixture.sh, launch-full.sh byte-identical (0755); npm-ci.sh byte-identical but **0644 and NOT run**; `SHA256SUMS.checkpoint-1` copy. Lane constants unchanged → **zero runner/fixture/launcher edits**.
- `/home/user/pg17/`: setup-10 (`postgresql-client-18 18.6-0ubuntu0.26.04.1` via apt, `/usr/bin/psql` = runner default) exit **0**, 20:04:15–20:04:28Z; setup-20 (zonky 17.6.0 jar from Maven Central, sha1 pin verified, jar/txz/postgres/initdb sha256 all **equal to S1/S2 recorded values**, extracted to `dist/`, `PROVENANCE.txt result=success`) exit **0**, 20:04:37–20:04:38Z. `postgres --version` = `postgres (PostgreSQL) 17.6`; initdb/pg_ctl 17.6. No cluster created (`clusters/` absent).
- Infra scripts used: `infra/*.sh` = S2 originals with only lock/log root → this builder's root and `installed_by` label (`infra/*.diff-vs-s2`; setup-10 zero diff). Frozen before execution: `frozen/FROZEN_BEFORE_SETUP.txt`. Logs: `logs/setup-1{0,2}0.{stdout,stderr,exit}`, `infra/logs/`.

## C. Readiness (setup identity, not test) — `readiness/READINESS.txt`, `readiness/ACTIVATION_AND_EXPECTED_ACCEPTANCE.md`
- Head `98d39610` / tree `67fc1db5` / clean / author=committer Bradley / spec sha256 `2b7d1969…` / bootstrap blob `85a636ba` / lock blob `354de3da` / node_modules record `05bc530a` / engine `a2924eab` / hooks real, hooksPath unset.
- Runner `offline_guard` literal cross-checks reproduced read-only: 7/7 pass (markers in db.ts and bootstrap, fixture pins, PG17_HOME, no nested flock). Data dir, QUARANTINE, canonical lock absent; port 54325 free; no postgres process.
- Spec case count (static parse): 22 direct + 29 `it.each` rows = **51**, 0 skip/only — frozen as the acceptance count.
- Old-root feasibility on the shallow worktree: `test/utils/g2-pg17-old-root.sh create` into `scratch/oldroot-clone-check-925780e0` → `G2_PG17_OLD_ROOT_OK` head 925780e0, migrations 164 (1.3 s). Worktree unchanged afterwards.
- Utilities: util-linux setsid/flock, uutils timeout 0.8.0 (`--foreground --kill-after` accepted), free/nproc/ss present.

## D. Classification
- Class C (record, no cycle): (1) runner has no HEAD/fingerprint pin — stamp will observe `HEAD=98d39610 TREE=67fc1db5 CLEAN=yes DIRTY_FINGERPRINT=none` instead of the archived dirty 143d/6850b32e context; (2) setup lock/log root substituted to this builder's root (canonical `execution/test-validation.lock` untouched; the runner will create it at activation); (3) `installed_by` label; (4) psql 18.6 client vs 17.6 server — identical to the S2 lane; (5) process-census self-match in RUNTIME_RELEASE; (6) network events: apt (Ubuntu archive) and Maven Central download — both are the reviewed setup's own actions, hashes pinned.
- No A/B items found in preparation. Unexecuted assumptions from checkpoint-1 REPORT (uutils `timeout --foreground` behaviour under the launcher, setsid group verification) remain unexecuted here by design.

## E. Not done
No `run-proof.sh` stage (incl. `oldroot`/`guard`), no initdb/start/migration/jest, no npm ci / prisma generate, no T0/baseline/controls, no old proof, no push, no product edit. 17.6 was available; no alternative needed.

## F. Handover
Activation command, expected stamp/preflight/exit/acceptance lines and post-run invariants: `readiness/ACTIVATION_AND_EXPECTED_ACCEPTANCE.md` §3–4. Runtime slot released: `RUNTIME_RELEASE.txt` (20:07:25Z). Manifest: `MANIFEST.sha256` (non-self-including; excludes `test-validation.lock` and `scratch/oldroot-clone-check-925780e0/**` git objects, whose identity is the recorded head).
