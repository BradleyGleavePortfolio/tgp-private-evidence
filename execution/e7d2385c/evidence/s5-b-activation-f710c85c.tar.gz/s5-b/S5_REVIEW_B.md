# S5 independent review B — exact candidate/runner source + hooked head 98d39610 (EXEC-e7d2385c)

Reviewer: independent nonbuilder S5 reviewer B (did not author any S5 byte; did not read s5-a or any parent disposition). Tier T4 individual/cumulative; requested Claude Fable 5 / High (requested setting, not runtime telemetry). Observed 2026-09-23 ~20:05–20:25Z.

Method: source-read only. No tests, install, node/npm, fixture, probe, runtime, or product edit. Git reads under `GIT_OPTIONAL_LOCKS=0` against `worktrees/s5-r4` (no ref/index/worktree write). Patch-layer replay was done on copies under my own scratch directory (`execution/e7d2385c/audits/s5-b/scratch/`), never in the candidate. Sole writes: `execution/e7d2385c/audits/s5-b/**`.

Read: `SCOPE.md`, `startup_read/live_AGENT_RULES.md`, `inputs/OWNER_SAFETY_ROI_AND_EXECUTION_DOCTRINE.md`, `inputs/S5_LINT_DISPOSITION_AND_COMMIT_ACTIVATION.md`, sealed `s5-continuation/RECEIPT.md` + `MANIFEST.sha256` and the packet files it covers, head/parent source in the worktree, and the already-retrieved checkpoint-1 runner files under `s5-proof-preparation/retrieved/` (hash-verified; no other s5-proof-preparation output existed yet). Not read: peer `audits/s5-a/**`, any parent S5 disposition, private shelf (no gh fetch was needed — every referenced byte was present locally with matching hashes).

S1–S4 accepted evidence is treated as applicable and unchanged; not re-audited. No controls, baselines, or harness were added.

---

## 1. Packet integrity (independently recomputed)

| Item | Expected | Observed | Match |
|---|---|---|---|
| `s5-continuation/MANIFEST.sha256` | `4007b242…5371` | `4007b242146cd6a547ae31306dd3c02cda3200c9dda65574bef8c39822095371`, 136 entries, `sha256sum -c` all OK | yes |
| Bundle `candidate/bundle/s5-r4-hooked-98d39610-from-public-c23b9d9f.bundle` | `e624facc…c9fb` | `e624facc9f4dc08f92b930350fa7d01ee8262d28577d9013ec0ff9571c1dc9fb`; `git bundle verify` (inside repo) okay; contains `98d39610 HEAD`, requires `c23b9d9f` | yes |
| `RECEIPT.md` | manifested | `b21060c5…0665` = manifest entry | yes |

## 2. Exact head pin (read from the repository object store, not from the receipt)

| Fact | Observed |
|---|---|
| HEAD | `98d39610f511505558373f3a59fa019804c94bd7` (detached; `git symbolic-ref -q HEAD` empty) |
| tree | `67fc1db5f353f0d363fe7134a78d455c0decfb55` |
| parent | `143d451ead6ccdbebd92ca3031ba7a89867d6cfc` (single parent) |
| author / committer | both `Bradley Gleave <bradley@bradleytgpcoaching.com>`, ts 1790193165 +0000 (on the landed object) |
| trailers / gpgsig | `%(trailers)` empty; no `gpgsig` line; message = the frozen `07-commit-message.txt` text (hash-guarded in 07R, re-checked in 08) |
| commit object sha256 | `ff8fce75ba9edf0922645be895fccfdbc9e37d9bcd6cb219b14541e87e711b6c` |
| refs | exactly `refs/heads/main`=c23b9d9f, `refs/restored/execute/20260921-s5-r3`=143d451e |
| worktree | porcelain 0 lines (incl. untracked) |
| `.git/config` | 4 defaults + `core.abbrev=8` + `user.name`/`user.email` (Bradley); `core.hooksPath` unset; no `hooks` override |
| `git diff 143d451e HEAD` sha256 | `9f37223b889b31580ba8024b14d86ac3d0fb9feab08ef4b250292d50a735921d` |
| changed paths | exactly `test/rls-g2-pg17-etq0.spec.ts` (975/357, blob `100644 b3af897e`, sha256 `2b7d1969…8e7f`) and `test/utils/g2-pg17-bootstrap.sh` (34/4, blob `100755 85a636ba`) |
| unchanged policy/config vs parent | `git diff HEAD^ HEAD -- eslint.config.js lefthook.yml package.json package-lock.json` = 0 bytes |

Every pin in the task brief (head, tree, parent, manifest, bundle) matches the object store.

## 3. Independent reconstruction of the two-file delta (four layers, replayed on copies)

Starting from the parent blobs (`143d451e:test/rls-g2-pg17-etq0.spec.ts` sha256 `54c85d8d…`, bootstrap `0ff77d8b…`):

| Layer | Patch (sha256) | Result sha256 / blob | Matches archive |
|---|---|---|---|
| L1 original checkpoint-1 correction | `c36258b3…5491` (`retrieved/2026-09-22/…/s5-r4-dirty-from-143d451e.patch`) | spec `01f3cfc0…` (blob `ff5a38b8`), bootstrap `d3348db8…` (blob `85a636ba`) | archived staged preimage `01f3cfc0`; bootstrap post-image |
| L2 archived Prettier formatting (frozen 06F) | `c43b4d1b…d21d` | spec `338defe8…6430` | frozen 06F hash |
| L3 five binding aliases | `ed1e596c…853a` (`candidate/preimage/binding-only-vs-index-756a.patch`) | spec `0f624f2c…453e` | builder's pre-format hash |
| L4 pinned Prettier 3.9.6 reflow | `6ea68be8…7180` (`formatter-only-delta.patch`) | spec `2b7d1969…8e7f` | — |
| Final | — | `cmp` spec and bootstrap against `HEAD:` blobs: **identical** | committed head |

So the committed head is exactly parent + L1 + L2 + L3 + L4 and nothing else. Bootstrap is touched only by L1 (byte-identical to the frozen post-image).

### 3.1 L3 — the five authorized alias changes (grant §Concrete defect)

`diff` of `staged-338defe8` vs `binding-edited-preformat` shows exactly five changed lines, nothing else:

- L176 `const families = [...]` → `const _families = [...]` (literal declaration retained; `rg` confirms no other `families` identifier reference in the file — the only other hits are comments).
- L253, L452, L1269 `const { source_platform, ...rest } = r;` → `const { source_platform: _source_platform, ...rest } = r;` — property key `source_platform` unchanged, so `rest` still excludes it.
- L307 `({ updated_at, ...rest }: any) => rest` → `({ updated_at: _updated_at, ...rest }: any) => rest` — same exclusion semantics.

No new token/cast/assertion/control-flow, no config, hook or suppression change. The pre-existing rule at HEAD is `'@typescript-eslint/no-unused-vars': ['warn', { argsIgnorePattern: '^_', varsIgnorePattern: '^_', caughtErrors: 'none' }]` — the aliases use the existing ignore pattern; nothing was widened. Decision: conforms exactly to the grant's five edits.

### 3.2 L2 + L4 — formatting layers (semantic neutrality checked at token level)

Whitespace-stripped character diff of L2 (`01f3cfc0` → `338defe8`): 160 opcodes = 152 trailing-comma insertions, `<T,>`→`<T>` in a `.ts` generic arrow (the comma is only needed in `.tsx`), removal of redundant parentheses around two arrow-body conditionals (`cursorOf`, `nextLegacy`), and one string requoted `'…E\'s…'` → `"…E's…"` (escape dropped). All are Prettier-canonical and semantically neutral. L4 is a single line-length reflow of the L307 `pages.map(...)` expression with zero token change. The pre-commit `prettier --check` of the head passed; tsc passed. Decision: no behavior change.

### 3.3 L1 — the original teardown / bootstrap correction (substantive review)

**Spec: teardown authority (`teardownAuthorized`).** I verified line by line that every statement in `beforeAll` before the flag is a read-only observation: `json(SELECT …)`, `sqlAdmin(SELECT current_setting('data_directory'))`, `sql(SELECT …)` ×6, `appliedMigrations()`, `hasColumn()`, `readFileSync` ×2, `gitShow` (read), `console.warn`. The flag is set immediately before the first mutation (`GRANT …`). `afterAll` with the flag false emits `PG17_TEARDOWN_SKIPPED` and returns with no SQL. With the flag true it runs `DROP CONSTRAINT IF EXISTS` ×2 (idempotent), `resetData()` (DELETEs on the five fixture tables, which exist because the 164-migration gate passed), and `DELETE FROM "ScoutImport"`. Jest-circus runs top-level `afterAll` after a failed `beforeAll` but does not run `beforeEach` of skipped tests; the nested describes contain only `beforeEach(resetData)` and no `afterAll`/`afterEach`, so there is no other mutation path after a refused setup. Cleanup safety: a refused identity/marker/pre-state gate now issues zero DDL/DML against an unaccepted target; a partially authorized setup still cleans up. Data isolation is otherwise carried by the unchanged, previously accepted `g2-pg17-db.ts` guard (loopback, refused ports, pinned DB name, double-entry confirmation, pinned cluster/database markers) and the unchanged harness role matrix. Decision: correct and fail-closed; no A/B finding.

**Bootstrap: enforced provenance.** `set -euo pipefail` is in force. `hash_required` exits 6 inside a command substitution used as a plain assignment, so `set -e` aborts the script with status 6 and the stderr reason is visible; the `[[ … ]] && cmp … || { …; exit 6; }` compounds have no masked-failure branch. Engine equality is now enforced for both generated clients (previously only O), and the candidate client's runtime is resolved from the generated directory and compared with the pinned path. I checked the premise against the actual generated client at the head: `node_modules/.prisma/client/runtime/` does not exist, `node_modules/@prisma/client/runtime/library.js` exists (202,499 B), both engine copies hash `a2924eab…a7d8`, and the ledger model in the generated schema carries `source_platform String?`. Under the old code the `CANDIDATE_CLIENT_GENERATED` echo would have hashed a missing file inside an `echo` substitution and printed an empty field without failing (the S5-R3-A-05 defect); the new code refuses. Decision: a genuine proof-validity improvement, fail-closed, no product surface touched.

Residual observation (Class C, pre-existing): teardown does not `REVOKE` the setup GRANTs; the disposable database is dropped/destroyed by the runner lifecycle, so nothing persists beyond the lane.

## 4. Genuine hooks, identity and input evidence

- Hook scripts `.git/hooks/pre-commit` and `commit-msg` are lefthook-generated; `core.hooksPath` unset; `LEFTHOOK`/`LEFTHOOK_EXCLUDE` unset at commit time (echoed by 07R). The `set -x` trace in `07R-identity-and-hooked-commit.log` shows `LEFTHOOK_BIN` empty, PATH lefthook absent, and dispatch to `node_modules/lefthook-linux-x64/bin/lefthook` (package.json version 2.1.9) for both `run pre-commit` and `run commit-msg`.
- Pre-commit jobs on staged files = the two paths: `prod-readiness-quick` no-op (script absent at this head, disclosed), `banned-cast-tokens` `OK — no positive token change`, `prettier --check` clean, `eslint --no-warn-ignored --max-warnings 0 test/rls-g2-pg17-etq0.spec.ts` exit 0 with no output (the original 07 refusal is gone), `tsc --noEmit` exit 0 (48.69 s). Commit-msg `no-ai-tokens` passed. Commit result `[detached HEAD 98d39610] … 2 files changed, 1009 insertions(+), 361 deletions(-)`.
- 08 postchecks all rc 0 (read directly from the log), including tree-identical, parent, identity, trailers, message equality, porcelain 0, banned-token 0, detached, diff hash `9f37223b`, numstat, refs.
- Command substitutions (`SUBSTITUTIONS.md`, `*.diff-vs-continuation`) are mechanical only: 07R tree guard `756a0d79→67fc1db5`; 08 tree/diff-hash/numstat/labels; `step.sh` roots + holder label `slot-H3`. 09/10 original. R75 range checks 143d..HEAD and c23b..HEAD both exit 0.
- Pins on disk now: `package-lock.json` `b7fed5ed…9c55`; `node_modules/.package-lock.json` `05bc530a…7b44`; pinned Prettier CLI `6e922134…906e` (linked at `node_modules/.bin/prettier`); eslint 10.5.0, typescript 5.9.3, prisma 6.19.3, lefthook 2.1.9; engine `a2924eab…a7d8` in both `@prisma/engines` and `.prisma/client`.
- Runtime released: 10 start / 10 end holder lines, lock fd holders 0 (`RUNTIME_RELEASE.txt`).

Decision: the head is a genuine, hook-enforced, correctly attributed commit of exactly the authorized delta.

## 5. Runner source review for the existing fresh51 real proof (inputs recovered so far)

Hash-verified against checkpoint-1 `SHA256SUMS`: `run-proof.sh` `19ab936a…`, `s5-fixture.sh` `3a7d57bf…`, `launch-full.sh` `a03836d5…`, `npm-ci.sh` `951c20a3…`.

Proof semantics as written:
- `live` runs `./node_modules/.bin/jest --config jest.rls.config.js test/rls-g2-pg17-etq0.spec.ts --runInBand --testTimeout=180000` as an owned, process-group-supervised child; the head's `jest.rls.config.js` `testMatch` includes `<rootDir>/test/rls-*.spec.ts` and ignores only `node_modules`/`dist`, so the spec is selected. The head spec has 22 plain `it(` plus 13 `it.each` blocks totalling 29 cases = **51 tests**, no `.skip`/`.only`/`todo` — matching the "fresh51" name; a passing run must report `Tests: 51 passed, 51 total`.
- `finish` writes `PROOF_EXIT=<rc> FIRST_RC=… STOP_RC=… DAEMON=… SURVIVORS=… QUARANTINE=…`; a cleanup-stop failure, live postmaster or owned survivor converts rc 0 to 3 and quarantines the lane. The exit record therefore distinguishes success from timeout (124) and from masked cleanup.
- `stamp` records `HEAD/TREE/CLEAN/DIRTY_FINGERPRINT`, `RUNNER_SHA256`, `FIXTURE_SHA256`, node_modules lock hash and PG provenance, but does **not** refuse a wrong head — the final attestation must read `HEAD=98d39610… TREE=67fc1db5… CLEAN=yes` from `env-<stage>-<ts>.log`.
- Preflight (13 facts, maintenance DB, superuser) precedes every mutation; `full` = guard → oldroot → init (fresh only) → start → preflight → bootstrap → live → stop.

Mechanical prerequisites in this fresh sandbox (not defects; recorded so the builder's substitutions can be checked exactly):
1. Lane constants are hardcoded: `W=/home/user/workspace/worktrees/s5-r4` (matches), `X=/home/user/workspace/execution`, `S=$X/s5-r4`, `LOCK=$X/test-validation.lock`, `PG17_HOME=/home/user/pg17`; fixture `PG17_HOME`; launcher `S=…/execution/s5-r4`, `DATA=/home/user/pg17/clusters/s5`. The runner declares the lane block as the only substitutable lines. Any substitution must be frozen and diffed against `19ab936a`/`3a7d57bf`/`a03836d5` before launch and the stamped `RUNNER_SHA256`/`FIXTURE_SHA256` must equal the frozen substituted files.
2. The head spec pins `expect(directory).toMatch(/\/pg17\/clusters\/s5$/)`; `PG17_HOME` must end in `pg17`.
3. `G2_PG17_PSQL` defaults to `/usr/bin/psql`, absent here; it must point at the PG 17.6 dist `psql`, and `PROVENANCE.txt` must carry `result=success` and matching `postgres_sha256`/`initdb_sha256`.
4. The restored object DB is shallow at `c23b9d9f` (`.git/shallow` present). O `925780e0` is present and an ancestor of HEAD, so `g2-pg17-old-root.sh` can clone/detach it (the local clone of a shallow source yields a shallow clone; every old-root and bootstrap gate is file/HEAD-based and needs no history below `c23b9d9f`).
5. `S=…/execution/s5-r4` (logs, `old-root-925780e0`, `QUARANTINE`) lies outside `execution/e7d2385c`; path ownership is a parent/builder decision.

## 6. Findings

No Class A finding. No Class B finding. Nothing here blocks the affected product path or invalidates the pending proof.

Class C (record, qualify, continue; no new cycle):
- C1 Teardown does not revoke setup GRANTs (pre-existing; disposable DB lifecycle covers it).
- C2 Bootstrap's "pinned runtime preceded only by the generator header" rule is an observed-6.19.3 assumption; a change would surface as a visible fail-closed `exit 6`, i.e. an evidence/prerequisite refusal, not a product defect.
- C3 Builder disclosures accepted as recorded: depth-1 base fetch instead of byte-copied `.git`; Prisma engine fetched from `binaries.prisma.sh` during step 02 (hash equals pin); lock path moved into the packet root; `prod-readiness-quick` no-op.
- C4 Runner records but does not pin the head (covered by the attestation checklist below).

## 7. Verdict (source phase) — SEALED

**Source / grantability: GRANTABLE.** Head `98d39610f511505558373f3a59fa019804c94bd7` (tree `67fc1db5…`, parent `143d451e…`) is exactly the authorized S5 candidate: the original checkpoint-1 teardown/bootstrap correction, the frozen Prettier formatting, the five authorized `_`-prefixed binding aliases and one pinned reflow, committed through genuine lefthook hooks with verified Bradley author/committer and unchanged dependency/toolchain pins. The one existing fresh51 real PostgreSQL 17.6 proof may be executed against this exact head. This is not runtime or product acceptance; no public push/merge/deploy/customer action is implied.

Attestation checklist I will apply to the actual fresh51 result (same review, appended, no new audit cycle):
1. `env-*.log` stamp: `HEAD=98d39610f511505558373f3a59fa019804c94bd7 TREE=67fc1db5f353f0d363fe7134a78d455c0decfb55 CLEAN=yes`, `NODE_MODULES_PACKAGE_LOCK_SHA256=05bc530a…`, `PACKAGE_LOCK_BLOB=354de3da…`, `RUNNER_SHA256`/`FIXTURE_SHA256` = frozen substituted files, PG provenance `result=success`, `version=170006`.
2. `preflight-*.log`: version 170006, cluster marker `s5-disposable-pg17`, loopback listen/addr, pinned port, `hosted_roles=0`, allowed dbs only, target marker (if present), `target_sessions=0`.
3. `bootstrap-*.log`: `O_CLIENT_GENERATED … engine_sha256=a2924eab…`, `CANDIDATE_CLIENT_GENERATED … engine_sha256=a2924eab… runtime=<pinned> runtime_sha256=…`, no `provenance file missing`, bootstrap rc 0.
4. `live-etq0-*.log`: `PG17_DATABASE` identity line with `g2_s5_etq0_disposable`, `127.0.0.1`, version 170006, `super:false`, `bypassrls:true`; `Tests: 51 passed, 51 total`, `Test Suites: 1 passed`; no `PG17_TEARDOWN_SKIPPED`; jest rc 0.
5. `exit-full-*.log`: `PROOF_EXIT=0 FIRST_RC=0 STOP_RC=0 DAEMON=none SURVIVORS=none QUARANTINE=no`; launcher sentinel `FULL_EXIT=0 OUTER_BOUND=no`; no `QUARANTINE/` directory; lock holders 0 afterwards.
6. Worktree still at HEAD `98d39610`, porcelain 0, refs unchanged after the run.

A failure caused by a missing prerequisite (binaries, paths, provenance file) is a prerequisite gap to close and rerun, not a new product defect, unless the log shows an actual assertion failure inside the spec or bootstrap refusal on real fixture state.

---

## Appendix A — read-only commands used (summary)

`sha256sum -c MANIFEST.sha256`; `git rev-parse / cat-file -p / log --format / status --porcelain --untracked-files=all / for-each-ref / symbolic-ref -q / diff --stat|--numstat|--name-status / diff | sha256sum / ls-tree / show / config --local -l / bundle verify / fsck --connectivity-only / cat-file -t / merge-base --is-ancestor / rev-list --count` (all with `GIT_OPTIONAL_LOCKS=0`); `patch -p1` replay on copies in `audits/s5-b/scratch/tree/`; `diff`, `cmp`, `rg`, a Python whitespace-stripped `difflib` comparison; `stat`, `readlink`, `awk` on installed files. No `node`, `npm`, `npx`, `jest`, `prisma`, `psql`, or hook execution.

## Appendix B — files written by this reviewer

- `execution/e7d2385c/audits/s5-b/S5_REVIEW_B.md` (this review)
- `execution/e7d2385c/audits/s5-b/scratch/` (parent blobs `spec.143d`, `boot.143d`; replayed `tree/test/**`; `spec.head.ts`, `harness.head.ts`, `boot.head.sh` extracted from `HEAD:` for reading)

---

# Part 2 — appended 2026-09-23 ~20:15Z: runner/PG 17.6 preparation review and activation grantability (same review, no new cycle)

Trigger: parent notice that `execution/e7d2385c/s5-proof-preparation/` is COMPLETE (manifest `080b9574…`). Still source-read only; no runner stage, fixture, jest, npm or product action by this reviewer. Not read: `audits/s5-a/**`, parent disposition.

## 2.1 Packet and exact bytes (independently recomputed)

| Item | Observed | Match |
|---|---|---|
| `s5-proof-preparation/MANIFEST.sha256` | sha256 `080b9574a6d4cda950d16baa3f4b19c5672086c2303643b18cb6cd3201024b11`, 42 entries, `sha256sum -c` all OK | yes |
| `execution/s5-r4/run-proof.sh` | `19ab936a1562061caf4f8ee8426a5e18a998b22f3d33093a45a02b64ee3fc2c5`, mode 0755 | = checkpoint-1 SHA256SUMS |
| `execution/s5-r4/s5-fixture.sh` | `3a7d57bf951ab27e2161dc91db1d816f31d4af079ede076e7a2dfd1c44f3a721`, 0755 | = |
| `execution/s5-r4/launch-full.sh` | `a03836d524bafc28572b1e600f34148d8e9ddea38391ffc427c26f5399b9f728`, 0755 | = |
| `execution/s5-r4/npm-ci.sh` | `951c20a3…badb`, 0644 (reference only, not run) | = |
| `/home/user/pg17/dist/bin/postgres` | `23cd174849b273064c47d581b55be596be2f5cf0ee5d3e76c0146e2464bf873a` | = `PROVENANCE.txt`, = S2 (2026-09-21) and S1 R3 (2026-09-20) retrieved provenance |
| `/home/user/pg17/dist/bin/initdb` | `b7db9bc2463a4ffbe1e405977512afb50c9846fd3af2b694e315e6d5a270882a` | = all three |
| `PROVENANCE.txt` | same artifact URL, maven sha1, jar/txz sha256 as S1/S2; `server_binary=postgres (PostgreSQL) 17.6`; `result=success`; only `installed_by`/`utc`/`log` differ | yes |
| psql | `/usr/bin/psql` → `pg_wrapper` → `psql (PostgreSQL) 18.6`; runner default `G2_PG17_PSQL=/usr/bin/psql`, `-x` test passes | same client lineage as the S2 lane |
| infra scripts | `setup-10-clients.sh` zero diff vs S2; `_common.sh` and `setup-20-pg17.sh` differ only in lock/log root and `installed_by` label; setup-10/20 exits 0 | mechanical |
| Lane state | `/home/user/pg17/clusters` absent; `execution/s5-r4/{logs,QUARANTINE}` absent; canonical `execution/test-validation.lock` absent; port 54325 free; 0 postgres processes; prep lock RELEASED 20:07:25Z, fd holders 0 | clean pre-activation |
| Head after prep | `worktrees/s5-r4` HEAD `98d39610`, porcelain 0; hooks `pre-commit`/`commit-msg` unchanged; `node_modules/.package-lock.json` `05bc530a…`; sealed continuation manifest `4007b242…` re-verifies | unchanged |

Because the lane constants of the archived runner (`W`, `X`, `S`, `PG17_HOME`) coincide with this sandbox's paths, zero substitutions were needed: the runner, fixture and launcher that will execute are byte-identical to the frozen checkpoint-1 files. Prerequisites 1–3 and 5 of Part 1 §5 are therefore closed without any edit; prerequisite 4 (shallow object DB) was shown feasible by the builder's one `g2-pg17-old-root.sh create` into a scratch path (`G2_PG17_OLD_ROOT_OK`, head 925780e0, 164 migrations, 1.3 s) — a git-only step, not a proof stage; the `full` run will create its own old root at `execution/s5-r4/old-root-925780e0` (absent now).

## 2.2 Concrete-consequence assessment of the unpinned HEAD in the runner

Question: the runner records but does not refuse a HEAD other than `98d39610`. Could this make a result attributable to the wrong candidate (Class B "wrong candidate SHA audited")?

Binding actually in place at activation: (a) the worktree is at the exact head, clean, with no other authorized writer (S6 is source-only and disjoint; the single heavy slot is granted to this proof alone); (b) `stamp()` writes `HEAD/TREE/CLEAN/DIRTY_FINGERPRINT` into `env-full-<TS>.log` and `run-full-<TS>.log` at the start of the same supervised run, before any connection or mutation, under the same lock the jest child later runs under; (c) nothing in the `full` path writes tracked source (`prisma generate` writes only `node_modules/.prisma`; the old root is cloned outside `W`); (d) the post-run invariant (Part 1 §7 item 6 / activation §4 item 10) re-reads HEAD and porcelain. A wrong or dirty head would be loudly present in the run's own log rather than silently substituted, and the attestation compares that line to the pin. The failure mode a hard pin would add (an operator launching on a moved head) is already excluded by ownership and would still be caught by the stamp. Decision: **Class C** — record; no runner edit, no new control. Adding a pin would be neatness, not a change to the validity of the next decision.

## 2.3 Other points checked against actual consequence

- Password `s5_local_synthetic` is the fixture's `initdb --pwfile` literal; it passes the runner's hosted-token refusal regex and is not a secret. Runner strips all `PG*`/hosted variables before children.
- Activation `STAGE=full` is `guard → oldroot → init (fresh only) → start → preflight → bootstrap → live (51) → stop`; `init` refuses an existing data directory, so the run cannot adopt a foreign cluster; preflight enforces the 13 identity facts and `target_sessions=0`.
- psql 18.6 client against a 17.6 server via `pg_wrapper`: same combination as the executed S2 lane; wire-compatible; the runner and harness pass connection URLs explicitly, so cluster auto-selection is not involved.
- uutils `timeout --foreground --kill-after` acceptance and `setsid` group verification remain unexecuted assumptions carried from checkpoint-1 (disclosed by the builder); a failure there is visible (launcher `OUTER_BOUND_HIT` / runner `OWNED_GROUP_UNVERIFIED`) and is an evidence/prerequisite matter, not product.
- Network events during prep (apt Ubuntu archive for `postgresql-client-18`; Maven Central jar with sha1 pin and sha256 equality to S1/S2) are the reviewed setup scripts' own actions, hash-bound. Class C.
- Expected acceptance in `readiness/ACTIVATION_AND_EXPECTED_ACCEPTANCE.md` §4 matches my Part 1 §7 checklist item-for-item (51 cases are the committed spec's, not redefined).

## 2.4 Findings (Part 2)

No Class A. No Class B. Class C: C5 runner records rather than pins HEAD (bound as in §2.2); C6 prep lock/log root and `installed_by` label substitutions; C7 psql 18.6 client lineage; C8 shallow object DB (feasibility shown); C9 disclosed network events; C10 census self-match in `RUNTIME_RELEASE.txt`.

## 2.5 Verdict (Part 2) — SEALED

**Runner / substrate / activation grantability: GRANTABLE.** The exact frozen runner `19ab936a`, fixture `3a7d57bf` and launcher `a03836d5` are materialized byte-identical at the paths they hardcode; PostgreSQL 17.6 binaries are hash-identical to the S1/S2 provenance; the head is unchanged at `98d39610`/`67fc1db5`, clean, with genuine hooks and pinned dependencies; the lane is empty. The one existing fresh51 real-database proof may be activated with the recorded command (`G2_PG17_PASSWORD=s5_local_synthetic STAGE=full bash /home/user/workspace/execution/s5-r4/launch-full.sh`). No new controls, tests or harness are requested. Acceptance is the frozen Part 1 §7 checklist; anything else is a FAIL to report, not to retry.

Part 3 (actual fresh51 result attestation) will be appended to this file when the run's exit record exists.
