# FINDINGS — S6 independent reviewer A

Source-derived reachability, not runtime reproduction. Pins and review boundary are in `REPORT.md`.

## S6-A-01 — A — unmount does not invalidate a transition; an orphan persistence can write another identity's data

**Exact code:** `PersistedQueryCacheGate.tsx:79-83,91-94,101-119,124-129`: the transition counter changes only in effect setup; cleanup retires only `activeRef.current`, which is null during drain/clear, and never invalidates `isCurrent()`. [Frozen gate](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/PersistedQueryCacheGate.tsx)

**Reachable harm:** A→B enters its bounded drain with `activeRef.current = null`; if the gate unmounts then, cleanup retires nothing and the suspended body still passes `isCurrent()`, creates B's persistence, restores, and subscribes after unmount. [Frozen gate, lines 79–129](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/PersistedQueryCacheGate.tsx)

This is a real composition boundary: `BiometricUnlockGate` removes RootNavigator children while checking/locked, and its background→active reevaluation calls `setStatus('checking')`; the Day1Win early return also removes the gate. [Biometric component, lines 20–27](https://github.com/BradleyGleavePortfolio/growth-project-mobile/blob/a5933fd6de5616493de75f0db907098b149b955c/src/components/BiometricUnlockGate.tsx), [biometric hook, lines 86–118](https://github.com/BradleyGleavePortfolio/growth-project-mobile/blob/a5933fd6de5616493de75f0db907098b149b955c/src/hooks/useBiometricGate.ts), [RootNavigator, lines 810–812](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/navigation/RootNavigator.tsx)

After remount, the new gate cannot retire that old persistence; on a later committed identity C, the orphan B subscription dehydrates the shared client's C data and writes it under B's key, making a future B restore expose C data. [Gate ownership, lines 59–65 and 124–129](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/PersistedQueryCacheGate.tsx), [persistence subscription/write, lines 183–224](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/queryClient.ts)

**Decision blocked:** affected identity/cache product path and source-closure grant for this candidate.

**Minimum correction:** invalidate the transition synchronously in cleanup, so no post-unmount continuation can clear/hydrate/create a subscription; retire the persistence actually owned by that effect and retain accountability for its outstanding writes. Do not add a framework or timer masking.

**Execution unlocked:** narrow changed-source closure, then the already-requested bounded identity/lifecycle validation, including this actual interrupted-unmount boundary.

## S6-A-02 — A — signOut returns before persistence retirement/drain/final purge

**Exact code:** `authActions.ts:309-329,360-362` purges while the identity persistence is still subscribed, then settles/clears query memory and emits a fire-and-forget logout; retirement/drain occur later in `PersistedQueryCacheGate.tsx:82-108`. [Frozen signOut](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/authActions.ts), [frozen gate](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/PersistedQueryCacheGate.tsx)

**Reachable harm:** the already-scoped H3 late cache update after the first purge can start a private write because `retired` remains false; `settleAndClearQueryCache()` awaits query cancellation, not that storage write, so awaiting `signOut()` is not a completed disk-privacy boundary. [Actual-write fence and query clear, lines 183–207 and 360–381](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/queryClient.ts)

Logout emission does not await async listeners, and RootNavigator must perform three async bootstrap reads before requesting null; private bytes can therefore survive a completed signOut until the later gate purge, or longer when the gate is absent. [Auth emitter, lines 25–31](https://github.com/BradleyGleavePortfolio/growth-project-mobile/blob/a5933fd6de5616493de75f0db907098b149b955c/src/utils/authEvents.ts), [bootstrap, lines 585–601](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/navigation/RootNavigator.tsx)

**Decision blocked:** closure of the existing logout late-write/privacy hazard, not unrelated lanes.

**Minimum correction:** coordinate retirement and drain with the signOut operation itself, before its final derived-cache purge/completion, instead of relying on a later React effect; preserve existing credential, analytics, store and offline-mutation semantics.

**Execution unlocked:** the existing post-fix hazard run and truthful logout-boundary validation after narrow source review.

## S6-A-03 — B — required identity suite has concrete lifecycle and assertion defects

**Exact code and proof harm:**

- `persistedQueryCache.identityGate.test.tsx:117,133,166,192,220,245,266,295,315,378` does not await `unmount`/`rerender`; RNTL 14's implementation awaits async `act`, so assertions/timer advancement can precede the transition or overlap act scopes. [Frozen identity suite](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/__tests__/persistedQueryCache.identityGate.test.tsx), [lock-pinned RNTL archive; inspected dist/render.js:44–53 and dist/act.js:68–69](https://registry.npmjs.org/@testing-library/react-native/-/react-native-14.0.0.tgz)
- At `:397-400`, `p.restore()` schedules the actual read with `Promise.resolve().then(...)`, but the test immediately invokes `release` while it is still null; that throws before testing the restore fence. [Test, lines 390–400](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/__tests__/persistedQueryCache.identityGate.test.tsx), [restore, lines 251–258](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/queryClient.ts)
- At `:410`, fixture seeding calls the already-spied `AsyncStorage.setItem(KEY_A, ...)`; `:417` then expects all KEY_A calls to equal `[]` without clearing or baselining that fixture call, so correct retirement still fails. [Test, lines 77–83 and 406–417](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/__tests__/persistedQueryCache.identityGate.test.tsx)

**Decision blocked:** only use of the new identity suite as valid acceptance proof.

**Minimum correction:** await lifecycle helpers; wait until the deferred read has actually begun before retiring/releasing it; distinguish fixture writes from post-retirement writes. Preserve the intended assertions in the existing tests, not a new harness.

**Execution unlocked:** the existing focused identity validation can produce attributable behavioral results rather than unrelated test errors.

## C — qualify and continue

- The cold-start exception is gate-instance-local, not QueryClient-lifetime-local: a real remount resets `memoryDirtyRef` and retirement bookkeeping while the module QueryClient survives; first-mount claims must not be generalized to every remount without accounting for that state. This qualification does not independently demand another cycle beyond S6-A-01. [Gate, lines 59–70 and 101–105](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/PersistedQueryCacheGate.tsx)
- A→B→A with an old timed-out write reuses the same key, and its unconditional late `removeItem(k)` can erase newer A derived-cache bytes; this is not demonstrated cross-identity exposure or canonical-data loss and is recorded as C, not another blocker. [Write cleanup, lines 174–194](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/queryClient.ts)
- Observer detachment removes query membership but does not itself rebind a still-mounted above-gate observer; reattachment depends on a later observer update/render, so the lifecycle claim is narrower than “all observers immediately reattach.” No independent customer harm is asserted for ThemeProvider from this fact alone. [Query removal and observer update; inspected query.ts:362–380 and queryObserver.ts:703–719](https://registry.npmjs.org/@tanstack/query-core/-/query-core-5.100.14.tgz)
- “Mutations are never persisted” is not established: the unchanged default dehydrate predicate includes paused mutations, whereas the candidate explicitly overrides only the query predicate; this is an inherited semantic qualification, not authority to alter offline mutations. [Candidate subscription, lines 217–224](https://github.com/BradleyGleavePortfolio/tgp-private-evidence/blob/cc62002bfd08c3cb677025b651965d36e6a1aaec/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/src/services/queryClient.ts), [pinned hydration.ts:125–150](https://registry.npmjs.org/@tanstack/query-core/-/query-core-5.100.14.tgz)
