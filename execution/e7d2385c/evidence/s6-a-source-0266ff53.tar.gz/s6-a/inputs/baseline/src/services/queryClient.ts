// React Query client configuration.
//
// We picked tanstack/react-query as the data layer for the API-first migration
// (Fix #2) for three reasons:
//
//   1. Caching + automatic background revalidation give us the "feels native"
//      offline experience the audit asked for without us hand-rolling a
//      sync engine. A user opening their Habits screen sees the last cached
//      list immediately while a fresh fetch runs in the background.
//
//   2. Mutations + automatic invalidation mean a coach posting a new nudge
//      and a client opening their Notifications screen see consistent state
//      with one line of `queryClient.invalidateQueries`. Previously every
//      screen wrote to its own SQLite table and there was no way to keep
//      two surfaces in sync.
//
//   3. Centralized retry policy. Network blips on a phone are normal; we
//      retry idempotent reads twice with exponential backoff and no retry
//      on mutations (the api.ts interceptor already coalesces 401s and
//      handles refresh).
//
// The defaults below intentionally err toward fewer network calls because
// the user base is mobile and metered. Screens that need always-fresh data
// can opt in per-query with `refetchOnWindowFocus: true` and shorter
// staleTime — see HabitsScreen for an example.

import { QueryClient } from '@tanstack/react-query';
import { createAsyncStoragePersister } from '@tanstack/query-async-storage-persister';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { readUserCacheSync } from '../lib/userCache';

function getHttpStatus(err: unknown): number | undefined {
  return (err as { response?: { status?: number } })?.response?.status;
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // 30s is the sweet spot for "fresh enough that opening the same screen
      // twice in 30s doesn't refetch" but "stale enough that a cold open
      // after a few minutes pulls fresh server state."
      staleTime: 30_000,
      // Keep cached data 10 minutes after the last subscriber unmounts so
      // tab-switching back to a screen is instant.
      gcTime: 10 * 60_000,
      // Mobile-first: do not auto-refetch on window focus. RN re-mounts on
      // focus already and we don't want a screen tab swipe to fire a fan-out.
      refetchOnWindowFocus: false,
      retry: (failureCount: number, error: unknown) => {
        if (getHttpStatus(error) === 402) return false;
        return failureCount < 2;
      },
      retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 8000),
    },
    mutations: {
      // Mutations should not retry blindly — the user already saw the spinner
      // resolve and a silent re-attempt could double-create rows. Callers can
      // override per-mutation when truly idempotent.
      retry: false,
    },
  },
});

/**
 * AsyncStorage-backed persister for the React Query cache.
 *
 * Why we persist the cache:
 *   On a cold start the user opens the app and we have to wait for the network
 *   round-trip before showing anything. With persistence, we hydrate the cache
 *   from disk synchronously-ish on boot and the first paint shows last-known
 *   data while a fresh fetch runs in the background. That's the felt-native
 *   experience the audit asked for and what enterprise apps (Linear, Things,
 *   Cash App) all do under the hood.
 *
 * What we DON'T persist:
 *   Mutations are intentionally not persisted. A pending mutation surviving
 *   an app restart could double-create rows (e.g. a workout logged twice if
 *   the user force-quit mid-network). Re-issuing those is the queue's job
 *   (foodLogQueue.ts), not the query cache's.
 *
 * Cache TTL:
 *   24h max age. Anything older is treated as cold and refetched on first
 *   subscribe. This bounds the staleness window for users who open the app
 *   once a week without ever connecting.
 *
 * R15: the persister key is namespaced by authenticated user id so a shared
 * device cannot hydrate user A's cache into user B's session. The id is read
 * synchronously from MMKV on module load; an anonymous (logged-out) cold
 * start uses ':anonymous', which is wiped on the next sign-in.
 */
export const QUERY_CACHE_KEY_PREFIX = 'TGP_RQ_CACHE_V1';

export function persisterKeyForUser(userId: string | null | undefined): string {
  const suffix = userId && userId.trim() ? userId : 'anonymous';
  return `${QUERY_CACHE_KEY_PREFIX}:${suffix}`;
}

function resolveBootUserId(): string | null {
  try {
    return readUserCacheSync()?.id ?? null;
  } catch {
    return null;
  }
}

// S6 R3 assessment (identity mirror): readUserCacheSync() is now a truthful
// in-process mirror that is null until lib/userCache has hydrated. This module
// is evaluated at import time, BEFORE any hydration, so on every AsyncStorage-
// shim build resolveBootUserId() is null and the persister key is always
// ':anonymous' for the whole process lifetime (identical to the pre-R3
// observable behaviour, where the shim's synchronous read was always
// undefined). The per-user namespacing therefore does not protect anything on
// shim builds; isolation rests entirely on purgePersistedQueryCacheForAllUsers()
// (every sign-in and sign-out) plus queryClient.clear() on sign-out. Fixing
// that requires re-creating the persister after hydration / on identity
// change (App.tsx PersistQueryClientProvider composition), which is outside
// the R3 identity/cache/pairing boundary and is reported for re-scope rather
// than widened here.
//
// NOTE (P1-1): the persister key is resolved ONCE at module load time
// (via resolveBootUserId()) and cannot be swapped after construction.
// This means that after an in-session account switch the persister
// continues writing under the boot-time user's key, not the newly
// signed-in user's key. To compensate, every sign-in path calls
// purgePersistedQueryCacheForAllUsers() immediately after setUserCache()
// so any orphan blob at a stale key is removed before the first
// persistence pass for the new user. See src/screens/auth/LoginScreen.tsx,
// CreateAccountScreen.tsx, and RoleSelectionScreen.tsx.
export const asyncStoragePersister = createAsyncStoragePersister({
  storage: AsyncStorage,
  key: persisterKeyForUser(resolveBootUserId()),
  // Throttle disk writes so heavy cache churn doesn't hammer AsyncStorage.
  throttleTime: 1000,
});

/**
 * Remove every persisted React Query cache key from AsyncStorage. Used on
 * sign-out to honor R15: a shared device must not retain user A's cache into
 * user B's session, even at a stale legacy key. Also wipes the legacy
 * unsuffixed key from pre-R15 builds.
 */
export async function purgePersistedQueryCacheForAllUsers(): Promise<void> {
  try {
    const allKeys = await AsyncStorage.getAllKeys();
    const matching = allKeys.filter(
      (k) => k === QUERY_CACHE_KEY_PREFIX || k.startsWith(`${QUERY_CACHE_KEY_PREFIX}:`),
    );
    if (matching.length) await AsyncStorage.removeMany(matching);
  } catch {
    // Non-fatal: the persister will hydrate empty on next sign-in.
  }
}

export const QUERY_CACHE_MAX_AGE = 24 * 60 * 60 * 1000; // 24 hours

