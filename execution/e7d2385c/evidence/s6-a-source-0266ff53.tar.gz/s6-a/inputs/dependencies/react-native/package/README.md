<div align="center">
  <a href="https://www.callstack.com/open-source?utm_campaign=generic&utm_source=github&utm_medium=referral&utm_content=react-native-testing-library" align="center">
    <img src="https://github.com/user-attachments/assets/4d452312-4ffd-4439-855f-a9b12ad7d6c2" alt="React Native Testing Library" />
  </a>
  <p align="center">Developer-friendly and complete React Native testing utilities that encourage good testing practices.</p>
</div>

[![Version][version-badge]][package]
[![Build Status][build-badge]][build]
[![Code Coverage][coverage-badge]][coverage]
[![Downloads][downloads-badge]][downloads]
[![MIT License][license-badge]][license]
[![Sponsored by Callstack][callstack-badge]][callstack]

## The problem

You want to write maintainable tests for your React Native components. Your tests should avoid implementation details and focus on giving you confidence. They should remain maintainable so refactors (changes to implementation but not functionality) don't break your tests and slow you and your team down.

## This solution

The React Native Testing Library (RNTL) tests React Native components. It simulates the React Native runtime on top of [Test Renderer](https://github.com/mdjastrzebski/test-renderer) and encourages better testing practices. Its primary guiding principle is:

> The more your tests resemble the way your software is used, the more confidence they can give you.

This project is inspired by [React Testing Library](https://github.com/testing-library/react-testing-library). Tested to work with Jest, but it should work with other test runners as well.

## Installation

Open a Terminal in your project's folder and run:

```sh
npm install --save-dev @testing-library/react-native
```

This library has a `peerDependencies` listing for [Test Renderer](https://github.com/mdjastrzebski/test-renderer). Make sure to install it as a dev dependency:

```sh
npm install --save-dev test-renderer
```

### Additional Jest matchers

You can use the built-in Jest matchers automatically by having any import from `@testing-library/react-native` in your test.

## Example

```jsx
import { render, screen, userEvent } from '@testing-library/react-native';
import { QuestionsBoard } from '../QuestionsBoard';

test('form submits two answers', async () => {
  const questions = ['q1', 'q2'];
  const onSubmit = jest.fn();

  const user = userEvent.setup();
  await render(<QuestionsBoard questions={questions} onSubmit={onSubmit} />);

  const answerInputs = screen.getAllByLabelText('answer input');

  // simulates the user focusing on TextInput and typing text one char at a time
  await user.type(answerInputs[0], 'a1');
  await user.type(answerInputs[1], 'a2');

  // simulates the user pressing on any pressable element
  await user.press(screen.getByRole('button', { name: 'Submit' }));

  expect(onSubmit).toHaveBeenCalledWith({
    1: { q: 'q1', a: 'a1' },
    2: { q: 'q2', a: 'a2' },
  });
});
```

You can find the source of `QuestionsBoard` component and this example [here](https://github.com/callstack/react-native-testing-library/blob/main/src/__tests__/questionsBoard.test.tsx).

## API / Usage

React Native Testing Library consists of following APIs:

- [`render` function](https://oss.callstack.com/react-native-testing-library/docs/api/render) - render your UI components for testing purposes
- [`screen` object](https://oss.callstack.com/react-native-testing-library/docs/api/screen) - access rendered UI:
  - [Queries](https://oss.callstack.com/react-native-testing-library/docs/api/queries) - find rendered components by various predicates: role, text, test ids, etc
  - Lifecycle methods: [`rerender`](https://oss.callstack.com/react-native-testing-library/docs/api/screen#rerender), [`unmount`](https://oss.callstack.com/react-native-testing-library/docs/api/screen#unmount)
  - Helpers: [`debug`](https://oss.callstack.com/react-native-testing-library/docs/api/screen#debug), [`toJSON`](https://oss.callstack.com/react-native-testing-library/docs/api/screen#tojson), [`root`](https://oss.callstack.com/react-native-testing-library/docs/api/screen#root), [`container`](https://oss.callstack.com/react-native-testing-library/docs/api/screen#container)
- [Jest matchers](https://oss.callstack.com/react-native-testing-library/docs/api/jest-matchers) - validate assumptions about your UI
- [User Event](https://oss.callstack.com/react-native-testing-library/docs/api/events/user-event) - simulate common user interactions like [`press`](https://oss.callstack.com/react-native-testing-library/docs/api/events/user-event#press) or [`type`](https://oss.callstack.com/react-native-testing-library/docs/api/events/user-event#type)
- [Fire Event](https://oss.callstack.com/react-native-testing-library/docs/api/events/fire-event) - simulate any component event
- [`renderHook` function](https://oss.callstack.com/react-native-testing-library/docs/api/misc/render-hook) - render hooks for testing purposes
- Miscellaneous APIs:
  - [Async utils](https://oss.callstack.com/react-native-testing-library/docs/api/misc/async): `findBy*` queries, `waitFor`, `waitForElementToBeRemoved`
  - [Configuration](https://oss.callstack.com/react-native-testing-library/docs/api/misc/config): `configure`, `resetToDefaults`
  - [Accessibility](https://oss.callstack.com/react-native-testing-library/docs/api/misc/accessibility): `isHiddenFromAccessibility`
  - [Other](https://oss.callstack.com/react-native-testing-library/docs/api/misc/other): `within`, `act`, `cleanup`

## Migration Guides

- **[Migration to 14.0](https://oss.callstack.com/react-native-testing-library/docs/start/migration-v14)** - Drops React 18, async APIs by default

## Troubleshooting

- [Troubleshooting guide](https://oss.callstack.com/react-native-testing-library/docs/guides/troubleshooting)

## Community Resources

Check out our list of [Community Resources about RNTL](https://oss.callstack.com/react-native-testing-library/docs/guides/community-resources).

## Made with ❤️ at Callstack

React Native Testing Library is an open source project and will always remain free to use. If you think it's cool, please star it 🌟. [Callstack](https://callstack.com) is a group of React and React Native geeks, contact us at [hello@callstack.com](mailto:hello@callstack.com) if you need any help with these or just want to say hi!

Like the project? ⚛️ [Join the team](https://callstack.com/careers/?utm_campaign=Senior_RN&utm_source=github&utm_medium=readme) who does amazing stuff for clients and drives React Native Open Source! 🔥

---

Supported and used by [Rally Health](https://www.rallyhealth.com/careers).

<!-- badges -->

[version-badge]: https://img.shields.io/npm/v/@testing-library/react-native.svg?style=flat-square
[package]: https://www.npmjs.com/package/@testing-library/react-native
[build-badge]: https://github.com/callstack/react-native-testing-library/actions/workflows/ci.yml/badge.svg
[build]: https://github.com/callstack/react-native-testing-library/actions/workflows/ci.yml
[coverage-badge]: https://img.shields.io/codecov/c/github/callstack/react-native-testing-library.svg
[coverage]: https://codecov.io/github/callstack/react-native-testing-library
[downloads-badge]: https://img.shields.io/npm/dm/@testing-library/react-native.svg?style=flat-square
[downloads]: http://www.npmtrends.com/@testing-library/react-native
[license-badge]: https://img.shields.io/npm/l/@testing-library/react-native.svg
[license]: https://opensource.org/licenses/MIT
[callstack-badge]: https://callstack.com/images/callstack-badge.svg
[callstack]: https://callstack.com/open-source/?utm_source=github.com&utm_medium=referral&utm_campaign=react-native-testing-library&utm_term=readme
