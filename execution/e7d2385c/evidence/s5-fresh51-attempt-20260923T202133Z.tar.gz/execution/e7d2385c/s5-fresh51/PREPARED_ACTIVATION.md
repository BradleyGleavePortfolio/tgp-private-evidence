# S5 fresh51 — prepared activation (WAITING for parent one-line runtime transfer; NOTHING started)

Executor: s5_exact_candidate_continuation (T4, requested Claude Fable 5 / High). Authority: `execution/e7d2385c/S5_FRESH51_ACTIVATION.md`; reviewer A `audits/s5-a/ACTIVATION_ATTESTATION.md`; reviewer B `audits/s5-b/S5_REVIEW_B.md` Part 2. Frozen acceptance: `s5-proof-preparation/readiness/ACTIVATION_AND_EXPECTED_ACCEPTANCE.md` §4 with A's C2 qualification (creation of `execution/s5-r4/old-root-925780e0` checkout, its package manifests and shared node_modules symlink is EXPECTED; the invariant is no drift in the other npm roots and O matching its pinned rules).

## The one command (to be run exactly once, after transfer; ordinary non-interactive bash)
    G2_PG17_PASSWORD=s5_local_synthetic STAGE=full bash /home/user/workspace/execution/s5-r4/launch-full.sh

## Immediate preconditions re-read right before launch (read-only; no census duplication beyond these)
- `git -C worktrees/s5-r4 rev-parse HEAD` == 98d39610f511505558373f3a59fa019804c94bd7; porcelain empty
- sha256 run-proof.sh 19ab936a… / s5-fixture.sh 3a7d57bf… / launch-full.sh a03836d5…
- /home/user/pg17/clusters/s5 ABSENT; execution/s5-r4/QUARANTINE ABSENT; execution/test-validation.lock not held
- parent transfer message received (never inferred)

## Observation plan (no interference with the launcher/runner)
- Record START ownership line in `s5-fresh51/OWNERSHIP.txt`; capture launcher stdout (`launched: pid=… sentinel=… log=…`).
- Wait by polling the sentinel file `execution/s5-r4/logs/full-<TS>.sentinel` (sleep loop, bounded by the launcher's own outer bound 1740 s + 120 s + margin); never signal, never touch the lock, never start a second runner.
- Read only: `execution/s5-r4/logs/{full-<TS>.launcher.log, run-full-<TS>.log, env-full-<TS>.log, exit-full-<TS>.log, preflight-full-<TS>.log, guard-unit-*.log, oldroot-*.log, fixture-*.log, bootstrap-*.log, live-etq0-*.log}`, `execution/test-validation.lock.log`.
- Post-run identity re-read (HEAD/porcelain/hooks/node_modules record/postmaster.pid absence/QUARANTINE absence/process census).

## Receipt outputs (all under execution/e7d2385c/s5-fresh51/)
OWNERSHIP.txt, LAUNCH.stdout, RESULT_SUMMARY.txt (verbatim key lines with paths+sha256 of every runner log), POSTRUN_IDENTITY.txt, RECEIPT.md, RUNTIME_RELEASE.txt, MANIFEST.sha256 (non-self-including; runner logs stay in place under execution/s5-r4/logs and are listed by path+hash).

## Rules carried
Any refusal/failure/timeout/survivor/mismatch is recorded as observed; no retry/resume/reset/destroy; stopped disposable fixture retained; no product or private remote write; slot released after the runner's terminal cleanup, with release line.
