#!/usr/bin/env bash
# S6-P3 validation/commit step runner = sealed s6-preparation/steps/step.sh with ONLY constant substitutions:
#   O -> execution/e7d2385c/s6-p3-validation-result (fresh; refuse if it exists before step 00)   P -> execution/e7d2385c/s6-p3-validation   W -> worktrees/s6-p2 (installed)   label -> S6-P3 slot-V
#   ctree() unchanged (same nine candidate paths; scratch index under $O; real .git/index untouched until step 20).
# NOT EXECUTED during preparation (bash -n only). Usage: step.sh NN label T offline(0|1) workdir cmdfile [postfile]
# NOT EXECUTED during preparation (no bash -n either). Usage: step.sh NN label T offline(0|1) workdir cmdfile [postfile]
NN=$1; label=$2; T=$3; offline=$4; workdir=$5; cmdfile=$6; postfile=${7:-}
O=/home/user/workspace/execution/e7d2385c/s6-p3-validation-result
P=/home/user/workspace/execution/e7d2385c/s6-p3-validation
W=/home/user/workspace/worktrees/s6-p2
HZ=/home/user/workspace/execution/e7d2385c/s6-inputs/2026-09-22/op88/remediation/s6-c6-prep/c6/inputs
LOCK=/home/user/workspace/execution/test-validation.lock
export GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 CI=1 NODE_OPTIONS=--max-old-space-size=2048 TZ=UTC npm_config_update_notifier=false npm_config_fund=false npm_config_audit=false CHECKPOINT_DISABLE=1
export EXPO_PUBLIC_FF_EXTENSION_IMPORT= EXPO_PUBLIC_FF_IMPORT_REVIEW=
if [ "$offline" = 1 ]; then export npm_config_offline=true; else unset npm_config_offline; fi
export O P W HZ
ctree() { local ix=$O/scratch/ctree.index; mkdir -p "$O/scratch"; rm -f "$ix"; GIT_INDEX_FILE=$ix git -C "$W" read-tree HEAD && GIT_INDEX_FILE=$ix git -C "$W" add -A -- App.tsx src/navigation/RootNavigator.tsx src/services/__tests__/queryClient.persister.test.ts src/services/__tests__/queryClient.signout.test.ts src/services/authActions.ts src/services/queryClient.ts src/services/PersistedQueryCacheGate.tsx src/services/__tests__/persistedQueryCache.identityGate.test.tsx src/__tests__/rootNavigatorPersistedCacheGate.test.tsx && GIT_INDEX_FILE=$ix git -C "$W" write-tree; }
export -f ctree
LOG="$O/logs/$NN-$label.log"; CMD=$(cat "$cmdfile")
cd "$workdir" || exit 70
exec 9>"$LOCK"; flock -n 9 || { echo "lock held; not waiting" | tee -a "$LOG"; echo "step_status=75" >> "$LOG"; exit 75; }
echo "S6-P3 slot-V $label pid=$$ start=$(date -u +%FT%TZ)" >> "$LOCK.holders"
{ echo "label=$label head=$(git -C $W rev-parse HEAD) candidate_tree=$(ctree) status_pin=$(git -C $W status --porcelain | tr '\n' ';') node=$(node -v) npm=$(npm -v) NODE_OPTIONS='${NODE_OPTIONS:-}' npm_config_offline='${npm_config_offline:-}' CHECKPOINT_DISABLE='${CHECKPOINT_DISABLE:-unset}' GIT_OPTIONAL_LOCKS='${GIT_OPTIONAL_LOCKS:-unset}' cwd=$PWD T=$T loadavg='$(cat /proc/loadavg)' mem_avail_mb=$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo) utc=$(date -u +%FT%TZ)"; echo "cmd: $CMD"; } > "$LOG"
if [ "${CHECKPOINT_DISABLE:-unset}" != 1 ]; then echo "STOP: CHECKPOINT_DISABLE unset" >> "$LOG"; echo "step_status=78" >> "$LOG"; flock -u 9; exit 78; fi
timeout --kill-after=30 "$T" bash -c "$CMD" >> "$LOG" 2>&1; rc=$?
echo "exit=$rc (124=timeout,137=killed) utc=$(date -u +%FT%TZ) candidate_tree_after=$(ctree) status_after=$(git -C $W status --porcelain | tr '\n' ';')" >> "$LOG"
final=$rc
if [ -n "$postfile" ]; then
  echo "== post-conditions (each line: postcheck rc); raw exit=$rc kept separate" >> "$LOG"
  RAW_RC=$rc bash "$postfile" >> "$LOG" 2>&1; prc=$?
  echo "postchecks_exit=$prc" >> "$LOG"; [ "$prc" -eq 0 ] || final=$prc
fi
echo "step_status=$final utc=$(date -u +%FT%TZ)" >> "$LOG"
echo "S6-P3 slot-V $label pid=$$ exit=$rc step_status=$final end=$(date -u +%FT%TZ)" >> "$LOCK.holders"
flock -u 9
exit "$final"
