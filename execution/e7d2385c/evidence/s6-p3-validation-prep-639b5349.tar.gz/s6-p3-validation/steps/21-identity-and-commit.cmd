git config --local user.name 'Bradley Gleave' && git config --local user.email 'bradley@bradleytgpcoaching.com'
A=$(git var GIT_AUTHOR_IDENT | sed -E 's/ [0-9]+ [+-][0-9]{4}$//'); C=$(git var GIT_COMMITTER_IDENT | sed -E 's/ [0-9]+ [+-][0-9]{4}$//')
echo "GIT_AUTHOR_IDENT=$A"; echo "GIT_COMMITTER_IDENT=$C"
[ "$A" = 'Bradley Gleave <bradley@bradleytgpcoaching.com>' ] && [ "$C" = 'Bradley Gleave <bradley@bradleytgpcoaching.com>' ] || { echo "identity mismatch; not committing"; exit 91; }
[ "$(git write-tree)" = 93ed7cfc4d0b8095148e0020ca40f901833595f6 ] || { echo "staged tree drifted; not committing"; exit 92; }
[ "$(sha256sum $P/steps/21-commit-message.txt | cut -c1-64)" = 4ac2840e04573a0ba66afa9ad9d35d6d44272beb908f6867e0caaff7f94507ee ] || { echo "message file hash mismatch; not committing"; exit 93; }
echo "hooks about to run: [$(ls .git/hooks | grep -v '\.sample$' | tr '\n' ' ')] core.hooksPath=[$(git config --get core.hooksPath)] (repo defines no hook policy: no husky/lefthook/lint-staged/prepare at d51a1910; expected empty)"
git commit -F - < $P/steps/21-commit-message.txt
