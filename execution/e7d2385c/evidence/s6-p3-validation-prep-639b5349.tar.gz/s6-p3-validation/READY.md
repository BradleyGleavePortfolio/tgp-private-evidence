# S6-P3 bounded validation + true-hooked local commit — READY (constant bindings only; NOT executed; awaiting parent runtime activation after both P3 verdicts and S5 release)

Prepared 2026-09-23T20:23:43Z. Source: sealed `s6-preparation/steps/**` (manifest d94c80b7) + `s6-p3/P3_VALIDATION_BINDINGS.md`. Delta = `steps.diff-vs-sealed-prep` (95 lines, 12 files; only: O/P/W/label constants, tree pin 845d83ad→**93ed7cfc**, candidate cmp reference → `s6-p3/candidate/`, packet manifest check → s6-p3 `4f993b98…`, step 22 nine-blob/numstat strings → d51→P3 values, bundle name s6-p3-hooked, commit message + its hash guard). No runner/harness/postcheck logic changed; `bash -n` only. Pins: `STEPS.sha256` (26 files).

## Worktree state (log `logs/P0-apply-p2-to-p3.txt`)
`worktrees/s6-p2`: HEAD d51a1910, frozen `p2-to-p3.patch` (493a3ba2) applied via `git apply` (no authored edit, no object/commit), **candidate tree 93ed7cfc4d0b8095148e0020ca40f901833595f6**, 9/9 files == `s6-p3/candidate`, 8/8 non-test files identical to frozen P2, identityGate blob 24640114, porcelain 9, index at HEAD (unchanged 9ff042e7), refs 2, hooks 0, identity unset, node_modules 701 (setup packet 1244063a, 20/20 module pins), lock 840be0b8.

## Steps (`bash $P/steps/step.sh NN label T offline W $P/steps/NN-label.cmd [.post]`; `P=execution/e7d2385c/s6-p3-validation`, `W=worktrees/s6-p2`, `O=execution/e7d2385c/s6-p3-validation-result` must NOT exist before step 00; `mkdir -p $O/logs` first)
| NN | label | T | offline | expected raw | expected postchecks |
|---|---|---|---|---|---|
| 00 | pins | 60 | 1 | 0 `PINS_OK` | tree 93ed7cfc, nine lines, 9 cmp vs s6-p3/candidate, P3 packet manifest 4f993b98, hazard/adapter hashes, node_modules+jest+tsc present, hooks 0 |
| 01 | typecheck | 900 | 1 | 0 | 0 `error TS`, tree unchanged |
| 02 | identity-gate-suite | 600 | 1 | 0 | `Tests: 19 passed, 19 total` (static), no FAIL/skipped/forceExit/did-not-exit |
| 03 | rootnav-gate-suite | 300 | 1 | 0 | 4 passed |
| 04 | persister-suite | 180 | 1 | 0 | 5 passed |
| 05 | signout-suite | 180 | 1 | 0 | 4 passed |
| 06 | regression-suites | 600 | 1 | 0 | `Test Suites: 5 passed`, 25 passed |
| 07 | place-hazard | 30 | 1 | 0 | two hash-guarded copies placed, porcelain 11 |
| 08 | hazard-postfix | 240 | 1 | **1** | `[mode=postfix-gate]`, `Tests: 3 failed, 3 passed, 6 total`, ✓ T-WIRING/T0/T4, ✕ T1 :188: / T2 :208: (not :205:) / T3 :240: (not :224:) |
| 09 | remove-hazard | 30 | 1 | 0 | copies removed, porcelain 9, tree 93ed7cfc |
| — | parent decision on 00–09 results | | | | |
| 20 | stage-nine | 30 | 1 | 0 | real-index write-tree 93ed7cfc |
| 21 | identity-and-commit | 300 | 1 | 0 | repo-local Bradley identity → `git var` check (91) → tree guard (92) → message hash guard (93, `21-commit-message.txt` sha256 4ac2840e04573a0ba66afa9ad9d35d6d44272beb908f6867e0caaff7f94507ee — **PROPOSED text; parent approval required**) → prints configured hooks (truthfully expected: none) → plain `git commit -F -` |
| 22 | post-commit-identity | 30 | 1 | 0 | %T 93ed7cfc, %P d51, author=committer Bradley, no trailers, exact nine blobs + numstat (d51→P3), refs unchanged, porcelain 0 |
| 23 | bundle | 60 | 1 | 0 | `s6-p3-hooked-<8hex>-from-public-a5933fd6.bundle` verify/list-heads/sha256 |

## Launch method (persistent; observes actual child status — replaces the supervisor-returning inline `nohup … &` that lost the S1 setup wrapper's exit record)
```
setsid -f bash $P/steps/step.sh NN label T 1 /home/user/workspace/worktrees/s6-p2 $P/steps/NN-label.cmd [$P/steps/NN-label.post] > $O/logs/NN.launcher.out 2>&1 < /dev/null
# poll (separate tool calls): until grep -q '^step_status=' $O/logs/NN-label.log; tail -3 $O/logs/NN-label.log; tail -1 /home/user/workspace/execution/test-validation.lock.holders
```
`setsid -f` detaches into its own session so the tool supervisor's return does not terminate the step; the step's own `exit=`/`step_status=` lines and the `.holders` end line are the actual-status record; steps are serialized (next launched only after the previous `step_status=0`, except 08 where raw 1 with the expected postchecks is the pass). Harness itself unchanged.

## Concrete execution prerequisites — none missing except grants
Present: installed node_modules (701; jest 29.7.0, tsc 6.0.3, jest-expo 56.0.4), `taskset/timeout/flock/setsid`, node v20.20.1, W bound with P3 bytes, `O` absent, hooks 0, identity unset, hazard inputs read-only at HZ. Required from parent: (a) both P3 verdicts + runtime activation, (b) S5 slot release (canonical lock free at 20:2xZ per one `flock -n` probe — recorded as a deviation; no further probes), (c) approval of the proposed commit-message text (or a replacement file + rebinding its hash in step 21). No install, upgrade, or harness change needed. Stop rules/write set/privacy as in the sealed P1 request.
