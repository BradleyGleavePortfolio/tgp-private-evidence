# S6 P3 review B — test-only delta follow-up (source phase)

Reviewer: independent nonbuilder B. Scope per parent: P2→P3 changed test bytes (S6-A-P2-B04 closure) and exact-tree/pin derivation only. Static copy/diff/hash inspection; no runtime, install, hook, candidate or worktree write. Builder's closure map read as input and re-derived from bytes; peer P3 conclusions not read. P1/P2 packets and the P2 reachability addendum unchanged.

## 1. Pins re-derived

| Item | Value | Verification |
|---|---|---|
| Sealed P3 packet | `s6-p3/MANIFEST.sha256` sha256 `4f993b98d45f8e49cf65a75b29b8da82a8a7189de8e9a3e69f81e97917fd1c26`, 20/20 OK | own `sha256sum -c` |
| `p2-to-p3.patch` | `493a3ba2c2d3a07c197191491a30b547f10ff62b2d0fce804d6a7a4d532e9f92`; one file; applied by me to a temp copy of the frozen P2 test → byte-identical to `s6-p3/candidate/...identityGate.test.tsx` | `p3/verify-p3-bytes.txt` |
| Changed blob | identityGate test P2 `5192c842…` → P3 **`24640114cd391d7b658d8df8fe111f52e1327c46`** (file sha256 `62a02340…`); +22 −12; `it(` count 19 | own `git hash-object` (no `-w`) and count |
| Eight other files | `cmp` identical to frozen P2 `candidate/` (no product byte changed) | same log |
| **P3 candidate tree** | **`93ed7cfc4d0b8095148e0020ca40f901833595f6`** — re-derived by pure SHA-1 hashing from `ls-tree -r d51` plus the nine `s6-p3/candidate` blobs, no object written | `p3/tree-rederivation.txt` |
| Live `worktrees/s6-p2` (observation only, S5-owned) | at 20:23Z all nine paths `cmp` identical to `s6-p3/candidate`; porcelain still nine lines; `node_modules` present | same log |
| Unchanged pins | lock `840be0b8…`, hazard `a91bb732…`, adapter `3796be8f…` not in diff | — |

## 2. Verdict

**SOURCE CLOSED — GRANTABLE for the bounded validation with P3 bindings.** No A, no B; two C. The B04 test-mechanics defect is closed by the changed bytes; product-path conclusions (P1, P2 A01/A02 closures) transfer unchanged because no product byte changed; my P2 reachability disposition (S6-B-P2-01 = conditional C) carries forward.

## 3. B04 closure — own mechanics trace

Pinned dependencies (read from the dependency source copies in `audits/s6-a/P2_inputs/dependencies`, not from peer conclusions): `@react-native-async-storage/async-storage@3.1.1` jest mock (`src/jest/AsyncStorageMock.ts`) exposes `getItem`/`setItem` as plain arrow-function instance fields over a `Map` — not `jest.fn`. `jest-mock@29.7.0` `spyOn` (`build/index.js:737`) wraps a non-mock original in a new mock and assigns it to the object; if the property is already a mock it returns it unchanged.

- **Re-entry defect closed.** `realGetItem`/`realSetItem` are now bound in `beforeEach` (`:88-89`) *before* `jest.spyOn` (`:90-91`), so they reference the underlying Map-backed functions. Every per-test `realGet`/`realSet` (`:161,214,242,288,326,403,445,484,506,530`) is assigned from those; no `.bind(AsyncStorage)` remains outside `beforeEach` (line 77 is a comment). `afterEach` calls `jest.restoreAllMocks()` (`:100`), restoring the plain functions, so the next `beforeEach` capture is again the real implementation and `spyOn` creates a fresh mock with empty `mock.calls` — the pre-spy capture stays valid across all 19 tests.
- **Second unreleased wait closed.** Unit test `:445-449` holds only while `release === null`; after the ≤10-microtick wait and `release()`, the delegated read resolves through the real store, `restore()` returns `'retired'` at its fence without hydrating. The timeout unit test (`:484-487`) keeps an unguarded hold but performs exactly one KEY_A read, so no second wait is armed; all other held implementations are `!release`-guarded.
- **Fixture-seed baseline closed.** A01 regression: `seededWrites` captured after the two seeds (`:321`); assertion uses `slice(seededWrites)` (`:351`). The `getItemSpy` KEY_B assertions (`:346,350`) precede the only KEY_B read (`blobQueries`, after them). Trace on P2/P3 product bytes: A committed without a mount write (fresh hydrated data), first KEY_A write held, B suspended in drain, unmount bumps `transitionRef`, released write lands on its own key (`drainTimedOut` false), body exits at the post-drain checkpoint, later cache event reaches no subscriber. Passes by source reasoning on P2/P3 product bytes; would fail on P1 product bytes (KEY_B read after drain) — still discriminating.
- No delay, release, assertion or test was added or removed; the `afterEach` anonymous-key criterion is unchanged. Nothing else in the file changed (patch hunks enumerated above).

## 4. Transfer of unchanged conclusions
Eight files byte-identical to P2 → P2_REPORT §3 (A01 orphan mechanism, A02, hazard expectations §4) and P1 lifecycle/preservation conclusions apply verbatim. S6-B-P2-01 stays conditional C per `P2_REACHABILITY_DISPOSITION.md`. Expected counts: identityGate 19, signout 4, rootNavGate 4, persister 5, regression 5 suites; hazard 3 failed/3 passed with T1 `:188`, T2 `:208`, T3 `:240`.

## 5. Setup provenance (parent-reported, not verified here)
One `npm ci` completed with exit 0 and 13/13 post-checks but the wrapper's raw exit record is missing because the supervisor killed the wrapper. Recorded as a provenance qualification of the environment, not as product evidence; no rerun requested by this review; the later runtime/head attestation must cite whatever raw evidence exists and state the gap.

## 6. Owned outputs
`P3_REPORT.md`, `P3_FINDINGS.md`, `p3/verify-p3-bytes.txt`, `p3/tree-rederivation.txt`, `MANIFEST.p3.sha256` (non-self-including). Earlier packets untouched.
