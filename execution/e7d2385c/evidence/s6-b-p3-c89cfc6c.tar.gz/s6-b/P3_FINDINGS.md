# S6 P3 review B — findings (P2→P3 test-only delta)

Scope: `p2-to-p3.patch` `493a3ba2…` (one file, identityGate suite, blob `24640114…`); tree `93ed7cfc…`. **A: 0. B: 0. C: 2.**

## Class A
None (no product byte changed; P1/P2 product conclusions and the P2 reachability disposition carry forward).

## Class B
None. S6-A-P2-B04 closed: pre-spy capture of the underlying mock functions in `beforeEach` (`:88-89`) with `restoreAllMocks` in `afterEach` (`:100`); all ten delegates re-pointed (`:161,214,242,288,326,403,445,484,506,530`); first-read-only hold in the deferred-read unit test (`:445-449`); fixture-seed baseline in the A01 regression (`:321,351`). No hang/import/skip/forced-exit dependence introduced.

## Class C

**C-P3-1 — unguarded hold in the timeout unit test.** `:484-487` holds every KEY_A read (no `release === null` guard). Only one KEY_A read occurs in that test, so no second wait is armed; if a future edit added a second read the hold would dangle (not awaited, no hang). Record only.

**C-P3-2 — retired-undrained unit persistences accumulate in the module registry.** The unit tests retire persistences without draining; `liveIdentityPersistences` (P2, `queryClient.ts:166`) keeps them for the suite's module lifetime. Fenced, cannot write; no assertion depends on the registry. Record only.

## Carry-forward
- P1 C2, C3, C5–C14: unchanged.
- P2 C-P2-1…6: unchanged. S6-B-P2-01: conditional C (`P2_REACHABILITY_DISPOSITION.md`).
- Setup provenance gap (wrapper raw exit missing) is an environment qualification for the runtime attestation, not a candidate finding.
