# S6 R2 validation + commit — actual result packet (tree acb41c2baab6e856573d86e02135430c3304828b on baseline d51a1910)

| Step | Raw | Post | Status | Note |
|---|---|---|---|---|
| 00 pins | 0 | – | 0 | 21:00:01Z |
| 01 typecheck | 0 | 0 | 0 | 0 `error TS` |
| 02 identity-gate-suite | 0 | 0 | 0 | `Tests: 19 passed, 19 total`, normal exit |
| 03 rootnav-gate-suite | 0 | 0 | 0 | `4 passed`, normal exit |
| 04 persister-suite | 0 | 0 | 0 | `5 passed` |
| 05 signout-suite | 0 | 0 | 0 | `4 passed` |
| 06 regression-suites | 0 | **1** | **1** | 5 suites / 25 passed; regex hits 2 (`legacy-code-todo-rewrite` stack paths in expected console.warn); did-not-exit warning then self-exit raw 0, cause UNKNOWN — parent C-qualified (CHECKPOINT-06.md) |
| 07 place-hazard | 0 | – | 0 | |
| 08 hazard-postfix | **1 (expected)** | **1** | **1** | `3 failed, 3 passed, 6 total`; ✓T-WIRING/T0/T4, ✕T1 `:188:`, ✕T2 `:208:`, ✕T3 `:240:`; T0 landed on `TGP_RQ_CACHE_V1:user-B`; sole post mismatch mode-line count 4 vs constant 1 — parent C-qualified (CHECKPOINT-08.md) |
| 09 remove-hazard | 0 | – | 0 | porcelain 10, ctree acb41c2b |
| 20 stage | 0 | **1** | **1** | staged tree acb41c2b, worktree==index, exact 10 paths, untracked 0, hazard 0; sole mismatch `staged paths expected=9 actual=10` — parent-dispositioned criterion artifact |
| 21 identity-and-commit (alternate cmd a6e94f17…, message 06e7ae2d…) | 0 | – | 0 | author+committer `Bradley Gleave <bradley@bradleytgpcoaching.com>`; hooks: none configured (`[]`, core.hooksPath empty); ordinary `git commit -F` |
| 22 post-commit-identity | 0 | 0 | 0 | 13/13: %T acb41c2b, %P d51a1910, no trailers, message == authored file, banned-token 0, detached, ten exact blobs, numstat, refs unchanged, lock unchanged |
| 23 bundle | 0 | – | 0 | `bundle/s6-r2-bc7b4e96-from-public-a5933fd6.bundle` verify okay; sha256 85836076cc1a99211153a5ad292415e72dd130299ec9dcb13458fec788efccf7 |

**HEAD `bc7b4e96fc1db54568bc209dbe1f7a4121501ac9`** (detached, worktrees/s6-p2), parent `d51a191098f483cea9abec6cc7e9f3beffd18c06`, tree `acb41c2baab6e856573d86e02135430c3304828b`, 10 files, +1455 −91; porcelain 0; refs untouched (`refs/heads/main` a5933fd6, `refs/restored/execute/20260921-s6-r3` d51); no remote action. Heavy slot released 21:24:12Z (RUNTIME_RELEASE.txt). Bindings: s6-r2-validation (MANIFEST 8338f187…), s6-r2-commit-binding (43a995ac…); packets s6-observed-test-fix-r2 (e0d281f9…). Disposition: ../S6_R2_VALIDATION_DISPOSITION.md.
