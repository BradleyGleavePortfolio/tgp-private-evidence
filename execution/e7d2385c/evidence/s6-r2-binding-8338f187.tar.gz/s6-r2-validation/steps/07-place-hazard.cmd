set -e; TESTDIR=src/services/__tests__
test ! -e $TESTDIR/persistedQueryCache.hazardControls.test.tsx; test ! -e $TESTDIR/persistedQueryCache.hazardAdapter.tsx
cp "$HZ/persistedQueryCache.hazardControls.test.tsx" "$HZ/persistedQueryCache.hazardAdapter.tsx" "$TESTDIR/"
[ "$(sha256sum $TESTDIR/persistedQueryCache.hazardControls.test.tsx | cut -d' ' -f1)" = a91bb732716b500122e291714bf437872cb81930c020812042f84ed87f6a184d ]
[ "$(sha256sum $TESTDIR/persistedQueryCache.hazardAdapter.tsx | cut -d' ' -f1)" = 3796be8fae738993bcc5c30dd7d4cf9b303329b8faa990ca03e31c2460cd35f3 ]
sha256sum $TESTDIR/persistedQueryCache.hazard*; git status --porcelain
[ "$(git status --porcelain | grep -vc -E '^\?\? src/services/__tests__/persistedQueryCache\.hazard')" = 10 ]
