# S5 independent review B — exact candidate/runner source + hooked head 98d39610 (EXEC-e7d2385c)

Reviewer: independent nonbuilder S5 reviewer B (did not author any S5 byte; did not read s5-a or any parent disposition). Tier T4 individual/cumulative; requested Claude Fable 5 / High (requested setting, not runtime telemetry). Observed 2026-09-23 ~20:05–20:25Z.

Method: source-read only. No tests, install, node/npm, fixture, probe, runtime, or product edit. Git reads under `GIT_OPTIONAL_LOCKS=0` against `worktrees/s5-r4` (no ref/index/worktree write). Patch-layer replay was done on copies under my own scratch directory (`execution/e7d2385c/audits/s5-b/scratch/`), never in the candidate. Sole writes: `execution/e7d2385c/audits/s5-b/**`.

Read: `SCOPE.md`, `startup_read/live_AGENT_RULES.md`, `inputs/OWNER_SAFETY_ROI_AND_EXECUTION_DOCTRINE.md`, `inputs/S5_LINT_DISPOSITION_AND_COMMIT_ACTIVATION.md`, sealed `s5-continuation/RECEIPT.md` + `MANIFEST.sha256` and the packet files it covers, head/parent source in the worktree, and the already-retrieved checkpoint-1 runner files under `s5-proof-preparation/retrieved/` (hash-verified; no other s5-proof-preparation output existed yet). Not read: peer `audits/s5-a/**`, any parent S5 disposition, private shelf (no gh fetch was needed — every referenced byte was present locally with matching hashes).

S1–S4 accepted evidence is treated as applicable and unchanged; not re-audited. No controls, baselines, or harness were added.

---

## 1. Packet integrity (independently recomputed)

| Item | Expected | Observed | Match |
|---|---|---|---|
| `s5-continuation/MANIFEST.sha256` | `4007b242…5371` | `4007b242146cd6a547ae31306dd3c02cda3200c9dda65574bef8c39822095371`, 136 entries, `sha256sum -c` all OK | yes |
| Bundle `candidate/bundle/s5-r4-hooked-98d39610-from-public-c23b9d9f.bundle` | `e624facc…c9fb` | `e624facc9f4dc08f92b930350fa7d01ee8262d28577d9013ec0ff9571c1dc9fb`; `git bundle verify` (inside repo) okay; contains `98d39610 HEAD`, requires `c23b9d9f` | yes |
| `RECEIPT.md` | manifested | `b21060c5…0665` = manifest entry | yes |

## 2. Exact head pin (read from the repository object store, not from the receipt)

| Fact | Observed |
|---|---|
| HEAD | `98d39610f511505558373f3a59fa019804c94bd7` (detached; `git symbolic-ref -q HEAD` empty) |
| tree | `67fc1db5f353f0d363fe7134a78d455c0decfb55` |
| parent | `143d451ead6ccdbebd92ca3031ba7a89867d6cfc` (single parent) |
| author / committer | both `Bradley Gleave <bradley@bradleytgpcoaching.com>`, ts 1790193165 +0000 (on the landed object) |
| trailers / gpgsig | `%(trailers)` empty; no `gpgsig` line; message = the frozen `07-commit-message.txt` text (hash-guarded in 07R, re-checked in 08) |
| commit object sha256 | `ff8fce75ba9edf0922645be895fccfdbc9e37d9bcd6cb219b14541e87e711b6c` |
| refs | exactly `refs/heads/main`=c23b9d9f, `refs/restored/execute/20260921-s5-r3`=143d451e |
| worktree | porcelain 0 lines (incl. untracked) |
| `.git/config` | 4 defaults + `core.abbrev=8` + `user.name`/`user.email` (Bradley); `core.hooksPath` unset; no `hooks` override |
| `git diff 143d451e HEAD` sha256 | `9f37223b889b31580ba8024b14d86ac3d0fb9feab08ef4b250292d50a735921d` |
| changed paths | exactly `test/rls-g2-pg17-etq0.spec.ts` (975/357, blob `100644 b3af897e`, sha256 `2b7d1969…8e7f`) and `test/utils/g2-pg17-bootstrap.sh` (34/4, blob `100755 85a636ba`) |
| unchanged policy/config vs parent | `git diff HEAD^ HEAD -- eslint.config.js lefthook.yml package.json package-lock.json` = 0 bytes |

Every pin in the task brief (head, tree, parent, manifest, bundle) matches the object store.

## 3. Independent reconstruction of the two-file delta (four layers, replayed on copies)

Starting from the parent blobs (`143d451e:test/rls-g2-pg17-etq0.spec.ts` sha256 `54c85d8d…`, bootstrap `0ff77d8b…`):

| Layer | Patch (sha256) | Result sha256 / blob | Matches archive |
|---|---|---|---|
| L1 original checkpoint-1 correction | `c36258b3…5491` (`retrieved/2026-09-22/…/s5-r4-dirty-from-143d451e.patch`) | spec `01f3cfc0…` (blob `ff5a38b8`), bootstrap `d3348db8…` (blob `85a636ba`) | archived staged preimage `01f3cfc0`; bootstrap post-image |
| L2 archived Prettier formatting (frozen 06F) | `c43b4d1b…d21d` | spec `338defe8…6430` | frozen 06F hash |
| L3 five binding aliases | `ed1e596c…853a` (`candidate/preimage/binding-only-vs-index-756a.patch`) | spec `0f624f2c…453e` | builder's pre-format hash |
| L4 pinned Prettier 3.9.6 reflow | `6ea68be8…7180` (`formatter-only-delta.patch`) | spec `2b7d1969…8e7f` | — |
| Final | — | `cmp` spec and bootstrap against `HEAD:` blobs: **identical** | committed head |

So the committed head is exactly parent + L1 + L2 + L3 + L4 and nothing else. Bootstrap is touched only by L1 (byte-identical to the frozen post-image).

### 3.1 L3 — the five authorized alias changes (grant §Concrete defect)

`diff` of `staged-338defe8` vs `binding-edited-preformat` shows exactly five changed lines, nothing else:

- L176 `const families = [...]` → `const _families = [...]` (literal declaration retained; `rg` confirms no other `families` identifier reference in the file — the only other hits are comments).
- L253, L452, L1269 `const { source_platform, ...rest } = r;` → `const { source_platform: _source_platform, ...rest } = r;` — property key `source_platform` unchanged, so `rest` still excludes it.
- L307 `({ updated_at, ...rest }: any) => rest` → `({ updated_at: _updated_at, ...rest }: any) => rest` — same exclusion semantics.

No new token/cast/assertion/control-flow, no config, hook or suppression change. The pre-existing rule at HEAD is `'@typescript-eslint/no-unused-vars': ['warn', { argsIgnorePattern: '^_', varsIgnorePattern: '^_', caughtErrors: 'none' }]` — the aliases use the existing ignore pattern; nothing was widened. Decision: conforms exactly to the grant's five edits.

### 3.2 L2 + L4 — formatting layers (semantic neutrality checked at token level)

Whitespace-stripped character diff of L2 (`01f3cfc0` → `338defe8`): 160 opcodes = 152 trailing-comma insertions, `<T,>`→`<T>` in a `.ts` generic arrow (the comma is only needed in `.tsx`), removal of redundant parentheses around two arrow-body conditionals (`cursorOf`, `nextLegacy`), and one string requoted `'…E\'s…'` → `"…E's…"` (escape dropped). All are Prettier-canonical and semantically neutral. L4 is a single line-length reflow of the L307 `pages.map(...)` expression with zero token change. The pre-commit `prettier --check` of the head passed; tsc passed. Decision: no behavior change.

### 3.3 L1 — the original teardown / bootstrap correction (substantive review)

**Spec: teardown authority (`teardownAuthorized`).** I verified line by line that every statement in `beforeAll` before the flag is a read-only observation: `json(SELECT …)`, `sqlAdmin(SELECT current_setting('data_directory'))`, `sql(SELECT …)` ×6, `appliedMigrations()`, `hasColumn()`, `readFileSync` ×2, `gitShow` (read), `console.warn`. The flag is set immediately before the first mutation (`GRANT …`). `afterAll` with the flag false emits `PG17_TEARDOWN_SKIPPED` and returns with no SQL. With the flag true it runs `DROP CONSTRAINT IF EXISTS` ×2 (idempotent), `resetData()` (DELETEs on the five fixture tables, which exist because the 164-migration gate passed), and `DELETE FROM "ScoutImport"`. Jest-circus runs top-level `afterAll` after a failed `beforeAll` but does not run `beforeEach` of skipped tests; the nested describes contain only `beforeEach(resetData)` and no `afterAll`/`afterEach`, so there is no other mutation path after a refused setup. Cleanup safety: a refused identity/marker/pre-state gate now issues zero DDL/DML against an unaccepted target; a partially authorized setup still cleans up. Data isolation is otherwise carried by the unchanged, previously accepted `g2-pg17-db.ts` guard (loopback, refused ports, pinned DB name, double-entry confirmation, pinned cluster/database markers) and the unchanged harness role matrix. Decision: correct and fail-closed; no A/B finding.

**Bootstrap: enforced provenance.** `set -euo pipefail` is in force. `hash_required` exits 6 inside a command substitution used as a plain assignment, so `set -e` aborts the script with status 6 and the stderr reason is visible; the `[[ … ]] && cmp … || { …; exit 6; }` compounds have no masked-failure branch. Engine equality is now enforced for both generated clients (previously only O), and the candidate client's runtime is resolved from the generated directory and compared with the pinned path. I checked the premise against the actual generated client at the head: `node_modules/.prisma/client/runtime/` does not exist, `node_modules/@prisma/client/runtime/library.js` exists (202,499 B), both engine copies hash `a2924eab…a7d8`, and the ledger model in the generated schema carries `source_platform String?`. Under the old code the `CANDIDATE_CLIENT_GENERATED` echo would have hashed a missing file inside an `echo` substitution and printed an empty field without failing (the S5-R3-A-05 defect); the new code refuses. Decision: a genuine proof-validity improvement, fail-closed, no product surface touched.

Residual observation (Class C, pre-existing): teardown does not `REVOKE` the setup GRANTs; the disposable database is dropped/destroyed by the runner lifecycle, so nothing persists beyond the lane.

## 4. Genuine hooks, identity and input evidence

- Hook scripts `.git/hooks/pre-commit` and `commit-msg` are lefthook-generated; `core.hooksPath` unset; `LEFTHOOK`/`LEFTHOOK_EXCLUDE` unset at commit time (echoed by 07R). The `set -x` trace in `07R-identity-and-hooked-commit.log` shows `LEFTHOOK_BIN` empty, PATH lefthook absent, and dispatch to `node_modules/lefthook-linux-x64/bin/lefthook` (package.json version 2.1.9) for both `run pre-commit` and `run commit-msg`.
- Pre-commit jobs on staged files = the two paths: `prod-readiness-quick` no-op (script absent at this head, disclosed), `banned-cast-tokens` `OK — no positive token change`, `prettier --check` clean, `eslint --no-warn-ignored --max-warnings 0 test/rls-g2-pg17-etq0.spec.ts` exit 0 with no output (the original 07 refusal is gone), `tsc --noEmit` exit 0 (48.69 s). Commit-msg `no-ai-tokens` passed. Commit result `[detached HEAD 98d39610] … 2 files changed, 1009 insertions(+), 361 deletions(-)`.
- 08 postchecks all rc 0 (read directly from the log), including tree-identical, parent, identity, trailers, message equality, porcelain 0, banned-token 0, detached, diff hash `9f37223b`, numstat, refs.
- Command substitutions (`SUBSTITUTIONS.md`, `*.diff-vs-continuation`) are mechanical only: 07R tree guard `756a0d79→67fc1db5`; 08 tree/diff-hash/numstat/labels; `step.sh` roots + holder label `slot-H3`. 09/10 original. R75 range checks 143d..HEAD and c23b..HEAD both exit 0.
- Pins on disk now: `package-lock.json` `b7fed5ed…9c55`; `node_modules/.package-lock.json` `05bc530a…7b44`; pinned Prettier CLI `6e922134…906e` (linked at `node_modules/.bin/prettier`); eslint 10.5.0, typescript 5.9.3, prisma 6.19.3, lefthook 2.1.9; engine `a2924eab…a7d8` in both `@prisma/engines` and `.prisma/client`.
- Runtime released: 10 start / 10 end holder lines, lock fd holders 0 (`RUNTIME_RELEASE.txt`).

Decision: the head is a genuine, hook-enforced, correctly attributed commit of exactly the authorized delta.

## 5. Runner source review for the existing fresh51 real proof (inputs recovered so far)

Hash-verified against checkpoint-1 `SHA256SUMS`: `run-proof.sh` `19ab936a…`, `s5-fixture.sh` `3a7d57bf…`, `launch-full.sh` `a03836d5…`, `npm-ci.sh` `951c20a3…`.

Proof semantics as written:
- `live` runs `./node_modules/.bin/jest --config jest.rls.config.js test/rls-g2-pg17-etq0.spec.ts --runInBand --testTimeout=180000` as an owned, process-group-supervised child; the head's `jest.rls.config.js` `testMatch` includes `<rootDir>/test/rls-*.spec.ts` and ignores only `node_modules`/`dist`, so the spec is selected. The head spec has 22 plain `it(` plus 13 `it.each` blocks totalling 29 cases = **51 tests**, no `.skip`/`.only`/`todo` — matching the "fresh51" name; a passing run must report `Tests: 51 passed, 51 total`.
- `finish` writes `PROOF_EXIT=<rc> FIRST_RC=… STOP_RC=… DAEMON=… SURVIVORS=… QUARANTINE=…`; a cleanup-stop failure, live postmaster or owned survivor converts rc 0 to 3 and quarantines the lane. The exit record therefore distinguishes success from timeout (124) and from masked cleanup.
- `stamp` records `HEAD/TREE/CLEAN/DIRTY_FINGERPRINT`, `RUNNER_SHA256`, `FIXTURE_SHA256`, node_modules lock hash and PG provenance, but does **not** refuse a wrong head — the final attestation must read `HEAD=98d39610… TREE=67fc1db5… CLEAN=yes` from `env-<stage>-<ts>.log`.
- Preflight (13 facts, maintenance DB, superuser) precedes every mutation; `full` = guard → oldroot → init (fresh only) → start → preflight → bootstrap → live → stop.

Mechanical prerequisites in this fresh sandbox (not defects; recorded so the builder's substitutions can be checked exactly):
1. Lane constants are hardcoded: `W=/home/user/workspace/worktrees/s5-r4` (matches), `X=/home/user/workspace/execution`, `S=$X/s5-r4`, `LOCK=$X/test-validation.lock`, `PG17_HOME=/home/user/pg17`; fixture `PG17_HOME`; launcher `S=…/execution/s5-r4`, `DATA=/home/user/pg17/clusters/s5`. The runner declares the lane block as the only substitutable lines. Any substitution must be frozen and diffed against `19ab936a`/`3a7d57bf`/`a03836d5` before launch and the stamped `RUNNER_SHA256`/`FIXTURE_SHA256` must equal the frozen substituted files.
2. The head spec pins `expect(directory).toMatch(/\/pg17\/clusters\/s5$/)`; `PG17_HOME` must end in `pg17`.
3. `G2_PG17_PSQL` defaults to `/usr/bin/psql`, absent here; it must point at the PG 17.6 dist `psql`, and `PROVENANCE.txt` must carry `result=success` and matching `postgres_sha256`/`initdb_sha256`.
4. The restored object DB is shallow at `c23b9d9f` (`.git/shallow` present). O `925780e0` is present and an ancestor of HEAD, so `g2-pg17-old-root.sh` can clone/detach it (the local clone of a shallow source yields a shallow clone; every old-root and bootstrap gate is file/HEAD-based and needs no history below `c23b9d9f`).
5. `S=…/execution/s5-r4` (logs, `old-root-925780e0`, `QUARANTINE`) lies outside `execution/e7d2385c`; path ownership is a parent/builder decision.

## 6. Findings

No Class A finding. No Class B finding. Nothing here blocks the affected product path or invalidates the pending proof.

Class C (record, qualify, continue; no new cycle):
- C1 Teardown does not revoke setup GRANTs (pre-existing; disposable DB lifecycle covers it).
- C2 Bootstrap's "pinned runtime preceded only by the generator header" rule is an observed-6.19.3 assumption; a change would surface as a visible fail-closed `exit 6`, i.e. an evidence/prerequisite refusal, not a product defect.
- C3 Builder disclosures accepted as recorded: depth-1 base fetch instead of byte-copied `.git`; Prisma engine fetched from `binaries.prisma.sh` during step 02 (hash equals pin); lock path moved into the packet root; `prod-readiness-quick` no-op.
- C4 Runner records but does not pin the head (covered by the attestation checklist below).

## 7. Verdict (source phase) — SEALED

**Source / grantability: GRANTABLE.** Head `98d39610f511505558373f3a59fa019804c94bd7` (tree `67fc1db5…`, parent `143d451e…`) is exactly the authorized S5 candidate: the original checkpoint-1 teardown/bootstrap correction, the frozen Prettier formatting, the five authorized `_`-prefixed binding aliases and one pinned reflow, committed through genuine lefthook hooks with verified Bradley author/committer and unchanged dependency/toolchain pins. The one existing fresh51 real PostgreSQL 17.6 proof may be executed against this exact head. This is not runtime or product acceptance; no public push/merge/deploy/customer action is implied.

Attestation checklist I will apply to the actual fresh51 result (same review, appended, no new audit cycle):
1. `env-*.log` stamp: `HEAD=98d39610f511505558373f3a59fa019804c94bd7 TREE=67fc1db5f353f0d363fe7134a78d455c0decfb55 CLEAN=yes`, `NODE_MODULES_PACKAGE_LOCK_SHA256=05bc530a…`, `PACKAGE_LOCK_BLOB=354de3da…`, `RUNNER_SHA256`/`FIXTURE_SHA256` = frozen substituted files, PG provenance `result=success`, `version=170006`.
2. `preflight-*.log`: version 170006, cluster marker `s5-disposable-pg17`, loopback listen/addr, pinned port, `hosted_roles=0`, allowed dbs only, target marker (if present), `target_sessions=0`.
3. `bootstrap-*.log`: `O_CLIENT_GENERATED … engine_sha256=a2924eab…`, `CANDIDATE_CLIENT_GENERATED … engine_sha256=a2924eab… runtime=<pinned> runtime_sha256=…`, no `provenance file missing`, bootstrap rc 0.
4. `live-etq0-*.log`: `PG17_DATABASE` identity line with `g2_s5_etq0_disposable`, `127.0.0.1`, version 170006, `super:false`, `bypassrls:true`; `Tests: 51 passed, 51 total`, `Test Suites: 1 passed`; no `PG17_TEARDOWN_SKIPPED`; jest rc 0.
5. `exit-full-*.log`: `PROOF_EXIT=0 FIRST_RC=0 STOP_RC=0 DAEMON=none SURVIVORS=none QUARANTINE=no`; launcher sentinel `FULL_EXIT=0 OUTER_BOUND=no`; no `QUARANTINE/` directory; lock holders 0 afterwards.
6. Worktree still at HEAD `98d39610`, porcelain 0, refs unchanged after the run.

A failure caused by a missing prerequisite (binaries, paths, provenance file) is a prerequisite gap to close and rerun, not a new product defect, unless the log shows an actual assertion failure inside the spec or bootstrap refusal on real fixture state.

---

## Appendix A — read-only commands used (summary)

`sha256sum -c MANIFEST.sha256`; `git rev-parse / cat-file -p / log --format / status --porcelain --untracked-files=all / for-each-ref / symbolic-ref -q / diff --stat|--numstat|--name-status / diff | sha256sum / ls-tree / show / config --local -l / bundle verify / fsck --connectivity-only / cat-file -t / merge-base --is-ancestor / rev-list --count` (all with `GIT_OPTIONAL_LOCKS=0`); `patch -p1` replay on copies in `audits/s5-b/scratch/tree/`; `diff`, `cmp`, `rg`, a Python whitespace-stripped `difflib` comparison; `stat`, `readlink`, `awk` on installed files. No `node`, `npm`, `npx`, `jest`, `prisma`, `psql`, or hook execution.

## Appendix B — files written by this reviewer

- `execution/e7d2385c/audits/s5-b/S5_REVIEW_B.md` (this review)
- `execution/e7d2385c/audits/s5-b/scratch/` (parent blobs `spec.143d`, `boot.143d`; replayed `tree/test/**`; `spec.head.ts`, `harness.head.ts`, `boot.head.sh` extracted from `HEAD:` for reading)

---

# Part 2 — appended 2026-09-23 ~20:15Z: runner/PG 17.6 preparation review and activation grantability (same review, no new cycle)

Trigger: parent notice that `execution/e7d2385c/s5-proof-preparation/` is COMPLETE (manifest `080b9574…`). Still source-read only; no runner stage, fixture, jest, npm or product action by this reviewer. Not read: `audits/s5-a/**`, parent disposition.

## 2.1 Packet and exact bytes (independently recomputed)

| Item | Observed | Match |
|---|---|---|
| `s5-proof-preparation/MANIFEST.sha256` | sha256 `080b9574a6d4cda950d16baa3f4b19c5672086c2303643b18cb6cd3201024b11`, 42 entries, `sha256sum -c` all OK | yes |
| `execution/s5-r4/run-proof.sh` | `19ab936a1562061caf4f8ee8426a5e18a998b22f3d33093a45a02b64ee3fc2c5`, mode 0755 | = checkpoint-1 SHA256SUMS |
| `execution/s5-r4/s5-fixture.sh` | `3a7d57bf951ab27e2161dc91db1d816f31d4af079ede076e7a2dfd1c44f3a721`, 0755 | = |
| `execution/s5-r4/launch-full.sh` | `a03836d524bafc28572b1e600f34148d8e9ddea38391ffc427c26f5399b9f728`, 0755 | = |
| `execution/s5-r4/npm-ci.sh` | `951c20a3…badb`, 0644 (reference only, not run) | = |
| `/home/user/pg17/dist/bin/postgres` | `23cd174849b273064c47d581b55be596be2f5cf0ee5d3e76c0146e2464bf873a` | = `PROVENANCE.txt`, = S2 (2026-09-21) and S1 R3 (2026-09-20) retrieved provenance |
| `/home/user/pg17/dist/bin/initdb` | `b7db9bc2463a4ffbe1e405977512afb50c9846fd3af2b694e315e6d5a270882a` | = all three |
| `PROVENANCE.txt` | same artifact URL, maven sha1, jar/txz sha256 as S1/S2; `server_binary=postgres (PostgreSQL) 17.6`; `result=success`; only `installed_by`/`utc`/`log` differ | yes |
| psql | `/usr/bin/psql` → `pg_wrapper` → `psql (PostgreSQL) 18.6`; runner default `G2_PG17_PSQL=/usr/bin/psql`, `-x` test passes | same client lineage as the S2 lane |
| infra scripts | `setup-10-clients.sh` zero diff vs S2; `_common.sh` and `setup-20-pg17.sh` differ only in lock/log root and `installed_by` label; setup-10/20 exits 0 | mechanical |
| Lane state | `/home/user/pg17/clusters` absent; `execution/s5-r4/{logs,QUARANTINE}` absent; canonical `execution/test-validation.lock` absent; port 54325 free; 0 postgres processes; prep lock RELEASED 20:07:25Z, fd holders 0 | clean pre-activation |
| Head after prep | `worktrees/s5-r4` HEAD `98d39610`, porcelain 0; hooks `pre-commit`/`commit-msg` unchanged; `node_modules/.package-lock.json` `05bc530a…`; sealed continuation manifest `4007b242…` re-verifies | unchanged |

Because the lane constants of the archived runner (`W`, `X`, `S`, `PG17_HOME`) coincide with this sandbox's paths, zero substitutions were needed: the runner, fixture and launcher that will execute are byte-identical to the frozen checkpoint-1 files. Prerequisites 1–3 and 5 of Part 1 §5 are therefore closed without any edit; prerequisite 4 (shallow object DB) was shown feasible by the builder's one `g2-pg17-old-root.sh create` into a scratch path (`G2_PG17_OLD_ROOT_OK`, head 925780e0, 164 migrations, 1.3 s) — a git-only step, not a proof stage; the `full` run will create its own old root at `execution/s5-r4/old-root-925780e0` (absent now).

## 2.2 Concrete-consequence assessment of the unpinned HEAD in the runner

Question: the runner records but does not refuse a HEAD other than `98d39610`. Could this make a result attributable to the wrong candidate (Class B "wrong candidate SHA audited")?

Binding actually in place at activation: (a) the worktree is at the exact head, clean, with no other authorized writer (S6 is source-only and disjoint; the single heavy slot is granted to this proof alone); (b) `stamp()` writes `HEAD/TREE/CLEAN/DIRTY_FINGERPRINT` into `env-full-<TS>.log` and `run-full-<TS>.log` at the start of the same supervised run, before any connection or mutation, under the same lock the jest child later runs under; (c) nothing in the `full` path writes tracked source (`prisma generate` writes only `node_modules/.prisma`; the old root is cloned outside `W`); (d) the post-run invariant (Part 1 §7 item 6 / activation §4 item 10) re-reads HEAD and porcelain. A wrong or dirty head would be loudly present in the run's own log rather than silently substituted, and the attestation compares that line to the pin. The failure mode a hard pin would add (an operator launching on a moved head) is already excluded by ownership and would still be caught by the stamp. Decision: **Class C** — record; no runner edit, no new control. Adding a pin would be neatness, not a change to the validity of the next decision.

## 2.3 Other points checked against actual consequence

- Password `s5_local_synthetic` is the fixture's `initdb --pwfile` literal; it passes the runner's hosted-token refusal regex and is not a secret. Runner strips all `PG*`/hosted variables before children.
- Activation `STAGE=full` is `guard → oldroot → init (fresh only) → start → preflight → bootstrap → live (51) → stop`; `init` refuses an existing data directory, so the run cannot adopt a foreign cluster; preflight enforces the 13 identity facts and `target_sessions=0`.
- psql 18.6 client against a 17.6 server via `pg_wrapper`: same combination as the executed S2 lane; wire-compatible; the runner and harness pass connection URLs explicitly, so cluster auto-selection is not involved.
- uutils `timeout --foreground --kill-after` acceptance and `setsid` group verification remain unexecuted assumptions carried from checkpoint-1 (disclosed by the builder); a failure there is visible (launcher `OUTER_BOUND_HIT` / runner `OWNED_GROUP_UNVERIFIED`) and is an evidence/prerequisite matter, not product.
- Network events during prep (apt Ubuntu archive for `postgresql-client-18`; Maven Central jar with sha1 pin and sha256 equality to S1/S2) are the reviewed setup scripts' own actions, hash-bound. Class C.
- Expected acceptance in `readiness/ACTIVATION_AND_EXPECTED_ACCEPTANCE.md` §4 matches my Part 1 §7 checklist item-for-item (51 cases are the committed spec's, not redefined).

## 2.4 Findings (Part 2)

No Class A. No Class B. Class C: C5 runner records rather than pins HEAD (bound as in §2.2); C6 prep lock/log root and `installed_by` label substitutions; C7 psql 18.6 client lineage; C8 shallow object DB (feasibility shown); C9 disclosed network events; C10 census self-match in `RUNTIME_RELEASE.txt`.

## 2.5 Verdict (Part 2) — SEALED

**Runner / substrate / activation grantability: GRANTABLE.** The exact frozen runner `19ab936a`, fixture `3a7d57bf` and launcher `a03836d5` are materialized byte-identical at the paths they hardcode; PostgreSQL 17.6 binaries are hash-identical to the S1/S2 provenance; the head is unchanged at `98d39610`/`67fc1db5`, clean, with genuine hooks and pinned dependencies; the lane is empty. The one existing fresh51 real-database proof may be activated with the recorded command (`G2_PG17_PASSWORD=s5_local_synthetic STAGE=full bash /home/user/workspace/execution/s5-r4/launch-full.sh`). No new controls, tests or harness are requested. Acceptance is the frozen Part 1 §7 checklist; anything else is a FAIL to report, not to retry.

Part 3 (actual fresh51 result attestation) will be appended to this file when the run's exit record exists.

---

# Part 3 — appended 2026-09-23 ~20:30Z: actual fresh51 `full` attempt TS 20260923T202133Z — result boundary attestation (as observed; no re-audit)

Sources read: `execution/e7d2385c/s5-fresh51/{RECEIPT.md,RESULT_SUMMARY.txt}` and the raw runner logs in `execution/s5-r4/logs/*20260923T202133Z*`, `execution/test-validation.lock.log`, plus `HEAD:test/utils/g2-pg17-old-root.sh` and `execution/s5-r4/run-proof.sh` (`child()`), read-only. I did not launch, retry, resume, reset or destroy anything.

## 3.1 Result: NOT PASS — refused at the old-root stage; no database, cluster, bootstrap or live case exists

Checklist (Part 1 §7) against the actual logs:

| # | Item | Observed | Met |
|---|---|---|---|
| 1 | Stamp | `RUNNER_SHA256=19ab936a… FIXTURE_SHA256=3a7d57bf…`, lane constants as archived, **`HEAD=98d39610f511505558373f3a59fa019804c94bd7 TREE=67fc1db5f353f0d363fe7134a78d455c0decfb55 CLEAN=yes DIRTY_FINGERPRINT=none`**, `PACKAGE_LOCK_BLOB=354de3da…`, `NODE_MODULES_PACKAGE_LOCK_SHA256=05bc530a…`, `PG_DIST … postgres_sha256=23cd1748… version=postgres (PostgreSQL) 17.6`, `PROVENANCE result=success`, `DATA_DIRECTORY_STATE=absent`; `OFFLINE_GUARD_OK stage=full rev=7`; `LOCK_HELD … pid=5305` | yes |
| 2 | Preflight | not reached | no |
| 3 | Bootstrap | not reached | no |
| 4 | Live 51 | **no live log exists**; 0 of 51 cases ran | no |
| 5 | Exit record | `PROOF_EXIT=3 FIRST_RC=3 STAGE=full STOP_RC=na DAEMON=none SURVIVORS=none SIGNALLED=none CLEANUP_SECONDS=0 QUARANTINE=no`; sentinel `FULL_EXIT=3 OUTER_BOUND=no`; lock log `RELEASE … first_rc=3 rc=3 survivors=none` | no (3 ≠ 0), but fail-closed and consistent |
| 6 | Source unchanged after | HEAD `98d39610`, porcelain 0 (re-read by me at 20:2xZ) | yes |

Stage facts as logged: guard `./node_modules/.bin/jest test/scout/g2-pg17-db-guard.spec.ts` → `rc=0`, `Tests: 27 passed, 27 total` (the guard suite, not the 51-case proof). Old-root child `bash test/utils/g2-pg17-old-root.sh create` printed `old_root=…/old-root-925780e0 head=925780e0… detached=yes migrations=164` and `G2_PG17_OLD_ROOT_OK`, exited **rc=0**; the runner then logged `OWNED_GROUP_LEFTOVER pgid=5967 after exit rc=0: 6140 6142 6154 6156 6168 6170 6184 6186 6198 6200`, `OWNED_GROUP_REAPED pgid=5967 term_wait=0s`, converted the stage to `rc=3` per its rev-7 leftover rule, and stopped (`old-root stage failed rc=3; no connection attempted`). Init/start/preflight/bootstrap/live/stop never ran; `/home/user/pg17/clusters` was never created; no postmaster, no listener; `SERVER_STARTED_HERE` never set, so no cleanup stop was needed (`STOP_RC=na` is correct, not a masked failure).

Nothing in this run is a 51-case result and none is claimed. The frozen acceptance boundary (Part 1 §7 / activation §4) stands unchanged for the eventual rerun.

## 3.2 What the logs and source establish about the refusal (no pid identity asserted)

- The refused stage's own work succeeded (`G2_PG17_OLD_ROOT_OK`, rc 0); the refusal came from the runner's `child()` post-exit check: after `wait "$pid"` it immediately scans `/proc` for any process whose pgid equals the child's, and treats a non-empty result as `OWNED_GROUP_LEFTOVER`, forcing rc 3 even though `terminate_group` then found the group empty within the same second (`term_wait=0s`) and recorded `SURVIVORS=none`.
- `g2-pg17-old-root.sh` (unchanged accepted source at this head) ends with three `cmp -s … <(git -C "$ROOT" show …)` process substitutions and `$(…)` substitutions in its final `echo`; bash does not wait for process-substitution children before the script exits, so briefly still-exiting grandchildren in the same process group are consistent with the ten pids seen in pairs. I record this as consistent with the source, not as a proven pid-by-pid identity — that exact-cause work is the builder's assigned task.
- Concrete consequence: a real fail-closed refusal on transient, already-terminating processes of a stage that succeeded. No product, source, dependency, PostgreSQL or data effect; nothing was created that needs destroying; the created `execution/s5-r4/old-root-925780e0` (detached at 925780e0, 164 migrations, lock sha256 `b7fed5ed…` = candidate lock) is exactly what `create` mode reuses and re-verifies ("old root already exists; verifying only") on a rerun.

## 3.3 Classification and disposition

**Class B (proof-invalidating evidence-runner defect), affecting only this proof.** Product may well be correct; the current runner cannot let the proof reach the assertions.
- CONCRETE HARM: the fresh51 real-database proof cannot complete on the exact head, so the S5 boundary decision has no evidence — not a false pass, not a product change.
- EXACT DECISION BLOCKED: acceptance of head `98d39610` at its fresh51 boundary.
- MINIMUM CLOSURE: a narrowly scoped correction to the **external runner only** (`execution/s5-r4/run-proof.sh` `child()` leftover check — e.g. a bounded re-observation before declaring a leftover), preserving unchanged: survivors after TERM/KILL → rc 3 + quarantine, nonzero child status propagation, timeout 124, inner deadline/outer bound, cleanup-stop verification, lock exclusivity. No candidate/fixture/spec/bootstrap/old-root change, no new fault tests, no new controls. The parent has assigned this; it is not a new safety cycle.
- EXECUTION UNLOCKED: one rerun of `STAGE=full` on the same head with the corrected runner (fresh init still applies — data dir absent), attested against the unchanged Part 1 §7 checklist.

Explicitly not a finding against the candidate: the unchanged head `98d39610` was not exercised beyond the guard suite, and nothing observed contradicts Parts 1–2. Parts 1–2 verdicts stand; the head remains grantable for the rerun once the changed runner passes the narrow exact-bytes review below.

## 3.4 Pending in this lane

On the builder's READY for the corrected runner: review **only** the runner delta (diff vs `19ab936a`, byte-exact new hash), confirm the preserved semantics listed in §3.3 and that no other file changed, then the rerun's result is attested here as Part 4 against the same checklist. No broad new audit; no runtime by this reviewer.

---

# Part 4 — appended 2026-09-23 ~20:33Z: corrected external runner rev 7.1 — narrow exact-bytes grantability (same review; no re-audit of candidate/fixture/launcher)

Packet `execution/e7d2385c/s5-runner-correction/` — manifest `4b77082ed98ba22435d4e159100f42b1b99cea913ad0122a6f8b2bee53fd2abd` (`sha256sum -c` all OK). Read: `CLOSURE_MAP.md`, `runner-rev7-to-rev7.1.patch`, `run-proof.rev7.1.sh`, `frozen-failure/*`. Not read: peer conclusions, parent disposition. Source-read only; I did not run `bash -n`, the runner, or any probe.

## 4.1 Exact bytes

| Item | Observed |
|---|---|
| `frozen-failure/run-proof.rev7.19ab936a.sh` | sha256 `19ab936a…c2c5` = frozen rev 7 |
| `runner-rev7-to-rev7.1.patch` | sha256 `e726b0634d8c107659a9006a89fc28a7c4b591a1c7f47a2503cf23a02d37f6c2`; +20/−4 |
| `run-proof.rev7.1.sh` | sha256 `87b6ac256ed4a910789310491fa0aa9e1f49e590c8ecb1a0802dce97dc06b4bc`, 0755 |
| Independent replay | `patch` of the frozen rev 7 bytes with `e726b063` → sha256 `87b6ac25…` and `cmp` identical to `run-proof.rev7.1.sh` |
| Live runner | `execution/s5-r4/run-proof.sh` still `19ab936a` (not swapped, as declared) |
| Unchanged inputs | fixture `3a7d57bf`, launcher `a03836d5`; `frozen-failure/g2-pg17-old-root.sh.candidate-98d39610.copy` `cmp`-identical to `HEAD:test/utils/g2-pg17-old-root.sh`; worktree HEAD `98d39610`, porcelain 0 |
| Lane | `/home/user/pg17/clusters` absent; `execution/s5-r4/QUARANTINE` absent; `old-root-925780e0` present (detached 925780e0, no `node_modules`, no `.g2-old-client`) |

## 4.2 The delta, hunk by hunk (only these four hunks exist)

1. `RUNNER_REV=7` → `7.1` — attribution only (`rev=7.1`, `REV=7.1` in stamp/log).
2. `DRAIN_BUDGET=5` added inside the substitutable lane block; echoed on the `LANE` stamp line.
3. `members_detail()` — read-only `/proc/<pid>/{stat,cmdline}` formatter for the log (`pid(state):cmdline`, 80-char cut). `set -- $s` inside the function does not disturb the `for p in "$@"` iteration (the word list is expanded before the loop). Children are never given secrets as arguments (password travels only in env), so logging cmdlines exposes nothing.
4. `child()` after `wait "$pid"`: if the immediate `/proc` scan finds group members, record them, then poll `group_members` once per second **without signalling** until empty or `DRAIN_BUDGET` (5 s) elapses, log `OWNED_GROUP_DRAIN pgid rc drained_s remaining initial=[…]`; if members remain, the **unchanged** rev-7 branch runs (`OWNED_GROUP_LEFTOVER` now with cmdlines → `terminate_group` TERM/REAP_BUDGET/KILL → survivors recorded → `rc 0→3`).

## 4.3 Preserved contract (checked in the patched file)

- Nonzero child rc: `rc=$?` from `wait` is untouched; the only rc rewrite remains `0→3` on a genuine leftover.
- Timeout: deadline loop, `terminate_group` at the deadline, `return 124` untouched; the drain runs only if members are present after `wait`, and after a deadline termination the group is already empty (drain 0 s), so 124 is still returned.
- Deadline/ownership: `DEADLINE` is absolute; drains consume from it (≤5 s per child, 6 children max in `full`), so `WORK_BUDGET` is not extended; the launcher's outer bounds (1740 s TERM / +120 s KILL) are unchanged and a final-child drain of ≤5 s sits inside the 100 s margin. Lock acquisition, `lock_exclusive_check`, `OWNED_GROUP_UNVERIFIED` fail-closed path, `finish`, quarantine, fixture stop/destroy semantics, offline guard literals, env hygiene, stage order: all untouched.
- Zero survivors: the drain never signals and never clears anything; any process still in the group after 5 s (a daemon, a stuck grandchild) is treated exactly as in rev 7 and additionally identified by cmdline. A postmaster is never in an owned child's group after `pg_ctl -w start` returns and is independently checked by `postmaster.pid`/`lock_exclusive_check`/fixture `stop`.
- No masking: `OWNED_GROUP_DRAIN` lines are informational, must be attested with their `initial=[…]` identities, and do not alter rc.

## 4.4 Proposed activation (CLOSURE_MAP §6) — checked

Swap only the runner file into `execution/s5-r4/run-proof.sh` (mode 0755, verify `87b6ac25…`; the fixture's `S5_RUNNER_PID` guard greps `run-proof.sh` in the cmdline, so the filename must stay `run-proof.sh`), same command once (`G2_PG17_PASSWORD=s5_local_synthetic STAGE=full bash …/launch-full.sh`), fresh `init` still valid (data dir absent), no destroy needed (nothing was created). Old-root reuse: `g2-pg17-old-root.sh create` on an existing `.git` path skips cloning and re-runs every identity gate (HEAD 925780e0, detached, manifests equal, 164 migrations, byte-identical scout sources, ledger model, `node_modules` absent-or-symlink) — the existing directory satisfies those gates by construction of the previous run; bootstrap then adds the shared `node_modules` symlink. Acceptable.

Frozen acceptance for the rerun = Part 1 §7 checklist with these mechanical updates: stamp `REV=7.1`, `RUNNER_SHA256=87b6ac256ed4a910789310491fa0aa9e1f49e590c8ecb1a0802dce97dc06b4bc`, `LANE … DRAIN_BUDGET=5`; launcher log `runner_sha256=87b6ac25…`; zero or more `OWNED_GROUP_DRAIN … remaining=none` lines acceptable (attested with identities); any `OWNED_GROUP_LEFTOVER`, `SURVIVORS≠none`, `QUARANTINE=yes`, `PROOF_EXIT≠0` or fewer than `Tests: 51 passed, 51 total` remains FAIL. Previous-run logs `*20260923T202133Z*` stay in place.

## 4.5 Findings (Part 4)

No Class A. No Class B. Class C (record only): C11 pid identities of the failed run remain unknown (rev 7 logged pids only); rev 7.1 records state/cmdline if it recurs. C12 the drain is a bounded tolerance in the evidence runner, not a candidate change; the alternative (helper without `<(…)`) would move the head and is correctly not proposed. C13 `bash -n` by the builder is a static parse, not runtime.

## 4.6 Verdict (Part 4) — FROZEN

**Changed-runner grantability: GRANTABLE.** Rev 7.1 (`87b6ac25…`) is exactly frozen rev 7 + patch `e726b063` (+20/−4), confined to a ≤5 s non-signalling natural drain and log diagnostics before the unchanged leftover/terminate/quarantine path; nonzero, timeout, deadline, ownership, zero-survivor and quarantine semantics are preserved. Candidate `98d39610`, fixture, helper and launcher are unchanged. The proposed `full` activation with pinned old-root reuse and no destroy is acceptable. Execution may proceed when the slot is free; Part 5 will attest the rerun's result against the checklist above.

---

# Part 4a — appended 2026-09-23 ~20:36Z: additive follow-up on peer finding S5-A-R71-B01 (sharing permitted by parent after both freezes; Part 4 text above is preserved unchanged)

Inspected: `audits/s5-a/RUNNER71_FINDINGS.md` (the claim only) and the exact rev 7.1 source `run-proof.rev7.1.sh` lines 228–239 (`on_signal`), 259–284 (`child()` tail), 304–317 (`finish`).

## 4a.1 Source reading (my own)

- `child()` line 267: `OWNED_PGID=""` is executed immediately after `wait "$pid"`, **before** the new drain loop (lines 274–278) that can spend up to `DRAIN_BUDGET`=5 s while `members` is known to be non-empty and unsignalled, and before the leftover `terminate_group` at line 280.
- `on_signal()` terminates a group only via `[ -n "$OWNED_PGID" ] && terminate_group "$OWNED_PGID"`; `finish()` likewise only `if [ -n "$OWNED_PGID" ]`. Neither has any other handle to the drained group.
- Consequence if TERM/INT/HUP arrives during the drain window (the launcher's outer TERM and operator cancellation are existing, supported paths): the trap runs after the current `sleep 1` returns, skips `terminate_group`, `finish` records `SURVIVORS=none QUARANTINE=no` (only `OWNED_SURVIVORS` is consulted), releases the lock and exits with the signal rc — while the members observed alive moments earlier were neither terminated nor rechecked. The rc is nonzero, but the ownership/zero-survivor release record is unverified for that group.
- Rev 7 had the same ordering (`OWNED_PGID=""` before the instantaneous scan and the leftover `terminate_group`), so the gap is not new in kind; rev 7.1 makes it a deliberate multi-second window with known-live members and no signal, which is what turns it from a sub-second race into a reachable state under the runner's own cancellation contract.

I confirm the peer's reading from source. In Part 4 §4.3 I checked the trap interaction only for budget effects and did not examine the `OWNED_PGID` ordering; that omission is recorded here. Part 4's verdict text stands as frozen per parent instruction; this addendum is additive.

## 4a.2 Classification (my own, by consequence)

**Class B, confined to activation of the rev 7.1 evidence runner.** Harm: a cancelled run can publish an untrustworthy `SURVIVORS=none` release and free the lock over possibly live owned descendants (doctrine example: "owned worker survives and can still mutate test state"). Decision blocked: activation of rev 7.1 only; head `98d39610`, fixture, helper, launcher and the 51-case acceptance are untouched. Minimum closure: keep `OWNED_PGID="$pid"` through the diagnostics, the drain and the existing leftover TERM/KILL path; clear it only once `group_members` is empty or `terminate_group` has completed/recorded survivors (on both the normal and the leftover branch). Nothing else — the existing `on_signal`/`finish` handlers then already own the correct group; no new manager, control or fault test. Execution unlocked: review that tiny delta and trap interaction, then the one-shot fresh `full` execution with pinned old-root reuse and no destroy.

Expected trap interaction after closure (to be checked in the successor source): a signal during the drain → `on_signal` → `terminate_group "$OWNED_PGID"` (TERM → REAP_BUDGET → KILL → survivors recorded) → `OWNED_PGID=""` → `finish` (no double termination because `on_signal` clears the handle before `finish`; `finish` then sees an empty handle and consults `OWNED_SURVIVORS` for quarantine). The normal path must clear the handle after the drain/leftover handling so that `finish` does not TERM an already-empty group (harmless but noisy) — either order is safe; the requirement is only that the handle is not empty while members may be alive.

Awaiting the builder's READY for the successor delta; Part 5 will review only that delta and the trap interaction.

---

# Part 5 — appended 2026-09-23 ~20:38Z: successor runner rev 7.2 — tiny-delta review, trap interaction, exact pins (same review)

Packet `execution/e7d2385c/s5-runner-correction-r2/` — manifest `6c51404ca35d32ec8932721b005e7b747a88c1bc1f6c579d913dd8be780751d0` (`sha256sum -c` all OK). Read: both patches, `run-proof.rev7.2.sh`, `inputs/run-proof.rev7.1.87b6ac25.sh`; `CLOSURE_MAP_R2.md` not needed for the verdict. No peer conclusions read beyond the already-shared finding. Source-read only.

## 5.1 Exact bytes (independently replayed)

| Item | Observed |
|---|---|
| `inputs/run-proof.rev7.1.87b6ac25.sh` | sha256 `87b6ac25…` = frozen rev 7.1 |
| `runner-rev7.1-to-rev7.2.patch` | sha256 `fe4b20c59cc23b3b276ce6c9e942c110eae7885c5ac57845145bec1931c785ad`; diff lines 7 (+5/−2) |
| `runner-rev7-to-rev7.2.cumulative.patch` | sha256 `069e4c77…bdbc` |
| `run-proof.rev7.2.sh` | sha256 `16c763f408544529ca4a11b40d61a57bc61e5e0c07023091b70253b541b9a73a`, 0755 |
| Replay A | rev 7.1 bytes + `fe4b20c5` → `cmp`-identical to `run-proof.rev7.2.sh` |
| Replay B | frozen rev 7 `19ab936a` + cumulative `069e4c77` → `cmp`-identical to `run-proof.rev7.2.sh` |
| Live/unchanged | `execution/s5-r4/run-proof.sh` still `19ab936a` (no swap); fixture `3a7d57bf`, launcher `a03836d5`; worktree HEAD `98d39610`, porcelain 0; `/home/user/pg17/clusters` and `execution/s5-r4/QUARANTINE` absent |

## 5.2 The 7.1 → 7.2 delta, line by line

1. `RUNNER_REV=7.1` → `7.2` (attribution).
2. Three comment lines explaining the retention (no code).
3. `OWNED_PGID=""` removed from immediately after `wait "$pid"` (old line 267) and re-inserted after the leftover branch (new line 284), i.e. after the drain and after any `terminate_group` for that group. Nothing else changed; the rev 7.1 drain/diagnostic code is byte-identical.

Every `OWNED_PGID` reference in rev 7.2: declaration (204), `on_signal` log/terminate/clear (232–234), `child()` set (260) and clear (284), `finish` terminate/clear (312). No other consumer.

## 5.3 Trap interaction (traced in the rev 7.2 source)

- Signal during the drain (`sleep 1` loop, members possibly alive): handle = `$pid` → `on_signal` runs after the current `sleep` returns → `terminate_group "$pid"` (TERM → ≤REAP_BUDGET reap → KILL → survivors recorded in `OWNED_SURVIVORS`) → `OWNED_PGID=""` → `finish` sees an empty handle (no double termination), consults `OWNED_SURVIVORS`, quarantines and forces rc≠0 if any survived, writes the exit record and releases the lock at exit. **S5-A-R71-B01 closed:** the release record is again backed by an actual termination/re-check of the group.
- Signal during the leftover `terminate_group` (line 283): handle still set → nested `terminate_group` on the same group between its loop commands; idempotent TERM/KILL; survivors may be appended twice (cosmetic) → `finish` → exit. Same behavior as rev 7's deadline-termination path, which also ran with the handle set.
- Signal after line 284 (group verified empty or terminated): `on_signal` skips termination correctly.
- Normal path: drain empties or is skipped → clear at 284 → `END` → return rc; `finish` later sees an empty handle. Timeout path: deadline `terminate_group` with handle set → `wait` → drain finds nothing → clear → `return 124`. `OWNED_GROUP_UNVERIFIED` path unchanged (returns 3 before the handle is set).
- Contract from Part 4 §4.3 (nonzero rc, 124, absolute deadline, ownership/lock, zero-survivor rule, quarantine, no masking) is unchanged by moving the clear; the drain still never signals.

## 5.4 Findings (Part 5)

No Class A. No Class B. Class C: C14 possible duplicate survivor pids in `OWNED_SURVIVORS` when a signal lands inside a leftover termination (log cosmetics; quarantine decision unaffected). Nothing else new; C11–C13 carry forward.

## 5.5 Verdict (Part 5) — FROZEN

**Rev 7.2 (`16c763f4…`) runner grantability: GRANTABLE**, closing S5-A-R71-B01 with the minimum delta and preserving every rev 7 guarantee plus the rev 7.1 drain. Same-review grant for **one** existing `STAGE=full` run on unchanged head `98d39610` / tree `67fc1db5`: swap only `execution/s5-r4/run-proof.sh` to the rev 7.2 bytes (keep the filename; verify `16c763f408544529ca4a11b40d61a57bc61e5e0c07023091b70253b541b9a73a`, 0755), fixture/launcher/helper untouched, fresh init (data dir absent), pinned old-root reuse, no destroy, when the parent releases the runtime slot (S6 currently holds it). Rerun acceptance = Part 1 §7 checklist with stamp `REV=7.2`, `RUNNER_SHA256=16c763f4…`, `LANE … DRAIN_BUDGET=5`, launcher `runner_sha256=16c763f4…`; `OWNED_GROUP_DRAIN … remaining=none` lines acceptable and attested with identities; any `OWNED_GROUP_LEFTOVER`, `SURVIVORS≠none`, `QUARANTINE=yes`, `PROOF_EXIT≠0` or fewer than `Tests: 51 passed, 51 total` is FAIL — report, do not retry. Part 6 will attest the actual result.
