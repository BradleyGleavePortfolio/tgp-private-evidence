# S7-1′ independent review B — composition c54386ec + 13-file pinned-Prettier correction → predicted tree 7800ecb4 (source-only)

Reviewer: independent non-builder B (T4). Date: 2026-09-23 ~21:10Z. Mode: source-read only — no runtime, tests, node/npm/prettier/tsc, PG, install, commit, hooks; no peer (s7-a) conclusions read; accepted parents S3 `be0ba827` and S5 `98d39610` **not re-audited** (their evidence carried forward). Writes confined to `execution/e7d2385c/audits/s7-b/**` (scratch under `scratch/`). All git reads with `GIT_OPTIONAL_LOCKS=0`; no object written to any repository (predicted tree recomputed in Python from `ls-tree` output).

Inputs read: `execution/e7d2385c/s7-foundation-format/{READY.md, CANDIDATE_TREE.txt, FILES13.txt, PINS_BEFORE.txt, PINS_AFTER.txt, format-13files.patch, 07-merge-message.r2.txt, 08-commit-launch-r2.sh, logs/*, orig/**, src/**}` (manifest `5cbfc77788aa9158c76e2e12efebd454f63c9751986d60928e5228e12e05b910`, 44 entries, `sha256sum -c` all OK; `NEUTRALITY_EVIDENCE.txt` not relied upon — replaced by my own check §4); `execution/e7d2385c/s7-foundation/{06-commit-launch.sh, 07-merge-message.txt, logs/06-commit.log}`; worktree `worktrees/s7-foundation` (read-only); blobs of `925780e0`, `be0ba827`, `98d39610`, `c54386ec`, `7800ecb4`, `d7404cd4`.

## 1. Exact pins verified

| Item | Value | How |
|---|---|---|
| Retained merge state | `HEAD=be0ba8274e486dee77f15d18fe367a13ff08ecf5`, `MERGE_HEAD=98d39610f511505558373f3a59fa019804c94bd7`, index entries (2136) == `ls-tree -r c54386ec` exactly, `git diff` (worktree vs index) empty, no untracked | rev-parse / ls-files -s / diff |
| Merge base | `925780e0a1906593e5383c618311b6b17364b8dc` | merge-base |
| Base merge tree | `c54386ec52a0c01050be4316f70efc45f5f13cc0` (exists) | cat-file |
| Predicted successor tree | `7800ecb4d294a48ed3d7282363265e5f07339f97` (exists; independently recomputed from `c54386ec` + the 13 `PINS_AFTER` blobs → identical; sanity: same code reproduces `c54386ec` from unsubstituted listing) | Python sha1 over tree objects |
| `diff-tree c54386ec 7800ecb4` | exactly the 13 `FILES13.txt` paths, all `M`, new blobs == `PINS_AFTER` blobs, no mode change | diff-tree |
| Patch | `format-13files.patch` sha256 `462513931a608e396cd19e3efcf574b8be3ed55b135f3e655c92d4f09c77db0c`, 13 `diff --git`, touches exactly FILES13, +952/−432 content lines, no mode/rename/new/delete | grep |
| Message r2 | `07-merge-message.r2.txt` sha256 `67a3df0257e1e221d0d55d67b298131962448951c14ae816726691cce1bf4733` = approved `07-merge-message.txt` (`d94f24fd…`) + "other than the formatting noted below" + one "Formatting only" paragraph; R3 regex from `lefthook.yml` applied by me → no banned tokens | diff / grep -E |
| Launch script | `08-commit-launch-r2.sh` sha256 `613511a082846877a9cf791e3340ae804488f3413ab8e9b1afbb0ad6073fbceb` | sha256sum |
| Identity | worktree `user.name=Bradley Gleave`, `user.email=bradley@bradleytgpcoaching.com`; `core.hooksPath` unset; `.git/hooks/{pre-commit,commit-msg}` lefthook stubs → `node_modules/lefthook-linux-x64` | git config / ls |
| Toolchain in s7 worktree | `node_modules/.package-lock.json` `05bc530a…` (= S5 installed pin); `.bin/prettier` → `execution/e7d2385c/s5-continuation/tooling/prettier-3.9.6/…/prettier.cjs` sha256 `6e922134…` (= S5/S3 hook CLI pin) | readlink / sha256sum |
| Infra identical on both parents and in `c54386ec` | package.json `656d11a2`, package-lock `354de3da`, lefthook.yml `54d03749`, tsconfig.json `93f3baab`, tsconfig.build.json `12776858`, eslint.config.js `78aa2b64`, .prettierrc.json `ee1ad136`, .prettierignore `8ec6db4a`, .editorconfig `34da5eab`, jest.config.js `769a4146`, nest-cli.json `8c45e90b` | rev-parse per parent |

## 2. Composition `c54386ec` — pure disjoint union, no textual merge

- Paths changed base→S3: 49; base→S5: 31; **intersection: empty** (no path edited on both sides).
- Every one of the 31 paths where `c54386ec` differs from `be0ba827` carries exactly the `98d39610` blob; the set equals base→S5's changed paths.
- Every one of the 49 paths where `c54386ec` differs from `98d39610` carries exactly the `be0ba827` blob (including the S3-side deletion of `.github/workflows/fly-logs-dump.yml`, correctly absent); the set equals base→S3's changed paths.
- Therefore `c54386ec` = `be0ba827` ⊕ (S5 delta) with no three-way content resolution anywhere; "textually clean" is exact, not just git's report.

## 3. Scope and provenance of the 13 files

- All 13 are among the 31 S5-side paths; each index blob == `98d39610` blob (verified: exported from `c54386ec`, byte-identical to `orig/**`); the three `src/scout/*` blobs == PR529 `d7404cd4` blobs as stated (`d7404cd4` present; blobs listed in `PINS_BEFORE` match).
- The 13 are exactly the set the real pre-commit Prettier refused on 2026-09-23 20:58Z (`06-commit.log` line 471: "Code style issues found in 13 files"; the hook's `{staged_files}` list at line 316 = 25 globbed staged files; the other 12 therefore already conform).
- Independent replay: `git apply` (outside any repo) of `462513931…` onto the export → byte-identical to packet `src/**`; `git hash-object` (no write) of each result == `PINS_AFTER` blob and sha256, 13/13.
- Config unchanged: `.prettierrc.json`/`.prettierignore`/`.editorconfig` identical on both parents and untouched by the patch; Prettier CLI is the same pinned 3.9.6 link the S5 and S3 hooks executed.

## 4. Semantic neutrality — my own evidence (not the builder's)

Token-level comparison (own tokenizer: identifiers, numbers, strings with quote-escape normalisation, template literals, comments, punctuation; whitespace ignored) of `orig` vs `src` for all 13 files:

- Identifier, number, string-literal and comment multisets: **13/13 identical**.
- Template literals: 11/13 identical; the 2 differing (`test/rls-g2-tq0.spec.ts`, `test/utils/g2-pg17-harness.ts`) differ only by one trailing `,` added after the `JSON.stringify(...)` argument inside `${…}`; static template text (`v2.`) unchanged.
- Punctuation residual, per file, consists only of: added `(`/`)` wrapping multi-line boolean/ternary/arrow expressions (balanced), added trailing `,` (parameters/arguments/object and array literals), added `;` as final member separator inside object *type* literals, one leading `|` in a multi-line union type. No `{`/`}` added or removed (the READY's "block braces" wording is not borne out and not needed — arrow bodies were merely re-wrapped). No token of any other class appears in either direction.
- Conclusion: every change is Prettier punctuation/whitespace normalisation with no effect on the TypeScript AST semantics; independent of the builder's `--debug-check` claim, which is consistent with it.

## 5. S3/S5 proof applicability to tree `7800ecb4`

- S5 fresh51 (PG17.6, `98d39610`, my S5 review Part 6) input closure: `test/rls-g2-pg17-etq0.spec.ts`, `test/utils/{g2-pg17-harness.ts,g2-pg17-db.ts,g2-tq0-worker.cjs,g2-pg17-bootstrap.sh,g2-pg17-old-root.sh}`, `jest.rls.config.js`/`jest.config.js`, `prisma/migrations/20270118000000_scout_ledger_platform_expand/*` (E, read by the harness from the candidate root), the 164 old-root migrations (applied from the pinned `925780e0` checkout, **not** from the candidate's `prisma/migrations`), and the worker's product chain `src/scout/{scout-reconstruct,scout-roster,scout-entities}.service.ts` → `scout-cursor.ts`, `scout-platform.ts`, `*.dto.ts`, `../prisma.service.ts`, `../analytics/*`. In `7800ecb4` this closure is byte-identical to `98d39610` except: the 13 Prettier-formatted files (AST-identical, §4) and S3's `src/prisma.service.ts` (a 4-line log-string re-wrap, same text) — S3's `src/scout/scout.service.ts` (3-line ternary re-wrap) is not in the chain. Bootstrap's manifest gate (`git diff --quiet 925780e0 HEAD -- package.json package-lock.json`) still holds (identical blobs). → **S5 proof applies to `7800ecb4` for its input closure.**
- S3's accepted evidence covers the 49 S3 paths, none of which the formatter touched. The composed tree additionally carries S3's `20261224000000_rls_close_public_exposure` migration (166 migration dirs vs 165 at `98d39610`); the PG17 proof never applies repository migrations other than E, so this neither breaks nor is exercised by it (C5).
- Hook evidence: at the failed attempt (same `c54386ec` content, real hooks), `prod-readiness-quick`, `banned-cast-tokens` and `eslint` **passed**; `prettier` refused 13 files (now corrected); `tsc` died with V8 heap OOM after 65 s (exit 134) because `06-commit-launch.sh` exported only `GIT_OPTIONAL_LOCKS=0 LEFTHOOK_VERBOSE=1` — no `NODE_OPTIONS`. The S5 candidate hooks ran with `NODE_OPTIONS='--max-old-space-size=4096'` (s5-continuation logs 02/03/08). The OOM is therefore an environment omission of that attempt, not a product defect; the r2 script restores the established binding.

## 6. Prepared commit activation `08-commit-launch-r2.sh` (source review)

- Env: `NODE_OPTIONS=--max-old-space-size=4096` (established S5/S3 binding), `GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 npm_config_offline=true`, notice suppressions, `LEFTHOOK_VERBOSE=1`; no `LEFTHOOK=0`, no `--no-verify`, no tsconfig/eslint/lefthook edits → hooks are genuine (five pre-commit jobs + commit-msg R3).
- Preconditions stop (rc 70) on: HEAD ≠ `be0ba827`, MERGE_HEAD ≠ `98d39610`, `write-tree` ≠ `c54386ec`, unstaged/untracked present, patch sha ≠ `CANDIDATE_TREE.txt` pin. Then `git apply --index`, `write-tree` must equal `7800ecb4` (rc 71), no unstaged residue (rc 71), then `timeout -k 30 600 git commit -F 07-merge-message.r2.txt`; records rc, HEAD, tree; sentinel. No retry, no fallback path.
- Consequence analysis: hooks are check-only (`prettier --check`, `eslint` without `--fix`) so the committed tree is the index = `7800ecb4`. A hook refusal or the 600 s bound leaves no commit (hooks precede object creation) but leaves the patch applied and staged — a visible, reversible state change to the retained merge worktree (C3). Expected commit: parents `be0ba827` (1st) and `98d39610` (2nd) from `MERGE_HEAD`, tree `7800ecb4`, author = committer = Bradley Gleave, message `67a3df02…`, no trailers.

## 7. Findings

**Class A: none. Class B: none.** Class C (record only, no cycle):

- C1 Prettier is not a package.json dependency; the hook resolves `npx prettier` via the `node_modules/.bin/prettier` link to the out-of-tree pinned 3.9.6 CLI (`6e922134…`) — identical to what the accepted S5/S3 hook runs used; carried forward, recorded for provenance.
- C2 The launch script has no free-memory/slot guard; `tsc` at 4096 MB plus parallel `eslint`/node runs must not overlap S6's heavy runtime on this 8 GB host. Activation only after S6's release (already the parent's binding). The prior OOM at default heap is not evidence about 4096 MB, which succeeded for the S5 hooks.
- C3 Failure after `git apply --index` (hook refusal or bound) leaves the 13 formatted files staged in `worktrees/s7-foundation`; recoverable (`git checkout -- .` / `read-tree c54386ec`) but must be recorded, not silently retried. Script also does not assert parents/author after the commit — the receipt step must.
- C4 `eslint` passed on the *unformatted* 13 files; the formatted bytes have not been linted. `eslint.config.js` has no stylistic/formatting rules (recommended sets + project rules only), so a refusal is not expected; if it occurs the hook is fail-closed.
- C5 The composed tree carries S3's RLS migration and S3's src changes that the S5 PG17 proof does not exercise, and S5's E migration/services that S3's evidence does not exercise. Each parent's proof applies to its own input closure (§5); cross-side runtime integration is not proven by either and was not requested at S7-1′.
- C6 Line-count growth (e.g. harness 229→360, spec 512→695) is entirely re-wrapping (§4); no content growth.
- C7 `git status --porcelain` in the merge worktree shows 31 staged entries (merge in progress); "clean" here correctly means worktree == index and no untracked, which is exactly what the script's `precondition-dirty` tests.

## 8. Verdict (source phase) — FROZEN

**GRANTABLE.** Composition `c54386ec` is an exact disjoint union of the accepted parents; the correction is confined to the 13 files the real hook refused, produced by the same pinned Prettier and unchanged config, independently shown token-neutral; the predicted tree `7800ecb4` is exactly base + those 13 blobs; the approved message `67a3df02…` passes the R3 rule; the prepared activation commits with genuine hooks under the established `NODE_OPTIONS` 4096 binding and fails closed on any drift. No A/B blocker. Activation may proceed when the parent releases the heavy slot (C2). Same-review acceptance for the actual commit (to be appended as Part 2, no new cycle):

- `08-commit.log`: `TREE_AFTER_APPLY=7800ecb4d294a48ed3d7282363265e5f07339f97`; lefthook summary with **all five** pre-commit jobs ✔️ (`prod-readiness-quick`, `banned-cast-tokens`, `eslint`, `prettier`, `tsc`) and commit-msg ✔️; `COMMIT_RC=0`.
- New head: `git cat-file -p HEAD` shows `tree 7800ecb4…`, `parent be0ba8274e486dee77f15d18fe367a13ff08ecf5`, `parent 98d39610f511505558373f3a59fa019804c94bd7`, author == committer == `Bradley Gleave <bradley@bradleytgpcoaching.com>`, message bytes == `67a3df02…`, no trailers; `MERGE_HEAD` gone; `status --porcelain` empty; `diff-tree HEAD^1 HEAD` == the 31 S5 paths ⊕ 13 formatted; `diff-tree HEAD^2 HEAD` == the 49 S3 paths ⊕ 13 formatted.
- Any refusal: record exact hook/job and rc; no retry, no `--no-verify`, no config change.

---

# Part 2 — appended 2026-09-23 ~21:27Z: final attestation of the actual S7-1′ head `5c760b77` against the frozen §8 acceptance (same review; no re-audit)

Read raw: `s7-foundation-format/logs/08-commit.{log,sentinel}`, `PRELAUNCH_R2.txt`, `POSTCHECKS.txt`, `APPROVALS.txt`, `RUNTIME_RELEASE.txt`, `OWNERSHIP.txt`, terminal `MANIFEST.sha256` `4c08991a3d777908d0b46acf9d7b1c3f8255946d86ffbb9da734fb84e02c2446` (`sha256sum -c` all OK); the commit object itself via `git cat-file`; worktree state; bundle verify. No runtime, no tests, no peer conclusions.

## 2.1 §8 checklist

| Required (§8) | Observed | |
|---|---|---|
| `TREE_AFTER_APPLY=7800ecb4…` | `08-commit.log` line 3 exactly; `R2_START … NODE_OPTIONS=--max-old-space-size=4096 bound=600s`; `APPLY` 21:19:06Z | PASS |
| Five pre-commit jobs ✔️ | lefthook v2.1.9 `summary: (done in 47.84 seconds)`: ✔️ prod-readiness-quick, ✔️ banned-cast-tokens, ✔️ prettier ("All matched files use Prettier code style!" on the 25 globbed staged files), ✔️ eslint (22 ts files incl. the 13 formatted), ✔️ tsc (47.83 s, no OOM) | PASS |
| commit-msg ✔️ | `lefthook run commit-msg .git/COMMIT_EDITMSG` → ✔️ no-ai-tokens | PASS |
| `COMMIT_RC=0` | sentinel `COMMIT_RC=0 STAGE=commit END=2026-09-23T21:19:54Z HEAD=5c760b77…`; log `COMMIT_END … rc=0 HEAD=5c760b77… tree=7800ecb4…` | PASS |
| Raw commit object | `tree 7800ecb4d294a48ed3d7282363265e5f07339f97`; `parent be0ba8274e486dee77f15d18fe367a13ff08ecf5`; `parent 98d39610f511505558373f3a59fa019804c94bd7` (in that order; `rev-list --parents` confirms); `author` = `committer` = `Bradley Gleave <bradley@bradleytgpcoaching.com>` 2026-09-23T21:19:06Z; commit object sha256 `87596775fcbb16b0…` | PASS |
| Message bytes == `67a3df02…` | raw object body (after header blank line) `cmp` equal to `07-merge-message.r2.txt`; sha256 `67a3df0257e1e221…`; `interpret-trailers --parse` → 0 trailers | PASS |
| `MERGE_HEAD` gone, porcelain empty | both `.git/MERGE_HEAD` and `.git/MERGE_MSG` absent; `status --porcelain --untracked-files=all` = 0 | PASS |
| `diff-tree HEAD^1 HEAD` == 31 S5 paths ∪ 13 | exact set equality | PASS |
| `diff-tree HEAD^2 HEAD` == 49 S3 paths ∪ 13 | exact set equality | PASS |
| `diff-tree c54386ec HEAD` == exactly the 13 `M` | exact; 13 blobs at HEAD == `PINS_AFTER` blobs (0 mismatches) | PASS |
| No refusal / retry / `--no-verify` / config change | single run 21:19:05Z–21:19:54Z; lefthook loaded `worktrees/s7-foundation/lefthook.yml`; manifests unchanged (`POSTCHECKS`: package.json `656d11a2`, lock `354de3da`, lefthook `54d03749`, tsconfig `93f3baab`, prettierrc `ee1ad136`); `node_modules/.package-lock.json` still `05bc530a…` | PASS |
| Terminal state | bundle `s7-foundation-5c760b77…-from-public-c23b9d9f.bundle` sha256 `3e81299de71ab01a…`, `git bundle verify` okay, head `5c760b77`; pin ref `refs/s7/foundation-5c760b77…`; S5 worktree HEAD `98d39610` porcelain 0 (untouched); no tsc/eslint/prettier/lefthook processes (only the sandbox `/opt/code-mode` daemon pids 297/332); heavy slot released 21:20:28Z | PASS |

## 2.2 Class C records (no cycle)

- C8 `PRELAUNCH_R2.txt` printed `FAIL no-unstaged-or-untracked: got 20 want 0` and `preconditions_ok=0`, yet the launch proceeded: the executor's check counted staged `A ` (added-by-merge) porcelain lines as failures, and its `ok=` flag was set inside a pipeline subshell so the stop never fired. This is an executor-check defect, not a state defect: the launcher's own guards (`git diff --name-only` empty, no `??`, HEAD/MERGE_HEAD/index tree/patch pin) ran and passed, and the resulting commit is exactly the predicted tree. Consequence: none for this head; a real dirty state would still have been caught by the launcher (rc 70). Recorded as C (matches my C7: porcelain shows merge-staged entries by design).
- C9 `POSTCHECKS` "message bytes" line compared `git log --format=%B` output (trailing newline appended) → sha `166cacaa…`, 2 diff lines; the raw commit object body is byte-identical to the approved file (`cmp` equal, `67a3df02…`), verified by me directly. Report wording corrected in its own NOTE.
- C10 `POSTCHECKS` "processes: 3 leftover" was a census self-match of wrapper shells; wrapper-excluded recount = 1 = the sandbox platform daemon (pid 297), not a hook process; my own `pgrep` confirms only the platform daemon pids.
- C4 closed: eslint has now run on the formatted 13 files and passed.
- C2 moot: run after S6 release with `mem_avail_mb=7692`, tsc 47.8 s at 4096 MB.

## 2.3 Acceptance boundary (Part 2) — FROZEN

**S7-1′ foundation head `5c760b774598532e90d5d217e15adc9285c3c3f4` / tree `7800ecb4d294a48ed3d7282363265e5f07339f97`: ACCEPTED within this review's boundary.** It is the two-parent composition of the accepted S3 head `be0ba827` (1st parent) and the accepted S5 head `98d39610` (2nd parent), plus exactly the 13 pinned-Prettier formatted blobs shown token-neutral in Part 1 §4, committed with all five genuine pre-commit hooks and the commit-msg hook passing under the established `NODE_OPTIONS` 4096 binding, operator identity in both fields, no trailers, approved message bytes, clean worktree, verified bundle.

What this attests: composition exactness, formatter scope/neutrality, genuine-hook commit evidence, and applicability of each parent's accepted proof to its own input closure in this tree (Part 1 §5). What it does not attest: any new runtime proof on `5c760b77` (none was run or requested), cross-side runtime integration (C5), importer completion, or acceptance beyond S7-1′. No A/B open; Part 1 verdict stands unchanged. Reviewer B's S7-1′ work is complete.
