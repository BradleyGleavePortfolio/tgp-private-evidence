# S7-1 independent A — composition and formatter-only source review

**SOURCE GRANTABLE: no open A/B finding.** The exact accepted-parent composition plus the frozen 13-file formatting delta is suitable for the prepared ordinary-hook commit with restored `NODE_OPTIONS=--max-old-space-size=4096`, when the parent transfers runtime ownership; no repeat S3/S5 test or PG proof is warranted by this delta. ([independent derivation](evidence/independent-pins.txt), [complete reviewed delta](inputs/format/format-13files.patch), [ordinary commit route](inputs/format/08-commit-launch-r2.sh))

Reviewer A, independent nonbuilder, T4 individual/cumulative, parent-model inheritance without asserted runtime model identity. Static source/diff/hash/Git inspection only; no candidate tooling, formatter, hook, test, install, PG or process census executed. No current peer conclusions read; accepted parents were not re-audited.

## Exact inputs

| Binding | Exact identity |
|---|---|
| First parent, accepted S3 | `be0ba8274e486dee77f15d18fe367a13ff08ecf5` |
| Second parent, accepted S5 | `98d39610f511505558373f3a59fa019804c94bd7` |
| Merge base | `925780e0a1906593e5383c618311b6b17364b8dc` |
| Independently composed base tree | `c54386ec52a0c01050be4316f70efc45f5f13cc0` |
| Frozen formatter packet manifest | `5cbfc77788aa9158c76e2e12efebd454f63c9751986d60928e5228e12e05b910` |
| 13-file patch SHA-256 | `462513931a608e396cd19e3efcf574b8be3ed55b135f3e655c92d4f09c77db0c` |
| **Independently derived successor tree** | **`7800ecb4d294a48ed3d7282363265e5f07339f97`** |
| Parent-approved message SHA-256 | `67a3df0257e1e221d0d55d67b298131962448951c14ae816726691cce1bf4733` |
| Prepared launcher SHA-256 | `613511a082846877a9cf791e3340ae804488f3413ab8e9b1afbb0ad6073fbceb` |

The table's byte identities are independently verified, and all **44/44** frozen packet entries pass hash verification; message authorization is the parent's explicit assignment, not an approval inferred from builder prose. ([independent pins](evidence/independent-pins.txt), [packet check](evidence/packet-manifest-check.txt))

## Composition and scope

An independent `merge-tree` using only my own object store reproduced `c54386ec…` without conflicts; S3/S5 changed-path sets from their common base have an empty intersection, and applying the frozen patch to my own index yielded `7800ecb4…`. ([derivation](evidence/independent-pins.txt), [S3 paths](evidence/s3-paths.txt), [S5 paths](evidence/s5-paths.txt), [intersection](evidence/parent-path-intersection.txt))

Every original formatter file equals its base-merge and S5 blob; every successor file equals the frozen formatted blob, and the only base→successor changes are the exact **13 listed TypeScript paths**—three production Scout files and ten tests/helpers. ([per-file comparisons](evidence/independent-pins.txt), [exact path list](evidence/derived-changed-paths.txt))

Dependency manifests/lock, lefthook, TypeScript/ESLint/formatter configuration are identical across both parents and successor; schema, real PG17 51-case spec, bootstrap and worker bytes remain S5-identical, and the copied installed lock remains `05bc530a…`. ([config/proof bindings](evidence/independent-pins.txt))

## Semantic neutrality and evidence applicability

I read the complete 1,999-line patch: changes reflow expressions/arguments/type members, add enclosing parentheses or trailing commas/leading union pipes, and expand existing single-line blocks without altering statement order, arguments, literals, query predicates, exception paths, child cleanup, or assertions. ([complete patch](inputs/format/format-13files.patch))

The already-executed pinned Prettier evidence records original `--debug-check` raw 0 on all 13 paths, formatting raw 0, final check raw 0 and second-write idempotence; its actual implementation compares formatter-normalized ASTs and idempotence, supporting the inspected delta rather than requiring another formatter run. ([actual formatter log](inputs/format/logs/format.log), [debug-check implementation excerpt](evidence/prettier-debug-check-excerpt.txt), [pinned CLI hash](evidence/independent-pins.txt))

The three production changes preserve cursor/platform validation and reconstruction contention/outcome logic; the PG17 helpers preserve role/target guards, redaction, ownership and settlement behavior, and no proof assertion or selection changes. ([production and helper diffs](inputs/format/format-13files.patch))

Accordingly the accepted parents' evidence remains applicable at its original boundaries, including S5's actual fresh PG17.6 51-case result, with formatting-only applicability explicitly recorded—not relabeled as a fresh execution on the successor. ([S5 final attestation](inputs/accepted/S5_FINAL_ATTESTATION.md), [S3 attributable validation record](inputs/accepted/S3_REPORT.md), [unchanged proof bindings](evidence/independent-pins.txt))

## Preserved failure and minimum execution

The first ordinary commit **failed raw 1**: actual log lines 458–471 name **13** formatter refusals, and lines 487–503 show TypeScript heap OOM/exit **134**; commit-msg was not reached and no successor commit resulted, so neither formatter nor composed typecheck acceptance is inherited from that attempt. ([failed raw hook log](inputs/failed-attempt/logs/06-commit.log), [sentinel](inputs/failed-attempt/logs/06-commit.sentinel), [retained state](evidence/retained-state-and-index.txt))

The original “two files” diagnosis is superseded by its preserved count correction; the launcher omitted the established 4096-MB Node setting, which the new route restores without changing/excluding TypeScript inputs. ([preserved correction](inputs/failed-attempt/CORRECTION_PRETTIER_COUNT.md), [old launcher](inputs/failed-attempt/06-commit-launch.sh), [accepted S5 environment](evidence/hook-environment-bindings.txt), [accepted S3 environment](inputs/accepted/S3_REPORT.md), [new launcher line 6](inputs/format/08-commit-launch-r2.sh))

The prepared route checks the exact two parents/retained index/unstaged state, applies only the pinned patch, enforces successor tree `7800ecb4…`, and invokes normal `git commit -F` under a 600-second timeout with 30-second kill grace; actual installed hooks/config call R75, Prettier, max-warnings-zero ESLint, TypeScript and commit-message checking, not bypasses. ([launcher lines 10–22](inputs/format/08-commit-launch-r2.sh), [installed pre-commit](inputs/hooks/pre-commit), [installed commit-msg](inputs/hooks/commit-msg), [unchanged commands](inputs/hooks/lefthook.yml))

**Unlocked execution:** after parent runtime transfer, one existing corrected ordinary-hook commit attempt on the retained merge, using the exact approved message and environment; preserve any refusal and stop, with no unrelated control, install or PG rerun.

## Final boundary still missing

No successor commit or successful corrected hook result is attested here; the retained HEAD is S3, with S5 in MERGE_HEAD and the unformatted composed index awaiting activation. ([retained identity/index](evidence/retained-state-and-index.txt))

Later append to this same review the actual raw hook/sentinel result and committed object: expected ordered parents **S3 then S5**, tree **`7800ecb4…`**, exact approved message, Bradley author **and** committer, no trailers, clean worktree, unchanged hooks/dependencies and attributable bundle/head identity under the prepared route. ([existing post-commit boundary](inputs/failed-attempt/PREPARED.md), [approved message bytes](inputs/format/07-merge-message.r2.txt))

This is source grantability for S7-1 foundation composition only—not a remote push/merge, deployment, real-customer/importer completion, new database proof, C1 completion or S6 acceptance.
