# S5 independent A — final exact-boundary attestation

**ACCEPTED for the frozen S5 exact-head / real fresh PostgreSQL 17.6 51-case proof boundary. No open A/B finding in this review.** The actual authorized full run completed all 51 selected cases with raw live status 0, successful bootstrap and stop, no survivors/quarantine, and a successful outer sentinel on the previously reviewed hooked candidate. ([actual case outcomes](final-inputs/logs/live-etq0-20260923T203841Z.log), [raw sequence](final-inputs/logs/run-full-20260923T203841Z.log), [terminal](final-inputs/logs/exit-full-20260923T203841Z.log), [sentinel](final-inputs/logs/full-20260923T203841Z.sentinel), [source/hook judgment](REPORT.md))

Independent nonbuilder reviewer A; T4 individual/cumulative; parent-model inheritance without an asserted runtime model identity. This is the final actual-result append to the existing review, not a new source audit. I performed only file/hash inspection and preservation; no runtime, test, install, census, candidate edit, or new criterion.

## Exact binding

The runtime packet manifest is **`ce4edd98401b0bcb3e67e503b2c924446788f3301673482176c88321c6347104`**; all **11/11** packet entries and **13/13** separately recorded original-log hashes independently verify, and complete attributable logs are preserved here. ([packet check](final-evidence/packet-manifest-check.txt), [log check](final-evidence/log-hash-check.txt), [independent bindings](final-evidence/independent-bindings.txt))

| Accepted binding | Exact value |
|---|---|
| Run | `20260923T203841Z`, full |
| Hooked HEAD | `98d39610f511505558373f3a59fa019804c94bd7` |
| Tree | `67fc1db5f353f0d363fe7134a78d455c0decfb55` |
| Runner rev 7.2 SHA-256 | `16c763f408544529ca4a11b40d61a57bc61e5e0c07023091b70253b541b9a73a` |
| Fixture SHA-256 | `3a7d57bf951ab27e2161dc91db1d816f31d4af079ede076e7a2dfd1c44f3a721` |
| Launcher SHA-256 | `a03836d524bafc28572b1e600f34148d8e9ddea38391ffc427c26f5399b9f728` |
| Installed lock SHA-256 | `05bc530aa44bfa6df64f0daa8edb66c5181abf4bfbc309bd8da2c8aff37b6a44` |
| Server binary SHA-256 | `23cd174849b273064c47d581b55be596be2f5cf0ee5d3e76c0146e2464bf873a` |

These bindings match the reviewed activation and rev 7.2 closure, the actual clean/no-dirty-fingerprint stamp, launch record and unchanged post-run identity; the genuine hooked-head evidence carries forward rather than being inferred from the runtime receipt. ([stamp](final-inputs/logs/env-full-20260923T203841Z.log), [launcher](final-inputs/logs/full-20260923T203841Z.launcher.log), [post-run identity](final-inputs/POSTRUN_IDENTITY.txt), [rev 7.2 grant](RUNNER72_REPORT.md), [source/hook evidence](REPORT.md))

## Frozen checklist: actual result

| Existing acceptance item | Independently read result |
|---|---|
| Exact source / dependencies / environment | Clean expected HEAD/tree and installed lock; PostgreSQL server 17.6 binary matches, recorded client remains psql 18.6; data directory absent before init. [Stamp](final-inputs/logs/env-full-20260923T203841Z.log) |
| Owned full execution | Offline guard passed; canonical lock held, exclusivity confirmed; guard **27/27** and all supervised child END records raw **0**, timed_out **0**. [Run](final-inputs/logs/run-full-20260923T203841Z.log), [guard](final-inputs/logs/guard-unit-20260923T203841Z.log) |
| Independent O / fresh fixture | Existing detached O `925780e0a1906593e5383c618311b6b17364b8dc` reverified with 164 migrations; fresh init/start succeeded; loopback port 54325, server `170006`, exact marked directory, zero target/sessions and no hosted roles. [O](final-inputs/logs/oldroot-20260923T203841Z.log), [fixture](final-inputs/logs/fixture-20260923T203841Z.log), [preflight](final-inputs/logs/preflight-full-20260923T203841Z.log) |
| Real bootstrap / runtime provenance | 164 prior migrations successfully applied; O and candidate engines match `a2924eab…`; actual O copied runtime and 130-byte preamble, pinned candidate runtime and exact fixture identity recorded; `G2_PG17_BOOTSTRAP_OK`, raw **0**. [Bootstrap](final-inputs/logs/bootstrap-20260923T203841Z.log) |
| Actual committed suite | Exact `jest.rls.config.js` / `test/rls-g2-pg17-etq0.spec.ts` command; actual server identity; all **51 named cases passed**, **1/1 suite**, no skipped cases or `PG17_TEARDOWN_SKIPPED`, live raw **0**. [Full live log](final-inputs/logs/live-etq0-20260923T203841Z.log) |
| Stop / terminal / outer bound | `S5_FIXTURE_STOP_OK`; **PROOF_EXIT=0 FIRST_RC=0 STOP_RC=0 DAEMON=none SURVIVORS=none SIGNALLED=none QUARANTINE=no**; **FULL_EXIT=0 OUTER_BOUND=no**. [Fixture](final-inputs/logs/fixture-20260923T203841Z.log), [terminal](final-inputs/logs/exit-full-20260923T203841Z.log), [sentinel](final-inputs/logs/full-20260923T203841Z.sentinel) |
| Post-run binding / release | Same clean source, hooks and installed lock; expected O dependency symlink/client only, other recorded npm-root facts unchanged; stopped marked cluster retained, no postmaster file, named execution PIDs gone and lock released at **20:43:39Z**. [Before/after facts](final-inputs/logs/env-full-20260923T203841Z.log), [identity](final-inputs/POSTRUN_IDENTITY.txt), [release](final-inputs/RUNTIME_RELEASE.txt) |

I read the actual selected outcomes, including migration/RLS preservation, real O/T and T/T contention, provenance/atomicity/accounting, Q0 scoped reads and rollback/lock boundaries; temporary future-schema tie characterization and simulated operator drain retain their existing limits rather than becoming deployment evidence. ([51 named outcomes](final-inputs/logs/live-etq0-20260923T203841Z.log), [original proof boundary](REPORT.md))

## C — observed drain cause, bounded attribution; continue

The successful run's old-root drain identifies seven shell/Git-wrapper plus `sleep 1` pairs, all naturally gone after one drain iteration with `remaining=none`; `/usr/bin/git` SHA-256 `e01850e8a76435075dcfcb73c5cf63d22c177f5730d01e29d91307b72b4e3818` line 27 backgrounds a one-second tee watchdog, matching the observed current-run helpers rather than the earlier speculative process-substitution explanation. ([actual drain](final-inputs/logs/run-full-20260923T203841Z.log), [wrapper lines 23–28](final-inputs/git-wrapper.sh), [wrapper hash](final-evidence/independent-bindings.txt))

This establishes the current drain's attributable mechanism, not retroactive identification of the first attempt's ten unrecorded PIDs; the executor's stronger retrospective claim is qualified accordingly, with no product finding, change, new control or rerun required. ([current receipt section 4](final-inputs/RECEIPT.md), [preserved first-attempt limits](PART3_ACTUAL_RESULT.md))

The post-run census's disclosed wrapper self-match/recount is retained as attributable executor evidence, not silently normalized or independently re-executed; the actual terminal and named-PID/lock/stop records support the accepted boundary. ([post-run record](final-inputs/POSTRUN_IDENTITY.txt), [terminal](final-inputs/logs/exit-full-20260923T203841Z.log), [release](final-inputs/RUNTIME_RELEASE.txt))

## Grant and limit

Reviewer A's **final S5 acceptance is granted at the exact binding above**, joining the preserved source/hooked-head verdict to this real fresh51 result; no S5 proof rerun or further source-review cycle is required by this review. ([source verdict](REPORT.md), [rev 7.2 closure](RUNNER72_REPORT.md), [actual live result](final-inputs/logs/live-etq0-20260923T203841Z.log), [terminal](final-inputs/logs/exit-full-20260923T203841Z.log))

The first attempt remains **failed/incomplete**, every earlier seal is preserved, and this acceptance neither rewrites that failure nor substitutes for independent reviewer B's attestation. ([Part 3](PART3_ACTUAL_RESULT.md), [prior seals](final-evidence/independent-bindings.txt))

This grants **only S5's frozen proof boundary**: not broader importer/product completion, customer/source-account proof, deployment/merge/enablement, real operator drain, later B/drain→R→N/Q1→C stages, S6 acceptance, or destructive cluster cleanup.
