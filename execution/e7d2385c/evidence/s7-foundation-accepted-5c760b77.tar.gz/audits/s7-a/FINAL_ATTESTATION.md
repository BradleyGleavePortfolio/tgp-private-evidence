# S7-1 independent A — final actual-head attestation

**ACCEPTED at the exact local foundation-composition boundary. No open A/B finding.** The actual two-parent commit matches the source-reviewed successor tree, preserves the approved message/identity, and completed the ordinary pre-commit and commit-message route with raw **0**; this closes this review's pending actual-head boundary, not broader importer completion. ([actual commit object](final-evidence/actual-commit.txt), [independent bindings](final-evidence/independent-bindings.txt), [raw hook log](final-inputs/logs/08-commit.log), [terminal sentinel](final-inputs/logs/08-commit.sentinel))

Reviewer A, independent nonbuilder, same S7-1 review, T4 individual/cumulative. File/hash/Git inspection only; no hook, formatter, test, install, PG, census, new control, source re-audit or peer-current-conclusion reading.

## Exact final binding

| Item | Independently verified identity |
|---|---|
| **Actual committed HEAD** | **`5c760b774598532e90d5d217e15adc9285c3c3f4`** |
| **Tree** | **`7800ecb4d294a48ed3d7282363265e5f07339f97`** |
| First parent | `be0ba8274e486dee77f15d18fe367a13ff08ecf5` |
| Second parent | `98d39610f511505558373f3a59fa019804c94bd7` |
| Terminal packet manifest | `4c08991a3d777908d0b46acf9d7b1c3f8255946d86ffbb9da734fb84e02c2446` |
| Approved/raw message SHA-256 | `67a3df0257e1e221d0d55d67b298131962448951c14ae816726691cce1bf4733` |
| Actual raw hook log SHA-256 | `a8c18a1313e778dc30ee36152ac26fee27e285d7f1420fa51b351b3b3f152f84` |
| Verified bundle SHA-256 | `3e81299de71ab01afae66bd0188cedd3eb7737135e1e8b52667377b2f0fc8b97` |

All **54/54** terminal packet entries verify; the actual commit has exactly the two ordered parents above, Bradley Gleave `<bradley@bradleytgpcoaching.com>` as both author and committer, no trailers, a byte-exact approved raw message, clean porcelain and no MERGE_HEAD. ([packet check](final-evidence/packet-manifest-check.txt), [raw object](final-evidence/actual-commit.txt), [independent identity/message checks](final-evidence/independent-bindings.txt))

The reviewed launcher and installed hooks are unchanged, hooksPath is unset, copied installed lock remains `05bc530aa44bfa6df64f0daa8edb66c5181abf4bfbc309bd8da2c8aff37b6a44`, and base-composition→HEAD is still precisely the reviewed 13-file path set; equality of the committed tree to the independently derived source-phase tree carries the prior source verdict without another audit. ([independent checks](final-evidence/independent-bindings.txt), [actual paths](final-evidence/actual-delta-paths.txt), [source-phase report](REPORT.md))

The bundle independently verifies, names this exact HEAD and requires baseline `c23b9d9f3fcc106b92c061ceb7d04d7ec53038d7`; no remote publication or deployment is inferred. ([bundle verification](final-evidence/independent-bindings.txt))

## Actual ordinary-hook execution

Raw log lines **1–4** bind `NODE_OPTIONS=--max-old-space-size=4096`, launch **21:19:05Z**, patch application and exact successor tree before commit; lines **449–473** record R75 success, Prettier success, ESLint success, TypeScript success and the prod-readiness-quick job's zero result, followed by commit-msg/no-ai-tokens success at **510–511**. ([actual log](final-inputs/logs/08-commit.log))

The no-op qualification remains: prod-readiness-quick's absent script is **not production-readiness evidence**, although the ordinary job returned zero; R75, formatter, lint, typecheck and message validation actually ran. ([preserved qualification](FINDINGS.md), [actual commands/results](final-inputs/logs/08-commit.log), [unchanged hook definition](inputs/hooks/lefthook.yml))

Line **582** and the sentinel both record **COMMIT_RC=0** at **21:19:54Z** on the exact new HEAD/tree, within the prepared bound; the attributable release reports no run-related leftovers and slot release at **21:20:28Z**, without a duplicate census by this reviewer. ([raw terminal](final-inputs/logs/08-commit.log), [sentinel](final-inputs/logs/08-commit.sentinel), [release](final-inputs/RUNTIME_RELEASE.txt), [qualified postchecks](final-inputs/POSTCHECKS.txt))

## C observations — preserved, no further cycle

- **Prelaunch false FAIL:** the executor's separate prelaunch record says `got=20` and preserves its explanation that staged `A ` paths were incorrectly counted and a pipeline-subshell assignment did not stop launch; it is not treated as a passed check. ([prelaunch record](final-inputs/PRELAUNCH_R2.txt))
  The reviewed launcher independently rejects unstaged/untracked state and wrong parents/index/tree, its successful route reaches the exact expected tree and ordinary hooks, and the actual final object is independently clean and exact; therefore that redundant executor-check defect does not invalidate this committed-head decision or require another run. ([launcher lines 10–20](inputs/format/08-commit-launch-r2.sh), [actual execution](final-inputs/logs/08-commit.log), [actual object/state](final-evidence/independent-bindings.txt))
- **Message formatting / parent-count labels:** `%B` display added a newline and produced the initial postcheck mismatch; independent raw-body extraction and byte comparison resolve it to the approved SHA, while `parent_count=3` in the receipt counts HEAD plus two parents, not three parent records. ([original/corrected postchecks](final-inputs/POSTCHECKS.txt), [raw object](final-evidence/actual-commit.txt), [independent raw message comparison](final-evidence/independent-bindings.txt))
- **Census wording:** the initial “3 leftover” count and subsequent wrapper/platform-daemon corrections remain in the record; run-related-zero is attributable executor evidence, not my independent process observation or an invented retrospective identity claim. ([full postcheck notes](final-inputs/POSTCHECKS.txt), [release](final-inputs/RUNTIME_RELEASE.txt))

The failed first hook attempt remains failed and its 13-file refusal/TypeScript OOM evidence is preserved; the source-phase seal **`9e9ca7bd998dcb95c9154f33ab490cda79e61e4ed4d1cabe8a3e46f1acabe1a7`** remains unchanged, with this final append separately sealed. ([failed attempt](inputs/failed-attempt/logs/06-commit.log), [source manifest](MANIFEST.sha256))

## Exact acceptance limit

Reviewer A grants **final S7-1 local foundation composition / genuine hooked-head acceptance at `5c760b77…`**, carrying accepted S3/S5 evidence only at the already-recorded boundaries and the reviewed formatter-only applicability; no new PG run or broader integrated-customer proof is claimed. ([source applicability decision](REPORT.md), [actual committed identity](final-evidence/independent-bindings.txt))

This is not the peer's independent attestation, a product remote push/merge, deployment/enablement, C1 or subsequent lifecycle completion, S6 acceptance, or mission/importer completion.
