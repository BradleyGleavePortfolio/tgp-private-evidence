# S6 P2 review B — changed-byte follow-up (source phase)

Reviewer: independent nonbuilder B (lifecycle/integration lens). Static file/hash/diff inspection only; no runtime, install, hook, candidate or worktree write. Builder conclusions (`s6-p2/REPORT.md`) not read; `FINDING_CLOSURE_MAP.md` and `P2_VALIDATION_REQUEST_DELTA.md` read as inputs and re-derived. Peer P2 findings not read. P1 source-phase bytes unchanged.

## 1. Pins re-derived

| Item | Value | Verification |
|---|---|---|
| Sealed P2 packet | `s6-p2/MANIFEST.sha256` sha256 `1cf14b97eb856b4dbd8e98ba53d2da25fd7abe47733cd042d3dda3d93454db6a`; 40/40 entries OK | own `sha256sum -c` |
| `p2-product.patch` / `p1-to-p2.patch` | `c9d0f835…` / `93d799db…` | own hashes match pins |
| Worktree `worktrees/s6-p2` | HEAD `d51a1910…`, 0 remotes, porcelain = the nine P1 lines, `diff-index` names only the six modified paths | own git read-only queries |
| Worktree vs `s6-p2/candidate/` | nine paths `cmp` identical | `p2/verify-p2-bytes.txt` |
| Unchanged vs P1 | `App.tsx`, `RootNavigator.tsx`, `queryClient.persister.test.ts`, `rootNavigatorPersistedCacheGate.test.tsx` byte-identical to my P1 packet copies | same log |
| Changed vs P1 | gate `c41d176f…`, `queryClient.ts` `53f752d3…`, `authActions.ts` `8bb68bff…`, identityGate test `5192c842…`, signout test `77fa75c8…` (blob ids recomputed with `git hash-object`, no `-w`) | same log |
| **P2 candidate tree** | **`dddd7c2872b4f9e52b2bb4382b4456d1ea3ea402`** — re-derived by pure SHA-1 tree hashing over `ls-tree -r d51` plus the nine blob ids, no object written | `p2/tree-rederivation.txt` |
| Lock/package/hazard/adapter | untouched (not in diff); hazard pair hashes as in P1 | — |

## 2. Verdict

**NOT source-closed as delivered: one Class A (S6-B-P2-01), no Class B, six Class C.** A02 and A03 closures are verified from the bytes. The A01 closure removes the orphan-persistence mechanism but, in the very scenario S6-A-01 premised, leaves the previous identity's memory uncleared for a fresh gate instance, which then commits the next identity on top of it (details, minimum correction and reachability qualifier in `P2_FINDINGS.md`). Grantable for the bounded validation once that minimal correction (module-lifetime dirty state + one extended assertion) is applied and its changed bytes re-reviewed — or if the parent narrows the S6-A-01 premise, in which case the finding reclassifies with it and P2 is grantable as is.

## 3. Closure verification (own trace on full P2 files)

**S6-A-01 (gate unmount).** Cleanup (`gate:139-149`) bumps `transitionRef` synchronously and retires the persistence this effect created via the local `created` handle; every later checkpoint (`:98,105,110-111,117,128`) fails, and `createIdentityPersistence`/`restore`/`subscribe` cannot run after unmount. If unmount happens during `restore`, `created` is retired so the restore→hydrate fence (`queryClient.ts:~304`) and `retire()`'s unsubscribe cover both halves. Same-instance identity changes behave as P1 (retired set hand-off; the effect-start `activeRef` add is now dead, C-P2-4). **Orphan mechanism closed.** Resulting invariant *not* preserved: the owed step-3 clear dies with the instance (`memoryDirtyRef` is `useRef`), see A finding.

**S6-A-02 (signOut boundary).** `queryClient.ts:166-183,356,360`: registry add at creation, delete in `drain()` when retired; `retireAndDrainIdentityPersistences` retires all then drains all, bounded 1000 ms, never rejects. `authActions.ts:322` awaits it before the `Promise.all` purge block; `settleAndClearQueryCache` (`:375`) and `emit('logout')` (`:377`) keep their positions. After retirement the H3 late `setQueryData` reaches no subscriber, and `clear()`'s `removed` events cannot start a write (closes my P1 C1 as well). The gate's later A→null transition drains an already-drained persistence (no-op) and purges. `drain()` restructure preserves outcomes/`drainTimedOut`/timer clearing. **Closed.**

**S6-A-03 (identity suite).** Ten `await` insertions at the named lines; unit test now waits ≤10 microticks for the deferred `getItem` (the read reaches the spy after one `Promise.resolve().then` hop and the mock assigns `release` synchronously), asserts non-null, then retires; fixture write baselined via `slice(writesBeforeRetire)`. Behavioral assertions intact. **Closed.**

**New tests.** identityGate `:309-353` (A01 regression) traced on P2 bytes: A committed, first KEY_A write held (no mount write occurs because hydrated data is fresh), B suspended in drain, unmount, release → held write lands on its own key (`drainTimedOut` false, no removal), no KEY_B read/write, later cache event writes nothing. Passes on P2 by source reasoning; would fail on P1 (KEY_B read after drain). signout `:138-171` (A02): immediate first write, spy on module namespace records `isRetired()` at purge time, late update, `retiredAtPurge===true`, memory empty, no later writes to the key. Passes by source reasoning. Expected counts: identityGate 19, signout 4 (own `it(` counts).

## 4. Hazard expectations under P2 (unchanged from P1 where not stated)
Adapter still selects `postfix-gate` (no `asyncStoragePersister` export; exports only added). T-WIRING/T0 pass; T1 fails at `:188`; T2 at `:208`; T3 at `:240` — now because the late write never starts (persistence retired before the purge) rather than being purged later; T4 passes (gate's null transition drains a no-op and purges). No import, timer or forced-exit dependence introduced.

## 5. Validation-request delta
Bindings (worktree, output dir, tree `dddd7c28…`, blob table, commit paragraph, bundle name) are consistent with my re-derivation; no new steps. Prerequisites from P1 C10 unchanged. If S6-B-P2-01 is corrected, the pins and expected identityGate count must be re-issued (P3), not patched into P2.

## 6. Owned outputs
`P2_REPORT.md`, `P2_FINDINGS.md`, `p2/verify-p2-bytes.txt`, `p2/tree-rederivation.txt`, `MANIFEST.p2.sha256` (non-self-including). P1 files untouched. Final-head/result attestation still deferred to this review root.
