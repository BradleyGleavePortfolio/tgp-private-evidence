# S6 P1 review B — findings (source phase)

Candidate: manifest `698cf631…`, patch `20c6594c…` over `d51a1910…`. Classes per the owner Safety ROI doctrine. **A: none. B: none. C: 14 (record/qualify/continue; no new cycle, control, test or audit is requested).** Line numbers refer to the frozen candidate files.

## Class A — product/customer/data risk
None found.

## Class B — proof-invalidating
None found. The frozen hazard pair, the two staged suites, the two adapted suites and the five regression suites can execute against the candidate without import/module-load dependence on removed exports; expected flips are assertion-level (REPORT §4).

## Class C — record, qualify, continue

**C1 — signOut's clear triggers a same-user persister write after the storage purge.** `authActions.ts:360` runs `settleAndClearQueryCache()` while the gate has not yet retired the signing-out user's persistence (retirement happens only after `emit('logout')` → bootstrap → `sessionUserId=null`). `QueryCache.clear()` emits `removed` synchronously per query; the still-subscribed `persistQueryClientSubscribe` listener dehydrates the remaining queries and `asyncThrottle` executes immediately if its window is open, so a partial (then empty) snapshot of the user's own data is written to the user's **own** key after `purgePersistedQueryCacheForAllUsers()` at l.328. Closed by the gate's committed-null transition (retire → drain → clear → purge); the frozen T4 asserts exactly this end state. Same mechanism existed on d51 (to the shared anonymous key). Residual: a process kill between `signOut` and the null transition leaves a same-identity blob at its own key until the next committed-null purge; it is never restorable by another identity. No action required for P1.

**C2 — identity-scoped query above the gate under the first-commit clear exception (pre-existing).** `useFoundingNumber` (`src/hooks/useIdentity.ts`, per-user endpoint) is mounted in `ThemeProvider` above the gate. With the disclosed exception (`PersistedQueryCacheGate.tsx:101`, clear skipped while `memoryDirtyRef` is false) a boot whose token belongs to user A but whose bootstrap commits null (token present, user cache unreadable, `RootNavigator.tsx:593`) followed by a different-user login carries A's founding-number in memory into B's session, where B's persistence saves it under B's key and `ThemeProvider` displays it until it re-renders/refetches. Requires an inconsistent storage state; low-sensitivity datum; strictly better than d51 (which restored the whole anonymous blob). Outside the nine paths. Suggested follow-up outside P1: mount identity-scoped hooks below the gate, or clear on the first user commit when the cache is non-empty. Not a blocker.

**C3 — `committed` is not reset when `userId` changes.** On A→B→A where B never commits, `committed === 'A'` again matches at the second change, so A's children remount immediately (l.132) before transition 3's clear/restore; the subsequent `settleAndClearQueryCache` detaches their observers and they show stale same-identity data until a re-render. Cross-identity exposure would need B's `hydrate()` (l.301) and the identity flip to interleave within one microtask before l.119; no product path emits A→B→A inside the drain/restore window. Optional hardening: `setCommitted(undefined)` at effect start when `committed !== userId`.

**C4 — `transitionRef` is not invalidated on gate unmount.** Cleanup (l.124-129) retires only `activeRef.current`. A transition whose async prefix (drain l.91 or clear l.102) is pending at unmount continues, and for a user identity then creates and subscribes a persistence (l.113-117) that no cleanup retires. Requires a user→user transition with prior memory or undrained retirees plus an unmount (BiometricUnlockGate lock, `day1win`) inside the ≤1 s drain/clear window; normal product flows pass through null first, where `createIdentityPersistence` runs synchronously in the effect and is caught by the cleanup. Optional hardening: an `unmounted` flag set in cleanup and checked before l.113.

**C5 — `hydrate()` is outside the read try.** `queryClient.ts:301` calls `hydrate` after the fenced read; the pinned `persistQueryClientRestore` (`persist.ts:70-105`) wraps hydrate in try/catch → `removeClient()`. A parseable-but-malformed blob with matching buster would reject the transition promise and leave that identity on the restoring placeholder until restart, without removing the blob. Only reachable with a blob not produced by this app's own `dehydrate`. Related deviation: on `'failed'` the candidate subscribes (l.285) whereas the baseline provider did not; harmless (own key). Optional hardening: try/catch around l.301 → `removeBlob()` → `'failed'`.

**C6 — fail-closed removal may delete a newer same-identity blob.** A write that outlives an expired drain removes its key on landing (l.189-198); on A→…→A it can remove the new A session's freshly written blob. Cache-only, self-heals on the next cache event.

**C7 — empty/whitespace `userId` maps to `:anonymous`.** `persisterKeyForUser` (unchanged) falls back to `anonymous`; the gate passes any string through (l.113). The only caller, `RootNavigator.tsx:618`, guards with `trim()`. Defensive only.

**C8 — microtask-scale residual in `settleAndClearQueryCache`.** Steps 2–3 are synchronous, but a fetch that *starts* during `await cancelQueries()` (l.367) — e.g. a component newly mounted by a re-render triggered by the revert `setState` — would be destroyed by `clear()` while in flight and its `fetch()` `finally { scheduleGc() }` would re-arm gc on the orphan. No such fetch is triggered by the cancel itself (`setOptions` on an unchanged query does not refetch). The hazard suite's clean exit is the observation point; no added control.

**C9 — navigation composition not exercised with a real container (baseline-equivalent coverage).** Verified in `@react-navigation/core@7.21.1`: `navigationRef.isReady()` = a mounted navigator's focus listener (`BaseNavigationContainer.tsx:188`); container state/`initialState` persists until the navigator mounts, so the gate only lengthens the not-ready period that the replay effects (`RootNavigator.tsx:493-542`) already poll. All three `rootNavigator*.test.tsx` suites mock `NavigationContainer` as a Fragment with `isReady: () => true`, as on d51. Not a proof regression; recorded.

**C10 — execution prerequisites and request wording.** `node_modules` absent in this sandbox (new-environment install needed under the S5-owned slot; not a repeat of accepted evidence); Node v20 / RNTL 14 qualification stands; the request's "S3 owns the runtime" sentence is stale and `840be0b8…` is package-lock, not the canonical lock. The two hazard files must be placed and removed hash-guarded and must not be staged into the hooked head (expected head tree = nine-path tree `845d83ad…`).

**C11 — test-side timer control is hygiene, not masking.** `identityGate` uses fake timers with `jest.clearAllTimers()` in `afterEach`; `signout.test.ts` uses fake timers in try/finally. Both are test-scoped and are the staged/accepted forms; the hazard suite runs real timers and its teardown uses `cancelQueries()+clear()` (frozen v5). No product code touches timers.

**C12 — stale comment outside the authorized paths.** `LoginScreen.tsx:88-91` still describes the removed `asyncStoragePersister` singleton. Cosmetic; no bytes may change now.

**C13 — dead code (pre-existing).** `RootNavigator.tsx:606-614` `try { user = parsedUser } catch` cannot throw.

**C14 — role-less cached user purges all derived caches.** `RootNavigator.tsx:618` commits the id, then l.749 commits null for "token but no role" → interrupted user→null transition → `purgePersistedQueryCacheForAllUsers()`. Consistent with the parent's committed-logged-out purge decision; derived cache only; recorded.

## Closure statement
Source is closed for the bounded validation grant. Runtime prerequisites and expected outcomes are in REPORT §6. No builder correction is requested before execution; C3/C4/C5 hardenings are optional and may be batched into any later authorized change, never as a standalone cycle.
