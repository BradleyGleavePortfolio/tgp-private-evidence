# Review B — P2 follow-up preparation (not part of the frozen P1 source-phase packet)

Written after the parent's 12:59 PDT notice. P1 bytes (`REPORT.md`, `FINDINGS.md`, `MANIFEST.sha256`, `inputs/**`, `logs/**`) are unchanged. Reviewer A's `audits/s6-a/FINDINGS.md` was read only as a follow-up input; the mappings below are my own byte checks, not inherited conclusions.

## Byte-level checks I performed now on A's shared concrete findings

- **A-01 (gate unmount does not invalidate `isCurrent`)** — same mechanism as my C4 (`PersistedQueryCacheGate.tsx:79-83, 124-129`). A supplies the reachability I had not credited: `BiometricUnlockGate` unmounts RootNavigator children on every background→active re-check, so an unmount inside the ≤1 s drain/clear window of a user→user transition is a real composition boundary, and the orphan persistence would later persist a *different* committed identity's data under the old key. I accept the elevation as the parent has disposed it; my P1 C4 text stands as written (frozen) and its stated minimum correction (invalidate the transition synchronously in cleanup, retire the effect-owned persistence) matches A's.
- **A-02 (signOut returns before retire/drain/final purge)** — same mechanism as my C1 (`authActions.ts:309-329, 360`). Parent has disposed it as A; correction scope is the builder's.
- **A-03 (identity suite proof defects)** — checked against the frozen `persistedQueryCache.identityGate.test.tsx`:
  - `:397-400`: `restore()` starts the read via `Promise.resolve().then(() => persister.restoreClient())` (`queryClient.ts:253-254`), so the spied `getItem` — and therefore `release =` — cannot have run when the test synchronously invokes `release` → `TypeError`. **Confirmed by bytes.**
  - `:410-417`: the fixture `AsyncStorage.setItem(KEY_A, …)` is recorded by `setItemSpy` (installed in `beforeEach`, `:77-83`), so `filter(KEY_A)).toEqual([])` fails even with correct retirement. **Confirmed by bytes.**
  - `:117,…` unawaited `rerender`/`unmount` under RNTL 14 — plausible; I did not open the RNTL 14.0.0 archive and will verify in the P2 delta if the suite is touched.
  - Self-correction (recorded here, P1 bytes untouched): my P1 REPORT §5/§4 treated the staged identity suite as consistent with the candidate; I traced its gate-level cases but not the `createIdentityPersistence` unit cases to this depth. The two confirmed defects are proof-invalidating (Class B) for that suite; they do not change the product-path source conclusions.

## Checklist for the P2 changed-byte review (when pins arrive)

1. Re-derive P2 pins: manifest hash, patch hash, base (`d51a1910…`), changed-path list; diff P1→P2 candidate bytes file-by-file; confirm no path outside the authorized set and no dependency/lock change.
2. A-01 closure: cleanup must invalidate the transition synchronously (or equivalent) so that no post-unmount continuation performs clear/hydrate/create/subscribe; the persistence owned by an in-flight effect must be retired/drained-accountable; check that retirement bookkeeping survives remount or is not needed after invalidation; no timers, no private APIs.
3. A-02 closure: retirement + drain coordinated inside `signOut` before its final derived-cache purge/completion, without changing credential/analytics/store/offline-mutation semantics; verify ordering with `settleAndClearQueryCache`, that the later gate null transition remains correct (idempotent retire/drain), and re-trace T3/T4 expectations against the new order.
4. A-03 closure: awaited lifecycle helpers; deferred read observed before retire/release; fixture writes baselined; intended assertions preserved (no new harness).
5. Preserve P1 conclusions where bytes are unchanged (lifecycle correction in `settleAndClearQueryCache`, defaults, purge, key/max-age/throttle, App/RootNavigator composition) — re-run only the `cmp`/block-identity checks, not a full re-review.
6. Re-check my C3/C5–C8 only if the P2 delta touches their lines; otherwise carry forward unchanged. Do not request changes on the basis of C labels alone.
7. Output: `P2_REPORT.md`, `P2_FINDINGS.md`, `MANIFEST.p2.sha256` (non-self-including) in this root; no runtime.

Status: waiting for the parent's P2 READY pins. No further action now.
