# S6 P1 independent review B — lifecycle/integration lens (source phase)

Reviewer: independent nonbuilder B (EXEC-e7d2385c, T4 individual/cumulative; requested Claude Fable 5 / High — requested setting, not runtime telemetry). Read-only against candidate, worktree and private inputs. Sole writes: `execution/e7d2385c/audits/s6-b/**`. No npm/node/Jest/tsc/eslint/formatter, install, hook, commit, lock/probe/signal, candidate edit or private-checkout write was performed. Static file/hash/Git-object inspection plus read-only `gh api` retrieval of immutable sources into this audit root only.

Source-phase report frozen 2026-09-23 (PDT afternoon). A later final-head/actual-result attestation will be appended as a separate sealed file in this root; this file's bytes are not to be edited.

## 1. Exact inputs (re-derived, not inherited)

| Input | Identity | How verified |
|---|---|---|
| Private intake | commit `cc62002bfd08c3cb677025b651965d36e6a1aaec` | local partial checkout HEAD; tree `2026-09-23/6c2a68ac/s6-p1-product-build` = `9afbce31864110f6d1c4f853dbb21265f92750d7` |
| Candidate packet | `MANIFEST.sha256` sha256 **`698cf631a421c8835928912aa0e180917a95be88e2672ac5f61878db63c71808`**, 15 entries, `sha256sum -c` 15/15 OK, non-self-including | fetched blob-by-blob via `gh api .../git/blobs/<sha>` into `inputs/s6-p1-product-build/`, sizes = tree sizes |
| Patch | `p1-product.patch` sha256 **`20c6594c200d38c9946f4f62d2c778f634bcacbe26b430b05e8291cc5f571cbd`**, exactly nine `diff --git` sections | own hash; sections enumerated |
| Baseline | `worktrees/s6-diagnostic` HEAD `d51a191098f483cea9abec6cc7e9f3beffd18c06`, tree `62bf67b88e0f123f1a23ee34a1a75cb43029d9fb` | `GIT_OPTIONAL_LOCKS=0 git rev-parse`; `diff-index --quiet HEAD` clean outside the nine paths |
| Candidate in worktree | porcelain = exactly the nine PINS_FINAL lines; all nine worktree files `cmp` byte-identical to packet `candidate/**` | own `cmp` (log `logs/`), preparer's derived tree `845d83ad5731f86b34bfca2ca67142c98498165f` not re-derived here (index untouched) |
| Frozen hazard | `persistedQueryCache.hazardControls.test.tsx` **`a91bb732716b500122e291714bf437872cb81930c020812042f84ed87f6a184d`**; adapter **`3796be8fae738993bcc5c30dd7d4cf9b303329b8faa990ca03e31c2460cd35f3`** | own sha256 of `execution/e7d2385c/s6-inputs/2026-09-22/op88/remediation/s6-c6-prep/c6/inputs/*` |
| Staged tests | `persistedQueryCache.identityGate.test.tsx` `44031dcb…`, `rootNavigatorPersistedCacheGate.test.tsx` `b1ed2f46…` | equal to `s6-p1-staging-1/MANIFEST.sha256` entries → byte-identical to staging as asserted |
| Pinned library source | `@tanstack/{query-core,react-query,query-persist-client-core,query-async-storage-persister,react-query-persist-client}@5.100.14` = lockfile pins; upstream per-package tags all resolve to commit `ba6e7beebd50143408f01fcf5d9aee2ec1486f60`; `@react-navigation/core@7.21.1` (lockfile) = commit `f4af3430155cdd765d02af4e654dcf79b1702b6d` | `gh api` refs/tags → `inputs/tanstack-5.100.14/**`, `inputs/react-navigation-core-7.21.1/**` (`logs/tanstack-pins.json`). `node_modules` is ABSENT in this sandbox, so installed bytes could not be compared; the builder's cited line numbers (query.ts 253/259/362/377/621) match this tag exactly. |

Not read: peer review outputs, parent dispositions of this candidate, any current runtime result (none exists).

## 2. Verdict

**SOURCE CLOSED — GRANTABLE for the proposed bounded validation.** No Class A or Class B finding. Fourteen Class C records (`FINDINGS.md`), none of which blocks the product path or invalidates the requested proof; none requires a new control, cycle or framework.

This is a source verdict only. It is not runtime acceptance; final acceptance requires the actual T-WIRING/T0/T4 pass, T1/T2/T3 assertion-level failures, the requested suites, and an exact true-hooked head, attested later in this same review.

## 3. Lifecycle correction — independently traced against pinned query-core 5.100.14

Observed defect (C6 outcome i): two 600 000 ms timers via `Query.removeObserver → scheduleGc` surviving `cancelQueries()+clear()`.

Pinned mechanics (own reading of `inputs/tanstack-5.100.14/query-core/src`):
- `QueryCache.clear()` → `remove(query)` → `query.destroy()` then map delete (`queryCache.ts:144-162`). `Query.destroy()` = `Removable.destroy()` (`clearGcTimeout`) + `cancel({silent:true})` (`query.ts:259-263`); **observers untouched**.
- `Query.removeObserver()` is guarded by `this.observers.includes(observer)` and, on empty list, calls `scheduleGc()` (`query.ts:362-381`). `QueryObserver.destroy()` and `#updateQuery()` both call `removeObserver` on `#currentQuery` (`queryObserver.ts:131-136, 716-718`). Hence an observer still attached to a destroyed-but-referenced query re-arms an unclearable gcTime timer; an observer detached while the query was cached is inert thereafter.
- `Query.fetch()` is `async` with `finally { this.scheduleGc() }` (`query.ts:621-623`). `Query.cancel()` returns `retryer.promise.then(noop).catch(noop)` (`query.ts:253-257`); `#retryer.promise` and `start()` return the same native Promise (`thenable.ts`, `retryer.ts:208-227`). The `await start()` reaction in `fetch` is registered before `cancel()`'s `.then`, so the `finally` re-arm runs before `cancelQueries()` resolves — on a query that is still cached. `cancel` rejects immediately even for paused retryers (`retryer.ts:87-93`), so `await cancelQueries()` cannot hang.
- Cache listeners are invoked synchronously inside `QueryCache.notify` (`queryCache.ts:200-206`); observer notifications are scheduled with `setTimeout(0)` (`notifyManager.ts:15`).

Candidate `settleAndClearQueryCache` (`queryClient.ts:360-382`): (1) `await cancelQueries()` — fetch-side re-arms land on cached queries; (2) synchronously detach every observer of every cached query via public `query.observers` / `query.removeObserver` — arms gc on cached queries and makes later observer-side `removeObserver` calls no-ops; (3) synchronous `clear()` — `destroy()` clears every gc timer. Steps 2–3 have no await between them. Conclusion: the observed orphan mechanism (observer-side and fetch-side) is closed for all queries present at step 1; no timer is unref'd, faked, shortened or force-cleared; `gcTime` 600 000 and all defaults unchanged (block-level identical to baseline); only public API used. Residual microtask-window note in C8.

`signOut` (`authActions.ts:360`) replaces the bare `queryClient.clear()` with `await settleAndClearQueryCache()`; the cache is still emptied before `authEvents.emit('logout')`. No other line of `signOut` changed (diff = one import line + one call + comment). `queryClient.signout.test.ts` adds the discriminating assertion (observer detached, query removed, no timer-count increase on later `destroy()`); its two existing assertions are preserved verbatim.

## 4. Gate transitions, cancellation, detach/reattach, clear ordering, supersession

`PersistedQueryCacheGate.tsx` (own trace):
- Render guard `userId !== undefined && committed === userId` (l.132): an identity change unmounts the previous subtree in the commit that schedules the effect, so passive cleanups (`QueryObserver.destroy` → `removeObserver` on cached queries) run before the effect body; replacement children mount only after `setCommitted`.
- Effect order: retire previous (l.85, idempotent; the cleanup l.128 already fenced the active one) → bounded drain 1000 ms (l.89-97) → `settleAndClearQueryCache(undefined,{shouldContinue:isCurrent})` when `memoryDirtyRef` (l.101-105) → null: purge then commit; user: create persistence, mark dirty, bounded restore 4000 ms, commit only if `isCurrent() && !next.isRetired()` (l.107-121). Every await is followed by an `isCurrent()` checkpoint; a superseded transition never commits. Retired-but-undrained persistences are carried in `retiredRef` and drained by the superseding transition (l.82, 96). `memoryDirtyRef` is only cleared by a current transition after a completed clear and is set before any restore, so it only errs toward clearing.
- Fences in `createIdentityPersistence`: write fence at the actual `setItem` (l.184), evaluated when `asyncThrottle` finally executes (`asyncThrottle.ts`: first call immediate, later calls sleep on `timeoutManager.setTimeout` until the window opens, then `trySave → serialize → storage.setItem`); restore fence after the read and before `hydrate` (l.275) — the only `hydrate` call site (l.301); timeout race discards the late read (the mapped promise is unreachable); fail-closed self-removal after an expired drain (l.189-198); `retire()` unsubscribes `persistQueryClientSubscribe` (l.244-250). The buster/max-age/opt-out logic mirrors `persistQueryClientRestore` (`persist.ts:70-105`) and baseline `App.tsx` persistOptions.
- Reattach after detach: on the next render `useBaseQuery → observer.setOptions → #updateQuery` builds/attaches a fresh Query and fetches if stale (`queryObserver.ts:704-725`) — identical to post-`clear()` behavior on d51.

Hazard-suite expectation (source reasoning only, to be verified by execution): adapter capability-detects the missing `asyncStoragePersister` export → `postfix-gate` mode, lazy-requires the gate (present, named + default export). T-WIRING: `App.tsx:231` `<QueryClientProvider client={queryClient}>`, zero occurrences of `asyncStoragePersister`, `RootNavigator.tsx:837` `<PersistedQueryCacheGate`, `QUERY_CACHE_BUSTER === 'tgp-rq-v2-samples'` → pass. T0: write lands on `TGP_RQ_CACHE_V1:user-B` → pass. T1: anonymous key never read → `getQueryData(ME)` undefined → fails at l.188 (hazard assertion). T2: committed null purges, then C restores only its key → fails at l.208. T3: late write lands under B's own key during `signOut` (gate not yet retired), then `recommit()` → gate retire/drain/clear/purge removes it → `onDisk('user-B')` false → fails at l.240 (its two preconditions at l.224 and the `committed === 'user-C'`-style checks hold). T4: end state clean after the gate's null transition → pass. Nothing in these paths depends on a timer that the candidate leaves unbounded; the only long timers are the library's own gc timers on cached queries, cleared by the suite's `clear()` teardown and by `settleAndClearQueryCache`.

## 5. Preservation (re-derived)

- Nine authorized paths only (porcelain, `diff-index` clean elsewhere).
- `queryClient.ts`: `new QueryClient({...})` block, `persisterKeyForUser`, `purgePersistedQueryCacheForAllUsers` byte-identical to `HEAD:src/services/queryClient.ts`; prefix `TGP_RQ_CACHE_V1`, max-age 24 h, throttle 1000 ms, buster string preserved; `asyncStoragePersister`/`resolveBootUserId`/`readUserCacheSync` import removed. No dependency, lock or package change.
- `App.tsx`: only the provider swap and imports; tree order unchanged.
- `RootNavigator.tsx`: `sessionUserId` set on every bootstrap outcome (l.594, 601, 612, 618, 749, 753); gate placed inside the existing `NavigationContainer` (l.837-849, 896); container, `ref`, `linking`, replay effects untouched; `Day1WinScreen` path ungated as before.
- `authActions.ts`: one semantic change (§3); credentials/analytics/store resets untouched.
- Tests: two staged suites byte-identical to staging; `persister.test.ts` adds one contract test and removes a now-dead `lib/userCache` mock (four existing assertions verbatim); `signout.test.ts` additive only. No other test in the tree imports `asyncStoragePersister`; no `signOut`-calling test partially mocks `services/queryClient` (only `entitlementProvider.test.tsx` does, and it does not call `signOut`).

## 6. Requested validation — applicability

`VALIDATION_REQUEST.md` steps 1–5 cover the changed actual paths: tsc; the two new suites; the two adapted suites; the five unchanged suites that import `RootNavigator`/`authActions`/`queryClient` (all exist in the worktree); the frozen hazard pair placed unmodified and run alone. Adequate for the P1 boundary; expected outcomes as in §4. Invalidation rule accepted: any import error, hang, skipped case, arbitrary failure or forced exit on T-WIRING/T0/T4 — or a T1/T2/T3 failure not at its hazard `expect` — is not a flip. Mechanical prerequisites (not findings): `node_modules` absent in this sandbox → a new-environment install under the S5-owned slot before any step; Node v20 / RNTL 14 engine qualification stands; the two hazard files must be placed and removed hash-guarded and must not enter the hooked head (expected head tree = the nine-path tree `845d83ad…` over parent `d51a1910…`, Bradley author/committer, no trailers). Request wording corrections (S3 runtime sentence stale; `840be0b8` is package-lock) do not touch candidate bytes.

## 7. Owned outputs

`REPORT.md`, `FINDINGS.md`, `MANIFEST.sha256` (non-self-including), `inputs/**` (retrieved immutable sources, read-only), `logs/**`. Final-head/result attestation to be added later as `FINAL_ATTESTATION.md` + `MANIFEST.final.sha256` without editing the files above.
