# S6 P2 review B — changed-byte findings

Scope: P1 → P2 delta only (`p1-to-p2.patch` `93d799db…`), with the resulting invariants re-traced on the full P2 files where the delta touches them. P1 conclusions for the four byte-identical files are carried forward unchanged. Line numbers refer to `s6-p2/candidate/**`.

**A: 1. B: 0. C: 6 (plus carry-forward table).**

## Class A

### S6-B-P2-01 — A — the S6-A-01 closure invalidates the suspended transition but leaves nobody owing the identity-memory clear; a remount then commits the next identity on top of the previous identity's memory

**Exact code.**
- `PersistedQueryCacheGate.tsx:139-149` (P2 cleanup): `transitionRef.current += 1` synchronously, retire `created`. Intended and correct for S6-A-01.
- `PersistedQueryCacheGate.tsx:98-105`: a body suspended in step 2 (drain) returns at `if (!isCurrent()) return;` — **before** step 3 (`settleAndClearQueryCache`, l.109-113). Nothing records that a clear was owed.
- `PersistedQueryCacheGate.tsx:72,109`: `memoryDirtyRef` is a `useRef` — instance-local. A fresh gate instance starts with `false` and therefore skips step 3 on its first transition, regardless of what the module-level `queryClient` still holds.
- `queryClient.ts:172-183` (`retireAndDrainIdentityPersistences`) fences writes but does not clear memory; only `settleAndClearQueryCache` (called by `signOut`, `authActions.ts:375`, and by the gate) does.

**Reachable harm — the S6-A-01 scenario itself, continued one step.** A committed (A's private queries in memory). Identity changes in-session to B; B's transition suspends in the bounded drain because one A write is in flight. The gate unmounts inside that window (the `BiometricUnlockGate` re-evaluation that S6-A-01 cited unmounts `RootNavigator` itself, `App.tsx:243-245`; `authState==='day1win'`, `RootNavigator.tsx:810-812`, unmounts the container). P2 cleanup invalidates the transition: the body returns at l.105 — A's memory is **not** cleared (on P1 the orphaned body did clear it). Unlock → `RootNavigator` remounts → bootstrap reads B from storage → a fresh gate mounts with `userId='user-B'`, `memoryDirtyRef=false` → step 3 skipped → `createIdentityPersistence('user-B')`, `restore(KEY_B)`: `hydrate` (pinned `hydration.ts:229-236`) keeps the existing in-memory entry unless the persisted one has a strictly newer `dataUpdatedAt`, so A's entries survive → `setCommitted('user-B')` → B's screens read A's data for every shared query key (served within `staleTime` 30 s; keys without a mounted observer are never refetched) → B's now-subscribed persistence dehydrates the shared client on the next cache event and writes A's data under `TGP_RQ_CACHE_V1:user-B`, where a future B cold boot restores it. Cross-identity exposure in memory and on disk — the H1/H2 hazard class this gate exists to close.

Reachability qualifier (stated so the parent can dispose consistently): I found no in-product emitter of an in-session A→B that bypasses a committed null (LoginScreen/CreateAccount/RoleSelection all run in the committed-logged-out state; `signOut`, including the refresh-failure path `api.ts:177-197`, clears memory itself). The scenario is therefore exactly the premise the parent accepted for S6-A-01 (in-session transition interrupted by unmount). If that premise is in scope, P2 does not close its harm class — it moves the exposure from "later identity written under B's key" to "A's data shown to and persisted for B". If the parent narrows the premise, this finding reclassifies together with S6-A-01.

**Decision blocked.** Identity/privacy source closure for the unmount-interrupted transition boundary, i.e. the S6-A-01 closure itself. A02/A03 closures are not affected.

**Minimum correction (in the already-authorized paths, no new control or framework).** Make the "identity memory may be dirty" state QueryClient-lifetime instead of gate-instance-lifetime: in `queryClient.ts` a module-level flag (e.g. `identityMemoryDirty`) set `true` where the gate currently sets `memoryDirtyRef.current = true` (before `restore`, l.125) and set `false` inside `settleAndClearQueryCache` after `client.clear()` (which also makes `signOut`'s own clear reset it); export a getter/setter pair (or a `markIdentityMemoryDirty()` + read inside the gate) and replace the three `memoryDirtyRef` uses at l.72,109,113,125 with them. Optional refinement to avoid same-identity churn on biometric remounts: tag the flag with the identity that dirtied it and clear only when it differs from the incoming `userId`. Extend the new S6-A-01 regression test (identityGate `:309-353`) by one step after `unmount()`: `render(<Harness userId="user-B" />)` on a fresh instance, `settle()`, assert `queryClient.getQueryData(ME)` is not `A` and `blobQueries(KEY_B)` never contains A's data. On P2 that step fails (fixture timestamps are equal under fake timers, so `hydrate` keeps A); after the correction it passes.

**Execution unlocked.** Narrow changed-byte re-review of that correction, then the same bounded validation already prepared (P2 bindings; expected identityGate count becomes 20 if the assertion is added as a separate case, or stays 19 if appended).

## Class B
None. The frozen hazard pair, the two amended suites and the unchanged suites load and run against P2 without import/module dependence on removed symbols; new symbols are additive exports. Expected flips remain assertion-level (see P2_REPORT §4).

## Class C

**C-P2-1 — signOut latency.** `retireAndDrainIdentityPersistences()` adds up to `QUERY_CACHE_SIGN_OUT_DRAIN_TIMEOUT_MS` (1000 ms) to `signOut` only when a write is in flight; bounded, timer cleared in `finally`. Acceptable.

**C-P2-2 — live registry growth.** `liveIdentityPersistences` retains retired-but-undrained persistences produced by unmount cleanups until the next `signOut` (or same-instance transition) drains them. Bounded by the number of identity transitions in a process; fenced entries cannot write. Acceptable.

**C-P2-3 — signOut failure after retirement.** If the `Promise.all` credential/store block (`authActions.ts:323-`) throws after `retireAndDrainIdentityPersistences()`, the still-committed identity continues without persistence until the next transition (writes fenced, reads unaffected). Safe direction; unchanged product semantics otherwise.

**C-P2-4 — effect-start `activeRef` hand-off is now dead.** Cleanup nulls `activeRef` when it points at `created`, so `if (activeRef.current) retired.add(activeRef.current)` (l.85) can no longer fire. Harmless.

**C-P2-5 — A03 await additions are safe regardless of RNTL internals.** Awaiting a synchronous `rerender`/`unmount` is a no-op; awaiting an async one is required. I did not open the RNTL 14.0.0 archive; the correction is correct either way.

**C-P2-6 — new signout test relies on module-namespace spying (`import * as qc`).** Same pattern as the frozen hazard T3, which produced attributable results on d51; under babel CJS interop the `authActions` live binding sees the spy. Recorded as a runtime observation point, not a defect.

## Carry-forward of P1 findings (B review)

| P1 | P2 status |
|---|---|
| C1 (signOut clear triggers a same-user write after the purge) | **Closed** by A02: persistence retired/unsubscribed before the purge; the `removed` events at `clear()` reach no listener. |
| C4 (transition not invalidated on unmount) | Orphan-persistence aspect **closed** (S6-A-01); memory-ownership aspect **reopened as S6-B-P2-01** above. |
| C2, C3, C5, C6, C7, C8, C9, C10, C11, C12, C13, C14 | Unchanged (lines shifted in `queryClient.ts`/gate only); still C; C10 prerequisites apply with P2 bindings. |
| P2_FOLLOWUP_PREP self-correction (A03 bytes) | A03 closure verified against the amended bytes (`:440-447`, `:463-468`). |
