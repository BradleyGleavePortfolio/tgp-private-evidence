import { ConflictException, Logger } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { AnalyticsService } from '../../../src/analytics/analytics.service';
import { Events } from '../../../src/analytics/events';
import { PrismaService } from '../../../src/prisma.service';
import { ScoutReconstructService } from '../../../src/scout/scout-reconstruct.service';
import {
  RECONSTRUCT_MAX_ROWS,
  RECONSTRUCT_PAGE_SIZE,
  RECONSTRUCT_STATUS,
} from '../../../src/scout/scout-reconstruct.dto';

/**
 * ScoutReconstructService unit tests.
 *
 * The Prisma dependency is a small in-memory fake with REAL upsert + groupBy
 * semantics (keyed on the same unique tuples as the schema), so accounting,
 * idempotent replay, and poison-row isolation are proven by behaviour — not by
 * a mock that hands back a pre-decided count (a tautology the codebase
 * explicitly avoids; see scout-ingest.service.spec.ts).
 */

interface StagedRow {
  source_id: string;
  source_platform: string;
  payload: unknown;
}
interface LedgerRow {
  source_platform?: string | null;
  coach_id: string;
  intent_id: string;
  entity_type: string;
  source_id: string;
  status: string;
  target_id: string | null;
  reason: string | null;
}

class FakePrisma {
  terminalStatus: string | null | undefined = 'success';
  hasImport = true;
  staged: StagedRow[] = [];
  /**
   * Overrides the pre-flight staged count without allocating the rows, so the
   * over-ceiling fail-closed path can be exercised deterministically.
   */
  stagedCountOverride: number | null = null;
  /** source_ids whose person.upsert should throw, to simulate poison rows. */
  poison = new Set<string>();
  /**
   * source_person_ids for which the FIRST person.upsert simulates losing a
   * concurrent insert race: it materializes the row (as the winning writer
   * would) and then throws a Prisma P2002 unique violation exactly once. The
   * service's retry-once path must then converge to `reconstructed`.
   */
  p2002Once = new Set<string>();
  /** Records skip/take pairs passed to findMany, to prove deterministic paging. */
  readonly pages: Array<{ skip: number; take: number }> = [];

  readonly persons = new Map<string, { id: string; display_name: string | null }>();
  readonly ledger = new Map<string, LedgerRow>();

  private personKey(coach: string, platform: string, personId: string): string {
    return `${coach}|${platform}|${personId}`;
  }
  private ledgerKey(r: {
    coach_id: string;
    intent_id: string;
    entity_type: string;
    source_id: string;
  }): string {
    return `${r.coach_id}|${r.intent_id}|${r.entity_type}|${r.source_id}`;
  }

  scoutImport = {
    findUnique: async (_args: unknown) =>
      this.hasImport ? { terminal_status: this.terminalStatus } : null,
  };

  scoutIngestEntity = {
    count: async (_args: unknown) => this.stagedCountOverride ?? this.staged.length,
    findMany: async (args: { take?: number; skip?: number }) => {
      const skip = args.skip ?? 0;
      const take = args.take ?? this.staged.length;
      this.pages.push({ skip, take });
      // Deterministic order by source_id, mirroring the service's orderBy.
      const ordered = [...this.staged].sort((a, b) => a.source_id.localeCompare(b.source_id));
      return ordered.slice(skip, skip + take);
    },
  };

  person = {
    upsert: async (args: {
      where: {
        coach_id_source_platform_source_person_id: {
          coach_id: string;
          source_platform: string;
          source_person_id: string;
        };
      };
      create: { display_name: string | null };
      update: { display_name: string | null };
    }) => {
      const w = args.where.coach_id_source_platform_source_person_id;
      if (this.poison.has(w.source_person_id)) throw new Error('poison person upsert');
      const key = this.personKey(w.coach_id, w.source_platform, w.source_person_id);
      if (this.p2002Once.has(w.source_person_id)) {
        // Simulate the concurrent winner: materialize the row as the racing
        // writer would, then surface the unique violation exactly once.
        this.p2002Once.delete(w.source_person_id);
        if (!this.persons.has(key)) {
          this.persons.set(key, {
            id: `person-${this.persons.size + 1}`,
            display_name: args.create.display_name,
          });
        }
        throw new Prisma.PrismaClientKnownRequestError('unique violation', {
          code: 'P2002',
          clientVersion: 'test',
        });
      }
      const existing = this.persons.get(key);
      if (existing) {
        existing.display_name = args.update.display_name;
        return { id: existing.id };
      }
      const created = {
        id: `person-${this.persons.size + 1}`,
        display_name: args.create.display_name,
      };
      this.persons.set(key, created);
      return { id: created.id };
    },
  };

  scoutReconstructionLedger = {
    updateMany: async (args: {
      where: {
        coach_id: string;
        intent_id: string;
        entity_type: string;
        source_id: string;
        OR?: Array<{ source_platform: string | null }>;
        status?: { not: string };
      };
      data: Partial<LedgerRow>;
    }) => {
      const w = args.where;
      const row = this.ledger.get(`${w.coach_id}|${w.intent_id}|${w.entity_type}|${w.source_id}`);
      if (
        !row ||
        (w.OR && !w.OR.some((p) => p.source_platform === (row.source_platform ?? null))) ||
        (w.status && row.status === w.status.not)
      )
        return { count: 0 };
      Object.assign(row, args.data);
      return { count: 1 };
    },
    upsert: async (args: {
      where: { coach_id_intent_id_entity_type_source_id: LedgerRow };
      create: LedgerRow;
      update: Partial<LedgerRow>;
    }) => {
      const key = this.ledgerKey(args.where.coach_id_intent_id_entity_type_source_id);
      const existing = this.ledger.get(key);
      if (existing) {
        Object.assign(existing, args.update);
        return existing;
      }
      const row = { ...args.create };
      this.ledger.set(key, row);
      return row;
    },
    groupBy: async (_args: unknown) => {
      const counts = new Map<string, number>();
      for (const row of this.ledger.values()) {
        counts.set(row.status, (counts.get(row.status) ?? 0) + 1);
      }
      return [...counts.entries()].map(([status, n]) => ({ status, _count: { _all: n } }));
    },
  };

  $transaction = async <T>(cb: (tx: FakePrisma) => Promise<T>): Promise<T> => cb(this);
}

/**
 * Wrap the in-memory fake as a PrismaService without a banned double-cast: the
 * fake's own-property delegates (scoutImport, person, ledger, $transaction) close
 * over the real fake instance, so the returned handle drives the same state the
 * test asserts against. Mirrors makePrisma() in scout-ingest.service.spec.ts.
 */
function asPrisma(fake: FakePrisma): PrismaService {
  return Object.assign(Object.create(PrismaService.prototype) as PrismaService, fake);
}

function makeAnalytics(capture: jest.Mock): AnalyticsService {
  return Object.assign(Object.create(AnalyticsService.prototype) as AnalyticsService, { capture });
}

function build(configure: (p: FakePrisma) => void = () => {}) {
  const prisma = new FakePrisma();
  configure(prisma);
  const capture = jest.fn();
  const service = new ScoutReconstructService(asPrisma(prisma), makeAnalytics(capture));
  return { service, prisma, capture };
}

function stagedClient(sourceId: string, name = `Name ${sourceId}`): StagedRow {
  return {
    source_id: sourceId,
    source_platform: 'truecoach',
    payload: { name, email: `${sourceId}@x.io` },
  };
}

describe('ScoutReconstructService', () => {
  afterEach(() => jest.restoreAllMocks());
  it.each(['', 'TrueCoach', 'truecoach ', ' truecoach', '-bad', 'a'.repeat(257), 'a\n'])(
    'rejects noncanonical provenance without any write: %j',
    async (platform) => {
      const { service, prisma } = build((p) => {
        p.staged = [{ ...stagedClient('private-id'), source_platform: platform }];
      });
      await expect(service.reconstruct('coach-1', 'intent-1')).rejects.toThrow(
        'reconstruction provenance conflict',
      );
      expect(prisma.persons.size).toBe(0);
      expect(prisma.ledger.size).toBe(0);
    },
  );

  it.each(['reconstructed', 'skipped', 'failed'])(
    'creates %s with actual staging provenance',
    async (status) => {
      const platform = status === 'skipped' ? 'unregistered.v1:token-2' : 'truecoach';
      const { service, prisma } = build((p) => {
        p.staged = [{ ...stagedClient('1'), source_platform: platform }];
        if (status === 'failed') p.poison.add('1');
      });
      await service.reconstruct('coach-1', 'intent-1');
      expect([...prisma.ledger.values()]).toEqual([
        expect.objectContaining({ status, source_platform: platform }),
      ]);
    },
  );

  it.each(['skipped', 'failed'])(
    'claims NULL but preserves a committed success on %s replay, including reason',
    async (attempt) => {
      const { service, prisma } = build((p) => {
        p.staged = [stagedClient('1')];
      });
      await service.reconstruct('coach-1', 'intent-1');
      const row = [...prisma.ledger.values()][0];
      row.source_platform = null;
      row.reason = 'retained-success-reason';
      const target = row.target_id;
      if (attempt === 'skipped')
        jest
          .spyOn(service['families'].get('clients')!, 'map')
          .mockReturnValueOnce({ ok: false, reason: 'synthetic mapper skip' });
      else prisma.poison.add('1');
      const result = await service.reconstruct('coach-1', 'intent-1');
      expect(row).toMatchObject({
        source_platform: 'truecoach',
        status: 'reconstructed',
        reason: 'retained-success-reason',
        target_id: target,
      });
      expect(result).toMatchObject({ reconstructed: 1, failed: 0, skipped: 0 });
    },
  );

  it.each(['reconstructed', 'skipped', 'failed'])(
    'refuses contradictory provenance even if preserving an existing %s',
    async (status) => {
      const { service, prisma } = build((p) => {
        p.staged = [stagedClient('1')];
      });
      await service.reconstruct('coach-1', 'intent-1');
      const row = [...prisma.ledger.values()][0];
      row.source_platform = 'different';
      row.status = status;
      const before = { ...row };
      jest
        .spyOn(service['families'].get('clients')!, 'map')
        .mockReturnValueOnce({ ok: false, reason: 'synthetic mapper skip' });
      await expect(service.reconstruct('coach-1', 'intent-1')).rejects.toThrow(
        'reconstruction provenance conflict',
      );
      expect(row).toEqual(before);
    },
  );

  it('uses serialized last non-success attempt, then allows success to upgrade it', async () => {
    const { service, prisma } = build((p) => {
      p.staged = [stagedClient('1')];
      p.poison.add('1');
    });
    await service.reconstruct('coach-1', 'intent-1');
    const row = [...prisma.ledger.values()][0];
    expect(row.status).toBe('failed');
    jest
      .spyOn(service['families'].get('clients')!, 'map')
      .mockReturnValueOnce({ ok: false, reason: 'synthetic mapper skip' });
    await service.reconstruct('coach-1', 'intent-1');
    expect(row.status).toBe('skipped');
    prisma.poison.clear();
    prisma.staged[0] = stagedClient('1');
    await service.reconstruct('coach-1', 'intent-1');
    expect(row).toMatchObject({ status: 'reconstructed', reason: null });
    expect(row.target_id).not.toBeNull();
  });

  it('isolates a throwing mapper, sanitizes error names and continues siblings', async () => {
    const { service, prisma } = build((p) => {
      p.staged = [stagedClient('1'), stagedClient('2')];
    });
    const family = service['families'].get('clients')!;
    const original = family.map;
    const mapper = jest.spyOn(family, 'map').mockImplementation((row) => {
      if (row.source_id === '1') {
        const error = new Error('private payload');
        error.name = 'private database identifier';
        throw error;
      }
      return original(row);
    });
    try {
      expect(await service.reconstruct('coach-1', 'intent-1')).toMatchObject({
        staged: 2,
        failed: 1,
        reconstructed: 1,
      });
      expect([...prisma.ledger.values()].find((row) => row.source_id === '1')).toMatchObject({
        source_platform: 'truecoach',
        reason: 'error:Error',
      });
    } finally {
      mapper.mockRestore();
    }
  });

  it.each(['P2002', 'P2034'])(
    'retries %s once on skipped and failed ledger writes',
    async (code) => {
      for (const outcome of ['skipped', 'failed']) {
        const { service, prisma } = build((p) => {
          p.staged = [stagedClient('1')];
          if (outcome === 'skipped') p.staged[0].source_platform = 'auto:coachrx.example.com';
          else p.poison.add('1');
        });
        const update = jest.spyOn(prisma.scoutReconstructionLedger, 'upsert').mockRejectedValueOnce(
          new Prisma.PrismaClientKnownRequestError('private', {
            code,
            clientVersion: 'test',
          }),
        );
        await service.reconstruct('coach-1', 'intent-1');
        expect(update).toHaveBeenCalledTimes(2);
        expect([...prisma.ledger.values()][0]).toMatchObject({
          status: outcome,
          source_platform: outcome === 'skipped' ? 'auto:coachrx.example.com' : 'truecoach',
        });
      }
    },
  );

  it.each(['P2002', 'P2034', 'P2003'])(
    'bounds exhausted/nonretryable %s ledger writes',
    async (code) => {
      const { service, prisma } = build((p) => {
        p.staged = [{ ...stagedClient('1'), source_platform: 'unsupported' }];
      });
      const upsert = jest.spyOn(prisma.scoutReconstructionLedger, 'upsert').mockRejectedValue(
        new Prisma.PrismaClientKnownRequestError('private', {
          code,
          clientVersion: 'test',
        }),
      );
      await expect(service.reconstruct('coach-1', 'intent-1')).rejects.toMatchObject({ code });
      expect(upsert).toHaveBeenCalledTimes(code === 'P2003' ? 1 : 2);
      expect(prisma.ledger.size).toBe(0);
    },
  );

  it('rejects an intent that has not settled (still running) with 409', async () => {
    const { service } = build((p) => {
      p.terminalStatus = null;
      p.staged = [stagedClient('1')];
    });
    await expect(service.reconstruct('coach-1', 'intent-1')).rejects.toBeInstanceOf(
      ConflictException,
    );
  });

  it('rejects an unknown intent (no import row) with 409', async () => {
    const { service } = build((p) => {
      p.hasImport = false;
    });
    await expect(service.reconstruct('coach-1', 'intent-x')).rejects.toBeInstanceOf(
      ConflictException,
    );
  });

  it('reconstructs every mappable client and keeps honest accounting', async () => {
    const { service, prisma } = build((p) => {
      p.staged = [stagedClient('1'), stagedClient('2'), stagedClient('3')];
    });
    const result = await service.reconstruct('coach-1', 'intent-1');
    expect(result).toEqual({
      intent_id: 'intent-1',
      staged: 3,
      reconstructed: 3,
      skipped: 0,
      failed: 0,
    });
    expect(result.staged).toBe(result.reconstructed + result.skipped + result.failed);
    expect(prisma.persons.size).toBe(3);
  });

  it('is an idempotent no-op on replay: identical counts, no new rows', async () => {
    const { service, prisma } = build((p) => {
      p.staged = [stagedClient('1'), stagedClient('2')];
    });
    const first = await service.reconstruct('coach-1', 'intent-1');
    const second = await service.reconstruct('coach-1', 'intent-1');
    expect(second).toEqual(first);
    expect(prisma.persons.size).toBe(2);
    expect(prisma.ledger.size).toBe(2);
  });

  it('skips an unmappable row (wrong platform) with a reason and no Person', async () => {
    const { service, prisma } = build((p) => {
      p.staged = [
        stagedClient('1'),
        { source_id: '2', source_platform: 'trainerize', payload: {} },
      ];
    });
    const result = await service.reconstruct('coach-1', 'intent-1');
    expect(result).toEqual({
      intent_id: 'intent-1',
      staged: 2,
      reconstructed: 1,
      skipped: 1,
      failed: 0,
    });
    expect(prisma.persons.size).toBe(1);
    const skipped = [...prisma.ledger.values()].find(
      (r) => r.status === RECONSTRUCT_STATUS.skipped,
    );
    expect(skipped?.reason).toBe('unsupported_platform:trainerize');
    expect(skipped?.target_id).toBeNull();
  });

  it('isolates a poison row to failed while its siblings still reconstruct', async () => {
    const { service, prisma } = build((p) => {
      p.staged = [stagedClient('1'), stagedClient('2'), stagedClient('3')];
      p.poison.add('2');
    });
    const result = await service.reconstruct('coach-1', 'intent-1');
    expect(result).toEqual({
      intent_id: 'intent-1',
      staged: 3,
      reconstructed: 2,
      skipped: 0,
      failed: 1,
    });
    expect(prisma.persons.size).toBe(2);
    const failed = [...prisma.ledger.values()].find((r) => r.status === RECONSTRUCT_STATUS.failed);
    expect(failed?.source_id).toBe('2');
    expect(failed?.target_id).toBeNull();
  });

  it('records a non-PII reason for a failed row (error class only, never payload)', async () => {
    const { service, prisma } = build((p) => {
      p.staged = [stagedClient('1', 'Secret Person')];
      p.poison.add('1');
    });
    await service.reconstruct('coach-1', 'intent-1');
    const failed = [...prisma.ledger.values()][0];
    expect(failed.reason).toBe('error:Error');
    expect(failed.reason).not.toContain('Secret Person');
    expect(failed.reason).not.toContain('@x.io');
  });

  it('handles an empty staged set with all-zero counts', async () => {
    const { service } = build();
    const result = await service.reconstruct('coach-1', 'intent-empty');
    expect(result).toEqual({
      intent_id: 'intent-empty',
      staged: 0,
      reconstructed: 0,
      skipped: 0,
      failed: 0,
    });
  });

  it('emits one completion event per pass with counts and no PII', async () => {
    const { service, capture } = build((p) => {
      p.staged = [stagedClient('1'), { source_id: '', source_platform: 'truecoach', payload: {} }];
    });
    await service.reconstruct('coach-1', 'intent-1');
    expect(capture).toHaveBeenCalledTimes(1);
    expect(capture).toHaveBeenCalledWith('coach-1', Events.SCOUT_RECONSTRUCT_COMPLETED, {
      intent_id: 'intent-1',
      entity_type: 'clients',
      staged: 2,
      reconstructed: 1,
      skipped: 1,
      failed: 0,
    });
    const props = capture.mock.calls[0][2] as Record<string, unknown>;
    expect(JSON.stringify(props)).not.toContain('@x.io');
    expect(Object.keys(props)).not.toContain('email');
  });

  it('uses the stable completion event name', () => {
    expect(Events.SCOUT_RECONSTRUCT_COMPLETED).toBe('scout.reconstruct.completed');
  });

  it('accounts a mixed pass (reconstruct + skip + fail) with the invariant intact', async () => {
    const { service, prisma } = build((p) => {
      p.staged = [
        stagedClient('1'),
        { source_id: '2', source_platform: 'trainerize', payload: {} }, // skip
        stagedClient('3'),
        { source_id: '', source_platform: 'truecoach', payload: {} }, // skip (missing id)
        stagedClient('5'),
      ];
      p.poison.add('5'); // fail
    });
    const result = await service.reconstruct('coach-1', 'intent-1');
    expect(result).toEqual({
      intent_id: 'intent-1',
      staged: 5,
      reconstructed: 2,
      skipped: 2,
      failed: 1,
    });
    expect(result.staged).toBe(result.reconstructed + result.skipped + result.failed);
    expect(prisma.persons.size).toBe(2);
  });

  it('links each reconstructed ledger row to the minted Person via target_id', async () => {
    const { service, prisma } = build((p) => {
      p.staged = [stagedClient('1')];
    });
    await service.reconstruct('coach-1', 'intent-1');
    const person = [...prisma.persons.values()][0];
    const ledgerRow = [...prisma.ledger.values()][0];
    expect(ledgerRow.status).toBe(RECONSTRUCT_STATUS.reconstructed);
    expect(ledgerRow.target_id).toBe(person.id);
    expect(ledgerRow.reason).toBeNull();
  });

  it('heals a previously-failed row on replay once the poison clears (failed → reconstructed)', async () => {
    const prisma = new FakePrisma();
    prisma.staged = [stagedClient('1'), stagedClient('2')];
    prisma.poison.add('2');
    const capture = jest.fn();
    const service = new ScoutReconstructService(asPrisma(prisma), makeAnalytics(capture));

    const first = await service.reconstruct('coach-1', 'intent-1');
    expect(first).toEqual({
      intent_id: 'intent-1',
      staged: 2,
      reconstructed: 1,
      skipped: 0,
      failed: 1,
    });

    prisma.poison.delete('2'); // transient cause resolved
    const second = await service.reconstruct('coach-1', 'intent-1');
    expect(second).toEqual({
      intent_id: 'intent-1',
      staged: 2,
      reconstructed: 2,
      skipped: 0,
      failed: 0,
    });
    expect(prisma.persons.size).toBe(2);
    expect(prisma.ledger.size).toBe(2);
    const healed = [...prisma.ledger.values()].find((r) => r.source_id === '2');
    expect(healed?.status).toBe(RECONSTRUCT_STATUS.reconstructed);
    expect(healed?.reason).toBeNull();
  });

  it('updates the display name on replay without minting a new Person', async () => {
    const prisma = new FakePrisma();
    prisma.staged = [stagedClient('1', 'Old Name')];
    const capture = jest.fn();
    const service = new ScoutReconstructService(asPrisma(prisma), makeAnalytics(capture));

    await service.reconstruct('coach-1', 'intent-1');
    prisma.staged = [stagedClient('1', 'New Name')];
    await service.reconstruct('coach-1', 'intent-1');

    expect(prisma.persons.size).toBe(1);
    expect([...prisma.persons.values()][0].display_name).toBe('New Name');
  });

  it('keeps two coaches isolated even when they share a source_id', async () => {
    const prismaA = new FakePrisma();
    prismaA.staged = [stagedClient('shared')];
    const prismaB = new FakePrisma();
    prismaB.staged = [stagedClient('shared')];
    const noop = makeAnalytics(jest.fn());

    const a = await new ScoutReconstructService(asPrisma(prismaA), noop).reconstruct(
      'coach-A',
      'intent-1',
    );
    const b = await new ScoutReconstructService(asPrisma(prismaB), noop).reconstruct(
      'coach-B',
      'intent-1',
    );

    expect(a.reconstructed).toBe(1);
    expect(b.reconstructed).toBe(1);
    expect([...prismaA.persons.keys()][0]).toContain('coach-A');
    expect([...prismaB.persons.keys()][0]).toContain('coach-B');
  });

  it('records the missing_source_id reason for an empty-id skip', async () => {
    const { service, prisma } = build((p) => {
      p.staged = [{ source_id: '   ', source_platform: 'truecoach', payload: {} }];
    });
    const result = await service.reconstruct('coach-1', 'intent-1');
    expect(result.skipped).toBe(1);
    const skipped = [...prisma.ledger.values()][0];
    expect(skipped.reason).toBe('missing_source_id');
    expect(skipped.target_id).toBeNull();
  });

  it('settles for any non-null terminal status (partial/failed are still settled)', async () => {
    for (const terminal of ['success', 'partial', 'failed']) {
      const { service } = build((p) => {
        p.terminalStatus = terminal;
        p.staged = [stagedClient('1')];
      });
      const result = await service.reconstruct('coach-1', `intent-${terminal}`);
      expect(result.reconstructed).toBe(1);
    }
  });

  it('performs NO reconstruction work when the intent is rejected as unsettled', async () => {
    const { service, prisma, capture } = build((p) => {
      p.terminalStatus = null;
      p.staged = [stagedClient('1'), stagedClient('2')];
    });
    const findMany = jest.spyOn(prisma.scoutIngestEntity, 'findMany');
    await expect(service.reconstruct('coach-1', 'intent-1')).rejects.toBeInstanceOf(
      ConflictException,
    );
    // Fail-closed BEFORE any staged read, Person mint, ledger write, or event —
    // a running crawl must never leave a partial roster behind.
    expect(findMany).not.toHaveBeenCalled();
    expect(prisma.persons.size).toBe(0);
    expect(prisma.ledger.size).toBe(0);
    expect(capture).not.toHaveBeenCalled();
  });

  it('emits no analytics event when an unknown intent is rejected', async () => {
    const { service, capture } = build((p) => {
      p.hasImport = false;
    });
    await expect(service.reconstruct('coach-1', 'intent-x')).rejects.toBeInstanceOf(
      ConflictException,
    );
    expect(capture).not.toHaveBeenCalled();
  });

  it('reconstructs a mappable client with no name into a null-display_name Person', async () => {
    const { service, prisma } = build((p) => {
      p.staged = [{ source_id: '1', source_platform: 'truecoach', payload: { email: '1@x.io' } }];
    });
    const result = await service.reconstruct('coach-1', 'intent-1');
    expect(result).toEqual({
      intent_id: 'intent-1',
      staged: 1,
      reconstructed: 1,
      skipped: 0,
      failed: 0,
    });
    expect(prisma.persons.size).toBe(1);
    expect([...prisma.persons.values()][0].display_name).toBeNull();
  });

  it('scopes the tally to the requested intent (a sibling intent does not leak in)', async () => {
    const prisma = new FakePrisma();
    prisma.staged = [stagedClient('1'), stagedClient('2')];
    const service = new ScoutReconstructService(asPrisma(prisma), makeAnalytics(jest.fn()));

    const a = await service.reconstruct('coach-1', 'intent-A');
    expect(a).toEqual({
      intent_id: 'intent-A',
      staged: 2,
      reconstructed: 2,
      skipped: 0,
      failed: 0,
    });

    // groupBy in the fake is intent-agnostic by construction, so this asserts the
    // service passes the intent filter and does not double-count across intents.
    const b = await service.reconstruct('coach-1', 'intent-A');
    expect(b).toEqual(a);
    expect(prisma.ledger.size).toBe(2);
  });

  it('writes exactly one ledger row per staged row (accounting is exhaustive)', async () => {
    const { service, prisma } = build((p) => {
      p.staged = [
        stagedClient('1'),
        { source_id: '2', source_platform: 'trainerize', payload: {} },
        stagedClient('3'),
      ];
      p.poison.add('3');
    });
    const result = await service.reconstruct('coach-1', 'intent-1');
    // staged (result) === ledger rows === reconstructed + skipped + failed.
    expect(prisma.ledger.size).toBe(result.staged);
    expect(result.staged).toBe(3);
  });

  describe('P3-1 bounded fan-out (fail-closed ceiling + deterministic paging)', () => {
    it('rejects an over-ceiling intent BEFORE any read, mint, ledger write, or event', async () => {
      const { service, prisma, capture } = build((p) => {
        p.stagedCountOverride = RECONSTRUCT_MAX_ROWS + 1;
      });
      const findMany = jest.spyOn(prisma.scoutIngestEntity, 'findMany');
      await expect(service.reconstruct('coach-1', 'intent-huge')).rejects.toBeInstanceOf(
        ConflictException,
      );
      expect(findMany).not.toHaveBeenCalled();
      expect(prisma.persons.size).toBe(0);
      expect(prisma.ledger.size).toBe(0);
      expect(capture).not.toHaveBeenCalled();
    });

    it('accepts an intent exactly at the ceiling (boundary is inclusive)', async () => {
      const { service } = build((p) => {
        p.stagedCountOverride = RECONSTRUCT_MAX_ROWS;
        p.staged = [stagedClient('1')];
      });
      // count is overridden to the ceiling, so the guard must NOT reject; the
      // actual staged array is small so the pass completes.
      const result = await service.reconstruct('coach-1', 'intent-1');
      expect(result.staged).toBe(RECONSTRUCT_MAX_ROWS);
      expect(result.reconstructed).toBe(1);
    });

    it('paginates a multi-page intent deterministically and reconstructs every row', async () => {
      const total = RECONSTRUCT_PAGE_SIZE * 2 + 1; // forces exactly 3 pages
      const { service, prisma } = build((p) => {
        p.staged = Array.from({ length: total }, (_v, i) =>
          stagedClient(String(i).padStart(5, '0')),
        );
      });
      const result = await service.reconstruct('coach-1', 'intent-big');
      expect(result).toEqual({
        intent_id: 'intent-big',
        staged: total,
        reconstructed: total,
        skipped: 0,
        failed: 0,
      });
      expect(prisma.persons.size).toBe(total);
      // Three deterministic pages with monotonically increasing skip offsets.
      expect(prisma.pages).toEqual([
        { skip: 0, take: RECONSTRUCT_PAGE_SIZE },
        { skip: RECONSTRUCT_PAGE_SIZE, take: RECONSTRUCT_PAGE_SIZE },
        { skip: RECONSTRUCT_PAGE_SIZE * 2, take: RECONSTRUCT_PAGE_SIZE },
      ]);
    });
  });

  describe('P3-2 same-intent concurrency (P2002 retry converges, no double-count)', () => {
    it('retries once on a lost insert race and converges to reconstructed', async () => {
      const { service, prisma } = build((p) => {
        p.staged = [stagedClient('1')];
        p.p2002Once.add('1'); // first person.upsert throws P2002, retry succeeds
      });
      const result = await service.reconstruct('coach-1', 'intent-1');
      expect(result).toEqual({
        intent_id: 'intent-1',
        staged: 1,
        reconstructed: 1,
        skipped: 0,
        failed: 0,
      });
      // Exactly one Person and one ledger row — the race did not double-count.
      expect(prisma.persons.size).toBe(1);
      expect(prisma.ledger.size).toBe(1);
      const row = [...prisma.ledger.values()][0];
      expect(row.status).toBe(RECONSTRUCT_STATUS.reconstructed);
      expect(row.reason).toBeNull();
    });

    it('records failed (not a 500) when the retry also loses', async () => {
      const { service, prisma } = build((p) => {
        p.staged = [stagedClient('1')];
        p.p2002Once.add('1'); // first attempt loses the race...
        p.poison.add('1'); // ...and the retry throws too
      });
      // Must not propagate — the row is isolated as failed with a non-PII reason.
      const result = await service.reconstruct('coach-1', 'intent-1');
      expect(result.failed).toBe(1);
      expect(result.reconstructed).toBe(0);
      const row = [...prisma.ledger.values()][0];
      expect(row.status).toBe(RECONSTRUCT_STATUS.failed);
      expect(row.reason).toBe('error:Error');
    });

    it('a serial replay after a race is a clean idempotent no-op', async () => {
      const prisma = new FakePrisma();
      prisma.staged = [stagedClient('1'), stagedClient('2')];
      prisma.p2002Once.add('2');
      const service = new ScoutReconstructService(asPrisma(prisma), makeAnalytics(jest.fn()));
      const first = await service.reconstruct('coach-1', 'intent-1');
      const second = await service.reconstruct('coach-1', 'intent-1');
      expect(second).toEqual(first);
      expect(prisma.persons.size).toBe(2);
      expect(prisma.ledger.size).toBe(2);
    });
  });

  describe('P3-3 PII-safe failure observability', () => {
    it('logs a warn (counts + correlation ids only) when a row fails, never payload', async () => {
      const warn = jest.spyOn(Logger.prototype, 'warn').mockImplementation(() => undefined);
      try {
        const { service } = build((p) => {
          p.staged = [stagedClient('1', 'Secret Name'), stagedClient('2', 'Also Secret')];
          p.poison.add('2');
        });
        await service.reconstruct('coach-1', 'intent-1');
        expect(warn).toHaveBeenCalledTimes(1);
        const msg = String(warn.mock.calls[0][0]);
        expect(msg).toContain('coach-1');
        expect(msg).toContain('intent-1');
        expect(msg).toContain('"failed":1');
        expect(msg).not.toContain('Secret Name');
        expect(msg).not.toContain('Also Secret');
        expect(msg).not.toContain('@x.io');
      } finally {
        warn.mockRestore();
      }
    });

    it('logs at info (not warn) on a fully clean pass', async () => {
      const warn = jest.spyOn(Logger.prototype, 'warn').mockImplementation(() => undefined);
      const log = jest.spyOn(Logger.prototype, 'log').mockImplementation(() => undefined);
      try {
        const { service } = build((p) => {
          p.staged = [stagedClient('1')];
        });
        await service.reconstruct('coach-1', 'intent-1');
        expect(warn).not.toHaveBeenCalled();
        expect(log).toHaveBeenCalledTimes(1);
        const msg = String(log.mock.calls[0][0]);
        expect(msg).toContain('"failed":0');
        expect(msg).not.toContain('@x.io');
      } finally {
        warn.mockRestore();
        log.mockRestore();
      }
    });
  });

  describe('P3-5 object-level tenant scoping (coach_id on every DB access)', () => {
    it('scopes count, findMany, and tally.groupBy by the token coach_id', async () => {
      const prisma = new FakePrisma();
      prisma.staged = [stagedClient('1')];
      const count = jest.spyOn(prisma.scoutIngestEntity, 'count');
      const findMany = jest.spyOn(prisma.scoutIngestEntity, 'findMany');
      const groupBy = jest.spyOn(prisma.scoutReconstructionLedger, 'groupBy');
      const service = new ScoutReconstructService(asPrisma(prisma), makeAnalytics(jest.fn()));

      await service.reconstruct('coach-7', 'intent-1');

      for (const spy of [count, findMany, groupBy]) {
        const arg = spy.mock.calls[0][0] as { where: { coach_id: string } };
        expect(arg.where.coach_id).toBe('coach-7');
      }
      // The minted Person key embeds the tenant, so no cross-tenant collision.
      expect([...prisma.persons.keys()][0]).toContain('coach-7');
    });
  });
});
