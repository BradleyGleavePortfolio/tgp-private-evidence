# S7-1′ correction — READY (source-only; no runtime, no commit, no hooks, no tsc/Jest run)

Builder s5_exact_candidate_continuation (T4). Scope: exactly the 13 TypeScript files the pre-commit Prettier hook refused (`s7-foundation/logs/06-commit.log`, "Code style issues found in 13 files"; list `FILES13.txt`), formatted mechanically with the existing pinned Prettier 3.9.6 CLI (`6e922134…`, the same link S5/S3 hooks used) and the repository's own unchanged config (`.prettierrc.json ee1ad136`, `.editorconfig`, `.prettierignore`, identical on both parents). No policy/config/hook/dependency/source-behaviour change. Work done on copies under `src/` (originals kept under `orig/`); the retained merge state in `worktrees/s7-foundation` is untouched (HEAD `be0ba827`, MERGE_HEAD `98d39610`, index tree `c54386ec`, clean). Heavy slot: S6's; nothing run.

## Frozen artifacts
| item | value |
|---|---|
| 13 file provenance | `PINS_BEFORE.txt`: each index blob == `98d39610` blob; the 3 `src/scout/*` blobs == PR529 `d7404cd4` |
| formatted pins | `PINS_AFTER.txt` (sha256 + blob + line counts) |
| patch | `format-13files.patch` sha256 **`462513931a608e39…`**, 93,194 B, 13 files, 953+/433− raw; `git apply --check` on an export of `c54386ec` = OK and result byte-identical to `src/` |
| base merge tree | `c54386ec52a0c01050be4316f70efc45f5f13cc0` (retained clean merge) |
| **candidate predicted tree** | **`7800ecb4d294a48ed3d7282363265e5f07339f97`** = base + the 13 formatted blobs (temp index; `diff-tree` vs base = exactly `FILES13.txt`) — `CANDIDATE_TREE.txt` |
| merge message r2 | `07-merge-message.r2.txt` sha256 `67a3df0257e1e221…` = approved `d94f24fd` text + one "Formatting only" paragraph and "no authored change other than the formatting noted below"; 0 banned tokens. **Needs parent approval** (message differs from the frozen d94f24fd). |
| activation script | `08-commit-launch-r2.sh` sha256 `613511a082846877…` |

## Semantic-neutrality evidence (`NEUTRALITY_EVIDENCE.txt`, `logs/format.log`; existing formatter/diff only)
1. `prettier --debug-check` on the 13 ORIGINAL files rc 0 — Prettier's own assertion that the formatted output parses to the same AST; `--check` after rc 0 ("All matched files use Prettier code style!"); second `--write` changed 0 files (idempotent); `--debug-check` after rc 0.
2. Whitespace-insensitive residual (`git diff -w --ignore-blank-lines`) consists only of Prettier's punctuation moves: wrapping parentheses around multi-line boolean/ternary/arrow expressions, trailing commas, leading `|` in a multi-line union type, `{ … }` block braces around one-line arrow bodies (same statements). Full residual listed in the evidence file.
3. Normalised-text identity (strip whitespace, `(`, `)`, `,`, `;`, leading union `|`): 13/13 files identical before vs after.
4. Identifier / number / string-literal multiset per file: 13/13 identical.
→ Applicability claim for reviewers: S3/S5 behaviour and the PG17 fresh51 proof (`98d39610`) transfer unchanged — the 13 formatted files are AST-identical; no PG rerun requested.

## Commit activation (prepared, NOT run) — `08-commit-launch-r2.sh`, persistent launch, bound 600 s, exclusive CPU
Env = S5/S3 established resource binding: `NODE_OPTIONS=--max-old-space-size=4096` (+ `GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 npm_config_offline=true` and the notice-suppression flags), no tsconfig weakening/exclusion. Steps, each guarded, stop on mismatch (rc 70/71), no retry: preconditions (HEAD `be0ba827`, MERGE_HEAD `98d39610`, index tree `c54386ec`, clean, patch pin) → `git apply --index format-13files.patch` → tree guard `write-tree == 7800ecb4…` → `git commit -F 07-merge-message.r2.txt` with real lefthook pre-commit (prod-readiness-quick, banned-cast-tokens, prettier, eslint, tsc) + commit-msg. Expected: 2-parent commit `HEAD^1=be0ba827 HEAD^2=98d39610`, tree `7800ecb4…`, Bradley author=committer, no trailers. Post-checks + bundle `c23b9d9f..HEAD` and receipt follow. Launch: `setsid nohup bash /home/user/workspace/execution/e7d2385c/s7-foundation-format/08-commit-launch-r2.sh`; poll `logs/08-commit.sentinel`.

## Not claimed / not done
No hooks, tsc, Jest, PG, install, network, product push. Any hook refusal on activation is recorded and stops the run. Reviewers are asked to review only the composition + this format diff/evidence, not the accepted parents.
