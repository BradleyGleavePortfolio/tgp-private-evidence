#!/usr/bin/env bash
# S7-1' commit activation r2: apply frozen 13-file formatter patch to the retained merge state, tree guard, real-hook commit.
# Environment = S5/S3 established resource binding (NODE_OPTIONS 4096 MB) + same offline npm flags. Bound 600 s. Persistent (setsid nohup); sentinel marks terminal.
set -u
F=/home/user/workspace/execution/e7d2385c/s7-foundation-format; L=$F/logs; W=/home/user/workspace/worktrees/s7-foundation
export GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 NODE_OPTIONS=--max-old-space-size=4096 PRISMA_HIDE_UPDATE_MESSAGE=1 npm_config_update_notifier=false npm_config_fund=false npm_config_audit=false npm_config_offline=true CHECKPOINT_DISABLE=1 LEFTHOOK_VERBOSE=1
cd "$W" || { echo "COMMIT_RC=74 END=$(date -u +%FT%TZ)" > $L/08-commit.sentinel; exit 74; }
log=$L/08-commit.log; echo "R2_START $(date -u +%FT%TZ) pid=$$ NODE_OPTIONS=$NODE_OPTIONS bound=600s" > $log
stop(){ echo "R2_STOP $1 $(date -u +%FT%TZ)" >> $log; echo "COMMIT_RC=$2 STAGE=$1 END=$(date -u +%FT%TZ)" > $L/08-commit.sentinel; exit $2; }
[ "$(git rev-parse HEAD)" = be0ba8274e486dee77f15d18fe367a13ff08ecf5 ] || stop precondition-HEAD 70
[ "$(cat .git/MERGE_HEAD 2>/dev/null)" = 98d39610f511505558373f3a59fa019804c94bd7 ] || stop precondition-MERGE_HEAD 70
[ "$(git write-tree)" = c54386ec52a0c01050be4316f70efc45f5f13cc0 ] || stop precondition-index-tree 70
[ -z "$(git diff --name-only)$(git status --porcelain --untracked-files=all | grep '^??')" ] || stop precondition-dirty 70
[ "$(sha256sum $F/format-13files.patch | cut -c1-64)" = "$(grep -o 'PATCH_SHA256=[0-9a-f]*' $F/CANDIDATE_TREE.txt | cut -d= -f2)" ] || stop precondition-patch-pin 70
echo "APPLY $(date -u +%FT%TZ)" >> $log; git apply --index "$F/format-13files.patch" >> $log 2>&1 || stop apply $?
T=$(git write-tree); echo "TREE_AFTER_APPLY=$T" >> $log
[ "$T" = 7800ecb4d294a48ed3d7282363265e5f07339f97 ] || stop tree-guard 71
[ "$(git diff --name-only | wc -l)" = 0 ] || stop unstaged-after-apply 71
echo "COMMIT_START $(date -u +%FT%TZ)" >> $log
timeout -k 30 600 git commit -F "$F/07-merge-message.r2.txt" >> $log 2>&1; rc=$?
echo "COMMIT_END $(date -u +%FT%TZ) rc=$rc HEAD=$(git rev-parse HEAD) tree=$(git rev-parse 'HEAD^{tree}')" >> $log
echo "COMMIT_RC=$rc STAGE=commit END=$(date -u +%FT%TZ) HEAD=$(git rev-parse HEAD)" > $L/08-commit.sentinel
