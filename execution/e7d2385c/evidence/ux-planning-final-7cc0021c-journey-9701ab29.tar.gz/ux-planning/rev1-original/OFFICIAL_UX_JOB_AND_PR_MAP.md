# Official TGP importer UX job and PR map (source-only)

Worker `plan_importer_ux_lane`, parent EXEC-e7d2385c, 2026-09-23 ~20:58 UTC (supersedes the 20:55 draft after the owner's 13:55 PDT naming direction). Requested route Claude Fable 5 / High (requested setting, not observed runtime identity). Read-only inputs; sole writes `execution/e7d2385c/ux-planning/**` excluding `journey/` (owned by `specify_mobile_importer_journey_muekv9nz`). Nothing built, branched, run, installed, edited in a product tree or written remotely; GitHub read with `gh` only. No PR number below is invented: every `#n` is an existing open PR observed live at ~20:50 UTC; `UX-0N` labels are official coordination/outcome names supplied by the owner, and PR titles are *proposals* in the owner's format `UX-03: Desktop handoff and pairing experience`.

**Tier header (this artifact).** Tier: T4 cumulative (parent grading). Why: allocates authority, PII and terminal-state boundaries across mobile, extension and backend without changing bytes. T4 scan: session trust / tenancy / PII / terminal truth allocation. T3 scan: cross-repo ownership (inherited from canonical docs, none invented). Bounded T1: NO. Canonical builder: Claude Fable 5 / High. Acceptance: parent read, journey worker cross-reference, `MANIFEST.sha256`. Promotion triggers: none (documentation only). This planning artifact is **not** an official outcome; it maps into UX-01 and the overall register.

## 0. Official outcome names (owner, 13:55 PDT) and what each contains

| Outcome | Official name | Contains (from plan/mission) |
|---|---|---|
| **UX-01** | Importer Journey & State Architecture | Journey spec + state/edge matrix, account-scoped journey state, one-intent/one-run consumer model, contract questions to S7 generator owner, this map |
| **UX-02** | Roman Import Entry & Discovery | Post-onboarding Roman offer, Yes/fresh/Later, permanent Home "Continue import setup" card and Settings → Import my records, Roman-gate-off functional entry, source selection as shortcut list |
| **UX-03** | Desktop Handoff & Pairing Experience | Phone "Continue on your computer", trusted non-authorizing setup locator, short code entry, returning-coach no-code path, destination-account confirmation, account mismatch → disconnect/re-pair, readiness checklist (Importer available → Connected to TGP → Previous platform ready) with exact remedies, "Confirm source account", extension task surface presentation |
| **UX-04** | Import Start, Progress & Stop Experience | Ready card + single Start, three-phase running panel with measured counts/freshness, honest indeterminate/determinate progress, Stop on both surfaces with "Stopping"/offline truth |
| **UX-05** | Failure, Partial & Recovery Experience | Partial/Blocked/Failed/Cancelled/Timed-out views, one reason + one safe recovery action, retry linked not reset, legacy intents shown as legacy, setup-error remedies (missing/disabled/old/wrong-profile/unsupported device, denied origins) |
| **UX-06** | Imported Results & Native Deep Links | Verified Complete view, "Open my clients" primary, "Review import details" secondary with per-family reconciliation/coverage, native deep links by owned IDs failing closed elsewhere, review API/type alignment to the generated contract |
| **UX-07** | Importer Design System & Accessibility | Shared import-journey primitives on TGP tokens, quiet-luxury layout rules, WCAG AA/44pt/focus/dynamic type/reduced motion/announcements, extension popup styling, shared a11y test suite; **cross-cutting, starts now alongside UX-01** |
| **UX-08** | End-to-End Journey Usability Proof | Scenario 1–19 journey tests on app + desktop, packaged-browser tests on minimum and current hosts plus S11 second host, unfamiliar-coach usability/a11y study, V1 zero-action traces, privacy-safe funnel; **converges with S11/S12** |

UX numbers are coordination labels, **not** dependency order and **not** a sequence competing with S1–S12 (see §1 and `DEPENDENCY_DAG.md`).

## 1. Relationship to S1–S12 (mission phases)

S1–S12 are mission phases: foundation (S1–S6), C1/G2 contract composition (S7), native writers (S8), relationships/reconciliation (S9), unseen-source induction (S10), complete customer/multi-host journey (S11), real acceptance/pilot (S12). UX-0N outcomes are a *consumer lane* whose implementation PRs attach to whichever phase freezes the contract they consume: UX-01/02/07 attach to nothing beyond mobile main and the M5 chain; UX-03 attaches to S7 (C1 pairing/intent contract) and the G3 auth freeze; UX-04/05 attach to the S7 lifecycle contract (server Start/cancel/deadline/terminals — currently MISSING in every inspected tree); UX-06 attaches to S8/S9; UX-08 converges with S11/S12. UX never freezes a contract, decides state authority, creates or terminates a run, decides completion, or encodes a source. Canonical names (M5-A/B/C/D/F, C1, G2 stages, C2a…V1, G0–G7, "Roman P1/P2") remain as-is; existing PRs are not renamed.

## 2. Mandatory targeted live inventory, mobile #289–#294 (gh, 2026-09-23 ~20:50 UTC)

"Implemented" = bytes exist on the head. "Proven" = independently accepted at exact head; **none** of the six has a submitted GitHub review, and public CI green is not R14 dual attestation. Private review status of these bytes is unknown to this worker, not asserted absent.

| PR | Title (verbatim) | Base → head | Changed paths | Implemented | Proven | Maps to |
|---|---|---|---|---|---|---|
| #289 | Declare zod and make CI installs deterministic (M5-A) | `main a5933fd6` → `22354984` (4 commits `4be69b90`,`8f0b5845`,`ba3fd409`,`22354984`) | `.github/pull_request_template.md`, `.github/workflows/ci.yml`, `README.md`, `package.json`, `package-lock.json`, `src/config/__tests__/declaredDependencies.test.ts` | Yes: zod declared, deterministic CI install, dependency guard over root entrypoints/workflows | CI 4/4 SUCCESS; draft; 0 reviews | Prerequisite for every mobile UX PR (deterministic install/dependency guard); no UX bytes |
| #290 | Declare import flags and add an independent review kill switch (M5-B) | `m5-a @ 4be69b90` → `ed0342e9` | `.env.example`, `src/config/featureFlags.ts`, `src/config/__tests__/importFlags.test.ts`, `src/hooks/useReconstructCounts.ts`, `…/__tests__/useReconstructCounts.test.tsx` | Yes: import flags default-off, independent review kill switch, reconstruct-count hook gated | CI 1/1; draft; 0 reviews; **base is stale first #289 commit** | UX-02 (flag gating of entry), UX-06 (kill switch over review; `useReconstructCounts` is the donor to retire roster-count-as-result) |
| #291 | Durable user-scoped pairing state and support correlation (M5-C/D) | `m5-b @ ed0342e9` → `d2f0d31c` | `src/hooks/useExtensionPairing.ts`, `src/storage/importPairingMirror.ts`, `src/utils/{correlation,idempotency}.ts`, `src/api/extensionPairApi.ts`, `src/services/{api,authActions}.ts`, `src/analytics/events.ts`, `docs/importer/MOBILE_IMPORT_DECISION.md` (+6 tests) | Yes: per-user pairing mirror, sign-out handling, correlation IDs, idempotency | CI 1/1; draft; 0 reviews | UX-01 (account-scoped state donor pattern), UX-03 (pairing hook/API consumer), UX-08 (opaque correlation for funnel) |
| #292 | Make the pairing code readable, copyable, and honest about it (M5-F) | `m5-cd @ d2f0d31c` → `34088677` | `src/components/coach/ExtensionPairingPanel.tsx`, `…/__tests__/ExtensionPairingPanel.{a11y,}.test.tsx` | Yes: readable/copyable code, honest status | CI 1/1; draft; 0 reviews | UX-03 (code entry surface), UX-07 (a11y test donor) |
| #293 | feat(import): add private Roman P1 presentation views | `main a5933fd6` → `003a9774` | 11 new files under `src/screens/coach/import-journey/`: `ImportOfferCard.tsx`, `ImportSetupView.tsx`, `importJourneyCopy.ts`, `importJourneyUI.tsx`, `i18n/en.json`, `README.md`, 5 tests incl. `sideEffectGuards.cjs` | Yes: offer card (question/value/compact resume; "sir" only with Roman on), setup view (source selection, custom public-HTTPS format feedback, computer-handoff instructions), copy dictionary, test-only traversal host. Body: no navigator registration, no API/storage/auth/analytics/Linking/Clipboard/Share, no flags | CI 4/4; PR body reports 69 tests/eslint/typecheck pass; draft; 0 reviews; T1 inactive | UX-02 (offer + resume card), UX-03 (setup/handoff view), UX-07 (`importJourneyUI.tsx` primitives + copy convention) |
| #294 | WIP: Roman importer P2 controlled status views — halted handoff | `#293 @ 003a9774` → `5cbf0de3` (2 commits) | 11 files under `import-journey/`: `ImportProgressView.tsx`, `ImportResultView.tsx`, `ImportStatusFrame.tsx`, `P2_README.md`, copy/i18n additions, a11y/transitions/status tests | Yes (WIP): progress (phase, stale/unavailable, stop pending/offline) and result views (unconfirmed, blocked, interrupted, failed, timed out, cancelled, transfer-only, unavailable, supplied native subset/complete/proven-zero); receipts vs unconfirmed separated; callbacks only; no lifecycle engine | CI 1/1; body reports 101 tests pass before halt, RN-Web synthetic layout gate; explicitly "incomplete, independently unreviewed, do not merge" | UX-04 (progress/stop presentation), UX-05 (adverse terminals), UX-06 (complete/result frame) |

### 2.1 Reconciliation: #290 base `4be69b90` vs #289 head `22354984`

#290's base is #289's **first** commit; #289 then received three amendments (`8f0b5845` parse imports with tsc, `ba3fd409` guard root entrypoints and every workflow, `22354984` resolve npm aliases/bundled .js/derive entrypoints) touching only `README.md`, `package.json`, `package-lock.json`, `.github/pull_request_template.md`, `src/config/__tests__/declaredDependencies.test.ts`. So #290→#291→#292 compose onto a stale M5-A and lack the final dependency-guard semantics (Op 80's "three missing amendments" is still live). Path intersection of those amendments with #290/#291/#292 changed files: **zero** → predicted textually clean recomposition (prediction, not proof). Behavioral risk: the strengthened guard scans every workflow/root entrypoint, so the recomposed chain must run against #289's final guard. **Disposition:** `M5-REBASE` is canonical M5-lane work (mobile M5 chain builder; keep names M5-B/C/D/F, no renames, no new PRs invented here), and a code-start gate for every UX PR that bases on the chain (UX-01 state store, UX-02 flag-gated entry, UX-03, UX-04/05 phone views, UX-06, UX-08 funnel). #293/#294 sit on `main`, not on the chain; adopting them requires re-basing onto the reconciled chain (parent disposition `ROMAN-DONOR`: adopt as donors / re-base / supersede). Reuse, never recreate: any UX PR that would re-author bytes present in #289–#294 must instead base on or cherry-pick the existing commit and cite it.

## 3. Canonical dependency vocabulary

| Key | Meaning |
|---|---|
| **S7-2′** | C1 #526 on composed S3+S5 foundation + one forward-2.x contract regeneration by the sole generator owner; freezes `import_intent_id`, `pair/current`, `pair/session`, idempotent init (S7 addendum §3) |
| **S7-L** | Lifecycle contract, MISSING everywhere inspected: server-accepted Start/cancel/deadline, execution epoch/commit fencing, setup states, phases, terminals `complete/partial/blocked/failed/cancelled/timed_out`, per-family counts (plan "Proposed run-state contract") |
| **S7-REV** | Intent-required review requests + single generated response schema fixing `importReviewApi.ts`/`importReview.ts` drift (plan contract decision 4) |
| **G3-AUTH** | Auth-owner freeze: extension disconnect/revocation, source principal/workspace attribution + evidence epochs, capability/version negotiation, status transport (existing realtime vs bounded foreground reads) |
| **S8 / S9** | Native writers with owned IDs / relationships, coverage manifest, reconciliation counts and reason codes |
| **S11 / S12** | Second host on the same kernel / real acceptance, pilot, V1 evidence, usability study |
| **M5-REBASE** | §2.1 recomposition of #290–#292 onto `22354984` + composed acceptance |
| **EXT-PKG** | Extension packaged-load fix (`content/main.js` classic vs ESM) + capability reporting; extension lane (WS1), not UX |
| **ROMAN-DONOR** | Parent disposition of #293/#294 |
| **JOURNEY-SPEC** | `ux-planning/journey/CANONICAL_MOBILE_JOURNEY_SPEC.md` + `STATE_AND_EDGE_CASE_MATRIX.md` + `CONTRACT_QUESTIONS.md` accepted by parent |

## 4. Outcome → job → proposed PR map

Common rules for every implementation PR: default-off behind #290 flags and existing backend controls; TGP tokens only (no stone/gold small body text); static approved copy, no LLM dependency; no source credentials or bearer/pairing data in any UI/URL; no source-specific UI (source selection = `src/constants/importPlatforms.ts` shortcut list + "Find another platform", no supported badges); one writer per mutable area (mobile navigation/state; extension popup logic WS1 vs popup HTML/CSS WS6); every T4 PR gets two independent exact-head attestations; Bradley author/committer, no AI trailers; no remote landing implied by local acceptance. Each PR title is `UX-0N: <outcome, sentence case>` with a host suffix only when one outcome needs one PR per repository.

### UX-01 — Importer Journey & State Architecture
| Field | Content |
|---|---|
| Jobs | UX-01.design: journey spec, state/edge matrix, contract questions (journey worker) + this map. UX-01.state: account-scoped journey state consumer. |
| Proposed PR title | `UX-01: Importer journey and state architecture — account-scoped journey state (mobile)` |
| Purpose | Persist Later/fresh decision and setup place per authenticated account; another account cannot inherit it; sign-out clears app-scoped state without claiming extension revocation; resume binds to the server-owned intent via `pair/current` once S7-2′ exists; single consumer model of one intent / one run for all UX surfaces. |
| Tier (before implementation) | T4. Why: tenancy/account isolation of persisted state and sign-out semantics. T4 trigger: cross-account state leakage. Bounded T1: NO. |
| Owned paths | new `src/storage/importJourneyState.ts` (+tests; pattern donor #291 `importPairingMirror.ts`); hook into `src/services/authActions.ts` sign-out (shared with #291 → serialize under the M5 chain owner); `src/types/extensionImport.ts` consumer types only after S7-2′ fixtures. |
| Entry | JOURNEY-SPEC accepted; `M5-REBASE` (for #291 semantics). |
| Exit | account-switch test: no inheritance; sign-out clears, emits no disconnect claim; resume returns the same setup (intent-bound test gated on S7-2′ fixtures); no client-supplied coach ID anywhere. |
| Parallelism | Design now, ∥ everything. State PR ∥ UX-02/UX-07 code; serial with #291 owner on `authActions.ts`. |
| Code-start gate | `M5-REBASE` + JOURNEY-SPEC; intent binding waits for S7-2′ consumer fixtures. |

### UX-02 — Roman Import Entry & Discovery
| Field | Content |
|---|---|
| Proposed PR title | `UX-02: Roman import entry and discovery (mobile)` |
| Purpose | First eligible coach-home entry after onboarding: one Roman card "Have you coached on another platform before[, sir]?" → Yes / I am starting fresh / Later; Yes → "Would you like to bring your clients and coaching history into TGP?" → "Import my records"; Later → compact "Continue import setup" Home card + Settings → Import my records; fresh → Settings entry only; Roman gate off → plain functional entry; typed chat action routes to the same controller; clients never see it; eligibility is server-side. |
| Tier | T2. Why: user-visible behavior on existing patterns (donor #293 `ImportOfferCard`). T4 scan: none provided persistence/eligibility live in UX-01.state and server flags; promote if any client-side eligibility or role inference appears. Bounded T1: NO. |
| Owned paths | `src/screens/coach/import-journey/ImportOfferCard.tsx`, `importJourneyCopy.ts`, `i18n/en.json` (from #293); one mount in `src/screens/coach/CoachHomeScreen.tsx`; one row in `src/screens/coach/SettingsScreen.tsx`/`settings/*`; one route in `src/navigation/CoachNavigator.tsx` to existing `ImportDataScreen.tsx`. Not owned: flags (#290), storage (UX-01). |
| Entry | JOURNEY-SPEC copy/states; `ROMAN-DONOR`; UX-01 state interface named (fixture allowed during build). |
| Exit | offer once per eligible account (scenario 1); Later/fresh keep TGP usable, permanent entry present with importer flag on and absent off (scenario 2); no Roman assets with gate off; UX-07 a11y suite passes; zero source network calls. |
| Parallelism | ∥ UX-01.state, UX-07; serial with any other `CoachHomeScreen.tsx`/`CoachNavigator.tsx` writer. |
| Code-start gate | JOURNEY-SPEC + `ROMAN-DONOR` + assigned sole mobile UI/navigation writer; Settings/Home flag gating needs `M5-REBASE`. Does **not** need S7-2′. |

### UX-03 — Desktop Handoff & Pairing Experience
| Field | Content |
|---|---|
| Proposed PR titles | `UX-03: Desktop handoff and pairing experience (mobile)` · `UX-03: Desktop handoff and pairing experience (extension)` |
| Purpose | Mobile: "Continue on your computer. I will keep your place here."; open/copy a trusted setup address carrying at most a non-authorizing opaque locator; OS share sheet only on tap; no automatic email; code entry via #292 panel; readiness mirror read-only. Extension: first connect by short code, returning paired coach skips it; destination workspace/account shown before Start; paired-to-other-account → stop, offer disconnect/re-pair; checklist Importer available → Connected to TGP → Previous platform ready; capability/version detection; "Use this site"/"Connect this site" gesture per chosen public HTTPS origin only; "Confirm source account" until positive authorized evidence; hard-denied destinations shown as blocked-for-verification; persistent extension-owned task tab + dismissible on-page launcher that receives no tokens/commands from page messages; `action.openPopup` feature-detected only. |
| Tier | T4 both. Why: pairing/session trust, account binding, locator safety, source principal, trusted-message boundary. Promotion: any token/code/email in URL; any local account inference. |
| Owned paths | Mobile: `ImportSetupView.tsx` (#293), `ExtensionPairingPanel.tsx` (#292), `useExtensionPairing.ts`/`extensionPairApi.ts` consumers (#291 owner serializes), `src/utils/safeImportLoginUrl.ts`. Extension: `popup/pair.{html,js}`, `popup/popup.html` readiness panel, new task-page presentation under `popup/`, launcher presentation in `content/` only after EXT-PKG; reads `shared/{session,pairing}.js`; never `background.js`/`shared/protocol.js` (WS1). |
| Entry | S7-2′ frozen + fixtures; G3-AUTH (revocation, attribution, capability negotiation); EXT-PKG for any packaged test; JOURNEY-SPEC handoff/readiness states. |
| Exit | locator returns no owner data/grants no session; lost init retry → same setup, reused/expired code fails safely (scenario 5); mismatch blocks capture (scenario 6); scenarios 3, 4, 7 have distinct states with one remedy; returning coach path shows zero code prompts; launcher cannot inject privileged messages (packaged test). |
| Parallelism | mobile ∥ extension (different repos); ∥ UX-01/02/07; extension serial with UX-04 (extension) on `popup/popup.html`. |
| Code-start gate | S7-2′ + G3-AUTH + `M5-REBASE` (mobile) + EXT-PKG (extension). **Must wait.** Locator threat model and error-state catalog start now. |

### UX-04 — Import Start, Progress & Stop Experience
| Field | Content |
|---|---|
| Proposed PR titles | `UX-04: Import start, progress and stop experience (extension)` · `UX-04: Import start, progress and stop experience (mobile)` |
| Purpose | Extension Ready card "Ready to bring these records into TGP?" with source site/account, destination, read-only promise, one "Start importing"; running panel "Finding your records" / "Bringing your records across" / "Checking everything in TGP" with measured per-family counts and freshness; indeterminate until evidenced denominator, never 100% before reconciliation, stale heartbeat shown stale; "Stop import" on both surfaces without confirmation → "Stopping" / "Stopped on this computer. I am waiting to confirm the server has stopped"; closing UI ≠ cancel; duplicate Start → same run; phone progress view owned, read from one arbiter. |
| Tier | T4 both. Why: one authoritative run, cancellation fencing, terminal truth; UI reads server arbiter only. |
| Owned paths | Extension: `popup/popup.html` run panel + new `popup/run.*` presentation; reads `shared/progress.js`; no engine/worker edits. Mobile: `ImportProgressView.tsx`, `ImportStatusFrame.tsx` (#294 donors), one status-read hook per G3-AUTH transport decision (no second timer owner). |
| Entry | S7-L frozen with fixtures; G3-AUTH transport; UX-03 readiness states. |
| Exit | scenarios 8, 9, 13, 19; zero required coach actions after Start on the success path; offline phone never claims desktop stopped. |
| Parallelism | mobile ∥ extension; ∥ UX-05/06 once S7-L frozen; extension serial with UX-03 (extension) on `popup/popup.html`. |
| Code-start gate | S7-L + G3-AUTH + `M5-REBASE` (mobile) + EXT-PKG (extension). **Must wait** (S7-L is MISSING). Flow design now. |

### UX-05 — Failure, Partial & Recovery Experience
| Field | Content |
|---|---|
| Proposed PR titles | `UX-05: Failure, partial and recovery experience (mobile)` · `UX-05: Failure, partial and recovery experience (extension)` |
| Purpose | "I could not complete this import." with one reason and one safe recovery action; Partial keeps verified records labeled partial; Blocked/Failed/Cancelled/Timed-out distinct; retry links to the prior result and cannot manufacture success or erase the old outcome; legacy extension-minted intents shown as legacy, never promoted; setup-time recovery states (missing/disabled/old/wrong-profile extension, unsupported device, denied origin, revoked permission, login expiry/CAPTCHA) each with exact remedy and retained progress; no blame, no raw error codes, no auto-retry of revoked authorization. |
| Tier | T4 both. Why: truthful terminals and recovery are product safety invariants; no local verdict. |
| Owned paths | Mobile: `ImportResultView.tsx` adverse branches (#294 donor), copy/i18n; Extension: `popup/result.*` adverse presentation. |
| Entry | S7-L terminals + S9 reason-code semantics; UX-04 states. |
| Exit | forced partial (injected 5xx/auth loss) renders partial/failed never complete (mission v1.0 §3.5 item 6); scenarios 10, 14, 18 pass. |
| Parallelism | ∥ UX-04, UX-06. |
| Code-start gate | S7-L + S9 semantics. **Must wait.** Error-state/remedy catalog starts now (feeds JOURNEY-SPEC matrix). |

### UX-06 — Imported Results & Native Deep Links
| Field | Content |
|---|---|
| Proposed PR titles | `UX-06: Imported results and native deep links (mobile)` · `UX-06: Imported results and native deep links — review contract alignment (mobile)` |
| Purpose | "Your import is complete. Your records are ready in TGP." only on server `complete` with native reconciliation; "Open my clients" primary → real roster/client detail refreshed from the native domain by owned native IDs; links fail closed in other accounts; "Review import details" secondary with verified families, coverage dates, observed/staged/created/already-present/rejected/unresolved and reason codes; align `importReviewApi.ts`/`importReview.ts` to the generated schema and retire roster-count-as-result (`useReconstructCounts`, #290 donor); #290 kill switch respected. |
| Tier | Results/deep links PR: T4 (ownership, fail-closed cross-account resolution). Review-contract alignment PR: T2 (generated-contract consumer; promote on any local completion inference). |
| Owned paths | `ImportResultView.tsx` complete branch + actions (#294 donor), `CoachNavigator.tsx` deep-link params (one navigation writer), roster/client detail read paths; `src/api/importReviewApi.ts`, `src/types/importReview.ts`, `src/hooks/useReconstructCounts.ts`, new `ImportReviewDetails` view under `import-journey/`. |
| Entry | S7-REV schema + fixtures (alignment PR); S8 native IDs + S9 manifest (results PR); UX-05. |
| Exit | scenarios 12, 15: counts/dates/native detail/history agree; links work in owning account, fail closed elsewhere; old/new contract tests; "sent ≠ stored" surfaced. |
| Parallelism | alignment PR ∥ UX-04/05; results PR after S8/S9. |
| Code-start gate | alignment: S7-REV + `M5-REBASE`; results: S8 + S9. **Must wait.** Fixture/schema questions go to `CONTRACT_QUESTIONS.md` now. |

### UX-07 — Importer Design System & Accessibility (cross-cutting, starts now)
| Field | Content |
|---|---|
| Proposed PR titles | `UX-07: Importer design system and accessibility (mobile)` · `UX-07: Importer design system and accessibility (extension)` |
| Purpose | Shared primitives on bone/cream/ink/forest tokens, Cormorant/Inter, semantic dark mode; single-column mobile with one headline / one Roman sentence / one CTA; desktop single task panel with identity top, progress center, one action below, diagnostics collapsed; ≥44×44pt targets, visible focus, logical traversal, WCAG AA, dynamic type/200% zoom, reduced-motion parity, polite deduplicated announcements, never color-only; no confetti/bounce/fake typing/loading rituals; shared a11y test suite consumed by UX-02…06. |
| Tier | Mobile: T2 (interaction/accessibility semantics are behavioral). Extension: T1 (HTML/CSS only per mission WS6 split; promote if `popup/*.js` logic must change). |
| Owned paths | Mobile: `importJourneyUI.tsx` (#293 donor), `import-journey/__tests__/*a11y*` (donors #292 a11y test, #294 `ImportStatus.accessibility.test.tsx`); `src/theme/tokens.ts` reuse only, no edits. Extension: `popup/*.html` + CSS only. |
| Entry | JOURNEY-SPEC layout rules; token exclusion list (stone/gold small text). |
| Exit | a11y suite green on every UX surface as each lands; reduced-motion parity snapshots; contrast checks recorded. |
| Parallelism | ∥ everything; only shared file `importJourneyUI.tsx` (UX-02 consumer) → one writer. |
| Code-start gate | JOURNEY-SPEC + `ROMAN-DONOR` + sole writer for `importJourneyUI.tsx`. Does **not** need S7-2′. Design tokens/checklist/test-plan start now, alongside UX-01. |

### UX-08 — End-to-End Journey Usability Proof (converges with S11/S12)
| Field | Content |
|---|---|
| Proposed PR titles | `UX-08: End-to-end journey usability proof — journey tests (mobile)` · `UX-08: End-to-end journey usability proof — packaged-browser journey (extension)` · `UX-08: End-to-end journey usability proof — privacy-safe funnel (mobile)`; usability study and V1 traces are private evidence packets, not product PRs. |
| Purpose | Prove scenarios 1–19 on app + desktop (restart, account switch, handoff, source login, native deep links; no fixture screenshots as live proof); packaged extension on minimum supported Chrome + current stable + S11 second host on the same kernel; privacy-safe funnel offer viewed → import selected → desktop ready → paired → source ready → Start accepted → native complete/incomplete → native review opened with opaque correlation (#291 donor) and low-cardinality reason codes, never PII; V1 traces: TrueCoach + one structurally different authorized platform, zero post-Start actions, ≤300 s, all-partial/all-timeout cannot pass. |
| Owner-provided usability target | Plan "Success metrics": **at least 9 of 10 unfamiliar-coach pilot participants complete authorized setup and find native results without moderator instruction; setup time measured separately**; accessibility: no unresolved blocking keyboard/screen-reader/contrast/large-text issue on any setup, running, result or recovery surface. These are acceptance targets; no observed metric, sample or session exists and none is claimed. |
| Tier | T4 (release-gate evidence G5/G6; PII in funnel; live-account tests need authorization and approved data handling). |
| Owned paths | `src/screens/coach/import-journey/__tests__/**` journey suites; extension `test/**` packaged runs; `src/analytics/events.ts` additions (#291 owner serializes) + one emission helper; private evidence dirs. |
| Entry | UX-01…07 accepted; S11 second host; S12 authorization; privacy-owner scope. |
| Exit | evidence-ladder rows "App/desktop journey", "Packaged-browser", "Human usability/accessibility", "V1 real evidence" filled with pinned matrix, counts, clock, negative controls. |
| Code-start gate | funnel: `M5-REBASE` + privacy scope; journey tests: as surfaces land; packaged/second host: S11; study/V1: S12. Scenario matrix + taxonomy start now. |

### 4.1 Cross-reference to the journey spec (`journey/CANONICAL_MOBILE_JOURNEY_SPEC.md`, read at ~21:02 UTC, 304 lines, in progress)

The journey worker's J-ids/CQ-ids and this map agree on outcome boundaries; the spec owns flow/states/copy, this map owns jobs/PRs/gates. Mapping: UX-01 ← §1/§3/§6/§7 + `STATE_AND_EDGE_CASE_MATRIX.md` + CQ-01…18; UX-02 ← J0, J1, J2, X4; UX-03 ← J3, J4, J5, J6, J13 (disconnect surface; revocation semantics stay G3-AUTH); UX-04 ← J7, J8, J9; UX-05 ← J10 non-complete, X1, E01–E42 negative rows; UX-06 ← J10 complete, J11, J12; UX-07 ← X2, X3, X6; UX-08 ← §8 targets + scenarios 1–19. Two grading requests the spec delegates to this map: (a) **J3 source-selection restyle** (presentation only, no origin/intent binding, `ImportSetupView.tsx` from #293): **T2**, joins the earliest-codeable set with UX-02/UX-07 under the same gates (JOURNEY-SPEC, ROMAN-DONOR, sole mobile UI writer); origin/shortcut binding (CQ-06) remains UX-03 gated on S7-2′; (b) **`ImportDataScreen` reordering built dark** (J4 before source login): allowed only as part of UX-03 (mobile) and not accepted as a journey until J6 has a truth source — consistent with the spec §6. Spec Class C (ii) (#294 body head `f687ee6f` vs observed `5cbf0de3`) matches §2 here: the observed head is the second commit; the body is stale.

## 5. Start-now versus must-wait (maximum parallelism without interrupting data flow)

**Starts now, source-only, no product tree, no heavy slot:** UX-01.design (journey spec — other worker; this map), UX-07 design tokens/a11y checklist/test plan, UX-03 locator threat model + readiness/error-state catalog, UX-05 remedy catalog, UX-06 review-schema fixture questions → `CONTRACT_QUESTIONS.md` for the S7 sole generator owner, UX-08 scenario 1–19 → surface matrix and funnel taxonomy. All flow design proceeds now (owner direction); none touches S5/S6/S7 runtime.

**Earliest codeable without any S7 contract:** UX-02 (offer/entry), UX-07 (primitives, popup CSS), UX-01.state (without intent binding). Open gates even for these: `ROMAN-DONOR`, `M5-REBASE` (for anything on the chain or flag-gated), JOURNEY-SPEC acceptance, an assigned sole mobile UI/navigation writer, and scheduling so mobile Jest/tsc never overlaps a CPU-bound S6/S7 step (mobile repo has no hooks; do not describe invented hook runs). These consume no C1/lifecycle contract, so "no staged consumer before contracts" is respected.

**Must wait for contracts / native writes / readiness:** UX-01 intent binding (S7-2′), UX-03 (S7-2′ + G3-AUTH + EXT-PKG), UX-04 and UX-05 (S7-L, MISSING), UX-06 (S7-REV; S8 + S9), UX-08 packaged/second-host/study/V1 (S11/S12).

## 6. Invariants preserved

NEW SOURCE → CORE DIFF = 0 (no vendor path, badge or copy anywhere in UX); one authoritative import run (no UX surface creates/arbitrates/terminates a run; one arbiter read by both hosts); identity (every screen bound to `import_intent_id` + authenticated owner; no client-supplied coach ID; mismatch stops before capture); no new governance (existing T0–T4, R14 dual attestation, one-writer rule, existing flags; no new review track, service, timer owner or coordination file beyond this evidence directory); reuse over recreation (#289–#294 bytes are inputs, cited and re-based, never re-authored).

## 7. Bradley decision required: **NO**

Canonical documents already fix the material product choices: placement after onboarding at first coach-home entry, skippability, permanent Settings entry, form-of-address rule, read-only billing history, desktop-only executor with graceful phone postponement, Stop without confirmation ritual, truthful terminals, 9/10 usability target. Remaining opens are owner-level design freezes named in the plan (G3 by auth/backend owner; native family models by domain owner; privacy scope by security/privacy owner) or parent dispositions (`ROMAN-DONOR`, `M5-REBASE`, sole generator owner assignment). None is a new Bradley product call and none is created by this map.
