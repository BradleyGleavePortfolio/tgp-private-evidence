# Importer UX dependency DAG (source-only; UX-0N labels are not dependency order)

Worker `plan_importer_ux_lane`, parent EXEC-e7d2385c, 2026-09-23 ~20:58 UTC. Companion to `OFFICIAL_UX_JOB_AND_PR_MAP.md` (vocabulary in its §3). Edges are gates, not schedule dates. S1–S12 are mission phases, not a competing sequence; UX outcomes attach to whichever phase freezes the contract they consume.

## 1. Graph

```text
                     mobile main a5933fd6 ───────┐
  #289 M5-A @22354984 ──► M5-REBASE (#290 ed0342e9 → #291 d2f0d31c → #292 34088677 recomposed onto 22354984)
  #293 P1 003a9774 ─┐                              │
  #294 P2 5cbf0de3 ─┴► ROMAN-DONOR (adopt / re-base / supersede)
                                                   │
  JOURNEY-SPEC (UX-01.design, journey worker) ─────┼──────────────────────────┐
                                                   ▼                          ▼
              ┌──────── UX-07 design system & a11y (mobile T2, extension T1) ─┤  (cross-cutting; starts now)
              │                                    │                          │
              │         UX-02 Roman entry (T2) ◄───┤   UX-01.state account-scoped state (T4)
              │                                    │            │
  S7-1′ compose S3+S5 ─► S7-2′ C1 + forward-2.x regen ──────────┴─► UX-01 intent binding
              │                          │
              │           G3-AUTH freeze ┤ (revocation, attribution, capability, transport)
              │           EXT-PKG (WS1)  ┤
              │                          ▼
              ├──────────────► UX-03 desktop handoff & pairing (mobile T4 ∥ extension T4)
              │                          │
              │      S7-L lifecycle contract (Start/cancel/deadline/terminals/counts; MISSING)
              │                          ▼
              ├──────────────► UX-04 start/progress/stop (extension T4 ∥ mobile T4)
              │                          │
              │      S9 reason codes ────┼─► UX-05 failure/partial/recovery (mobile T4 ∥ extension T4)
              │                          │
              │      S7-REV review schema ─► UX-06 review-contract alignment (T2)
              │      S8 native writers ──┐
              │      S9 reconciliation ──┴─► UX-06 results & native deep links (T4)
              │                          │
              └──────────────► UX-08 journey tests (as surfaces land) ─► packaged/second host (S11) ─► usability study + V1 traces (S12)
                                         ▲
                             privacy-owner scope ─► UX-08 funnel (T4)
```

## 2. Edge table

| From (gate) | To (job) | Kind | Evidence that satisfies |
|---|---|---|---|
| #289 head `22354984` | M5-REBASE | canonical M5 lane | #290–#292 recomposed on `22354984`; #289 final `declaredDependencies` guard passes on composed chain; dual attestation |
| M5-REBASE | UX-01.state, UX-02 flag gating, UX-03 (mobile), UX-04/05 (mobile), UX-06, UX-08 funnel | hard | composed chain accepted |
| #293/#294 | ROMAN-DONOR | parent disposition | written disposition: adopt as donors + re-base onto reconciled chain, or supersede with citation |
| ROMAN-DONOR | UX-02, UX-07, UX-04/05/06 (mobile) presentation | hard for code | disposition recorded |
| JOURNEY-SPEC | UX-01.state, UX-02, UX-03, UX-04, UX-05, UX-06, UX-07, UX-08 | hard for code, soft for design | `journey/*.md` accepted by parent |
| S7-1′ → S7-2′ | UX-01 intent binding, UX-03 | hard | regenerated forward-2.x contract byte-equal drift test; consumer fixtures; `rls-c1-setup` once |
| G3-AUTH | UX-03, UX-04, UX-01 sign-out semantics confirmation | hard | auth-owner freeze record of revocation/attribution/capability/transport |
| EXT-PKG | UX-03 (extension), UX-04 (extension), UX-07 (extension) packaged tests | hard for packaged proof | packaged-extension load test on min Chrome + stable |
| S7-L | UX-04, UX-05, UX-01 run-state consumer types | hard | generated contract + fixtures + old/new compatibility tests |
| S7-REV | UX-06 alignment | hard | single generated review schema; intent-required requests |
| S8 + S9 | UX-06 results/deep links; UX-05 reason codes | hard | owned native IDs in result manifest; reconciliation counts; relationship validation tests |
| UX-07 | every visible UX PR | soft (incremental) | a11y suite runs on each surface as it lands; UX-07 does not block code-start of UX-02 |
| UX-01…07 accepted | UX-08 journey tests | hard | surfaces exist |
| S11 second host | UX-08 packaged/second host | hard | same kernel on ≥2 hosts |
| S12 authorization + privacy scope | UX-08 study/V1/funnel | hard | approved data handling, authorized platform + accounts |

## 3. Critical path (contract-driven, not UX-numbered)

`S7-1′ → S7-2′ → G3-AUTH → S7-L → UX-04/UX-05 → (S8+S9) → UX-06 → UX-08 (S11/S12)`. UX-03 hangs off S7-2′+G3-AUTH and can complete before S7-L. UX-01.state, UX-02 and UX-07 are off the critical path and are the only codeable items before any S7 contract.

## 4. Parallel lanes that never collide

| Lane | Writers | Disjoint paths |
|---|---|---|
| Mobile journey UI | one sole writer | `src/screens/coach/import-journey/**`, one mount each in `CoachHomeScreen.tsx`, `SettingsScreen.tsx`, `CoachNavigator.tsx` |
| Mobile state/pairing (M5 chain owner) | one writer | `src/storage/**`, `src/hooks/useExtensionPairing.ts`, `src/services/authActions.ts`, `src/analytics/events.ts`, `src/api/extensionPairApi.ts` |
| Mobile review contract | one writer | `src/api/importReviewApi.ts`, `src/types/importReview.ts`, `src/hooks/useReconstructCounts.ts` |
| Extension presentation (WS6) | one writer | `popup/*.html`, CSS, new `popup/{run,result,task}.*` presentation |
| Extension logic (WS1, not UX) | one writer | `background.js`, `shared/**`, `content/main.js`, `manifest.json` |
| Backend generator (S7) | sole generator owner (unassigned) | `scripts/importer-contract.ts`, `docs/contracts/importer-openapi.json`, schema |
| Design/spec (source-only) | journey worker + this worker | `execution/e7d2385c/ux-planning/**` |

Serialization points: `popup/popup.html` (UX-03 ext ↔ UX-04 ext), `importJourneyUI.tsx` (UX-07 ↔ UX-02), `authActions.ts`/`events.ts` (#291 owner ↔ UX-01/UX-08), navigation files (single navigation writer). None touches the single heavy runtime slot; mobile Jest/tsc is CPU-bound and must be scheduled around S6/S7 hook/tsc steps.
