# Importer UX dispatch-ready register (proposed; parent dispatches, nothing here is active)

Worker `plan_importer_ux_lane`, parent EXEC-e7d2385c, 2026-09-23 ~20:58 UTC. States: **READY-NOW** = source-only design work dispatchable today without touching product trees, the heavy slot or any S5/S6/S7 lane; **GATED** = implementation waiting on named gates; **INPUT** = existing PR bytes consumed, never re-authored. Requested routes follow the T0–T4 doctrine (T4/T3 → Claude Fable 5 / High per current owner amendment; T2 → Claude Sonnet 5; T1 → GPT-5.6 Terra; T0 → GPT-5.6 Luna); recorded as requested settings, not runtime telemetry. Every T4 item gets two independent exact-head attestations. Mobile repo has no configured hooks; extension main is protected; no remote landing is implied.

## 1. Inputs (existing PRs; reuse, do not recreate)

| PR | Head | Role for UX | Action owner | State |
|---|---|---|---|---|
| #289 M5-A | `22354984` | deterministic install + dependency guard prerequisite | M5 chain builder (T4) | INPUT; dual attestation pending |
| #290 M5-B | `ed0342e9` (base stale `4be69b90`) | flags + review kill switch; `useReconstructCounts` donor | M5 chain builder (T4) | INPUT; needs `M5-REBASE` |
| #291 M5-C/D | `d2f0d31c` | account-scoped pairing mirror, correlation, sign-out | M5 chain builder (T4) | INPUT; needs `M5-REBASE` |
| #292 M5-F | `34088677` | copyable/readable pairing code, a11y test donor | M5 chain builder (T4) | INPUT; needs `M5-REBASE` |
| #293 Roman P1 | `003a9774` | offer card, setup view, copy, `importJourneyUI` primitives | parent `ROMAN-DONOR` disposition; T1 inactive | INPUT; re-base onto reconciled chain when adopted |
| #294 Roman P2 (WIP, halted) | `5cbf0de3` | progress/result/status-frame presentation, adverse terminals | parent `ROMAN-DONOR` disposition; T2 inactive; "do not merge" per body | INPUT; donor only |

## 2. Register

| Job | Outcome | Tier | Requested route | Sole writes (proposed) | Gates | State |
|---|---|---|---|---|---|---|
| UX-01.design journey spec + state/edge matrix + contract questions | UX-01 | T4 cumulative (doc) | Claude Fable 5 / High | `ux-planning/journey/**` (journey worker `specify_mobile_importer_journey_muekv9nz`) | none | **READY-NOW / ACTIVE** |
| UX-01.map (this register + map + DAG) | UX-01 | T4 cumulative (doc) | Claude Fable 5 / High | `ux-planning/{OFFICIAL_UX_JOB_AND_PR_MAP,DEPENDENCY_DAG,DISPATCH_READY_REGISTER}.md`, `MANIFEST.sha256` | none | **COMPLETE (this packet)** |
| UX-07.design tokens exclusion list, a11y checklist, shared test plan, extension popup style spec | UX-07 | T0 (doc) | GPT-5.6 Luna (or bundled with UX-01 route) | new `ux-planning/design-system/**` | JOURNEY-SPEC layout rules (soft) | **READY-NOW** |
| UX-03.design locator threat model + readiness/error-state catalog | UX-03 | T4 (doc, trust boundary) | Claude Fable 5 / High | new `ux-planning/handoff/**` | none | **READY-NOW** |
| UX-05.design remedy catalog (setup + run adverse states) → feeds journey matrix | UX-05 | T0 (doc) | GPT-5.6 Luna | new `ux-planning/recovery/**` | coordinate with journey worker to avoid duplicate matrix | **READY-NOW** |
| UX-06.design review-schema consumer fixture questions | UX-06 | T0 (doc) | GPT-5.6 Luna | append to `ux-planning/journey/CONTRACT_QUESTIONS.md` via journey worker, or `ux-planning/review-contract/**` | S7 sole generator owner assignment (recipient, not gate) | **READY-NOW** |
| UX-08.design scenario 1–19 → surface matrix, funnel taxonomy, 9/10 target definition | UX-08 | T0 (doc) | GPT-5.6 Luna | new `ux-planning/acceptance/**` | none | **READY-NOW** |
| M5-REBASE (canonical, not UX) | input | T4 | Claude Fable 5 / High | isolated mobile worktree; private evidence dir | S6/S7 CPU scheduling; parent activation | **GATED** (parent activation) |
| UX-02 Roman entry (mobile) | UX-02 | T2 | Claude Sonnet 5 | `import-journey/ImportOfferCard.tsx`, copy/i18n, mounts in `CoachHomeScreen.tsx`/`SettingsScreen.tsx`/`CoachNavigator.tsx` | JOURNEY-SPEC, ROMAN-DONOR, sole mobile UI writer; M5-REBASE for flag gating | **GATED** (earliest codeable; no S7 dependency) |
| UX-03 J3 source-selection restyle (presentation only, no binding; `ImportSetupView.tsx` from #293) | UX-03 | T2 | Claude Sonnet 5 | `import-journey/ImportSetupView.tsx` source-selection section | JOURNEY-SPEC, ROMAN-DONOR, sole mobile UI writer; origin/intent binding stays gated S7-2′ | **GATED** (earliest codeable; no S7 dependency) |
| UX-07 design system & a11y (mobile) | UX-07 | T2 | Claude Sonnet 5 | `import-journey/importJourneyUI.tsx`, `__tests__/*a11y*` | JOURNEY-SPEC, ROMAN-DONOR, sole writer for `importJourneyUI.tsx` | **GATED** (earliest codeable; starts with UX-01) |
| UX-07 design system & a11y (extension) | UX-07 | T1 | GPT-5.6 Terra | `popup/*.html`, CSS only | JOURNEY-SPEC; WS6 split honored | **GATED** (earliest codeable) |
| UX-01 account-scoped journey state (mobile) | UX-01 | T4 | Claude Fable 5 / High | `src/storage/importJourneyState.ts`, `authActions.ts` hook (serialize with #291 owner) | M5-REBASE, JOURNEY-SPEC; intent binding waits S7-2′ | **GATED** |
| UX-03 desktop handoff & pairing (mobile) | UX-03 | T4 | Claude Fable 5 / High | `ImportSetupView.tsx`, `ExtensionPairingPanel.tsx`, pairing hook/API consumers, `safeImportLoginUrl.ts` | S7-2′, G3-AUTH, M5-REBASE | **GATED — must wait** |
| UX-03 desktop handoff & pairing (extension) | UX-03 | T4 | Claude Fable 5 / High | `popup/pair.*`, readiness panel, task-page + launcher presentation | S7-2′, G3-AUTH, EXT-PKG, WS1 protocol freeze | **GATED — must wait** |
| UX-04 start/progress/stop (extension) | UX-04 | T4 | Claude Fable 5 / High | `popup/popup.html` run panel, `popup/run.*` | S7-L, G3-AUTH, EXT-PKG | **GATED — must wait (S7-L missing)** |
| UX-04 start/progress/stop (mobile) | UX-04 | T4 | Claude Fable 5 / High | `ImportProgressView.tsx`, `ImportStatusFrame.tsx`, status-read hook | S7-L, G3-AUTH transport, M5-REBASE | **GATED — must wait** |
| UX-05 failure/partial/recovery (mobile) | UX-05 | T4 | Claude Fable 5 / High | `ImportResultView.tsx` adverse branches, copy | S7-L, S9 reason codes | **GATED — must wait** |
| UX-05 failure/partial/recovery (extension) | UX-05 | T4 | Claude Fable 5 / High | `popup/result.*` adverse | S7-L, S9 reason codes, EXT-PKG | **GATED — must wait** |
| UX-06 review-contract alignment (mobile) | UX-06 | T2 | Claude Sonnet 5 | `importReviewApi.ts`, `importReview.ts`, `useReconstructCounts.ts`, `ImportReviewDetails` view | S7-REV, M5-REBASE | **GATED — must wait** |
| UX-06 results & native deep links (mobile) | UX-06 | T4 | Claude Fable 5 / High | `ImportResultView.tsx` complete branch, `CoachNavigator.tsx` deep-link params | S8, S9, UX-05 | **GATED — must wait** |
| UX-08 journey tests (mobile) | UX-08 | T4 | Claude Fable 5 / High | `import-journey/__tests__/**` journey suites | surfaces landed | **GATED** (incremental) |
| UX-08 packaged-browser journey (extension) | UX-08 | T4 | Claude Fable 5 / High | extension `test/**` | EXT-PKG, S11 second host | **GATED** |
| UX-08 privacy-safe funnel (mobile) | UX-08 | T4 | Claude Fable 5 / High | `src/analytics/events.ts` additions + one helper | M5-REBASE, privacy-owner scope | **GATED** |
| UX-08 usability study + V1 traces (evidence) | UX-08 | T4 evidence | independent nonbuilders | private evidence packets | S12 authorization, approved data handling | **GATED** |

## 3. What must not happen in any UX dispatch

No implementation, branch, worktree checkout, install, test run or hook run for READY-NOW items; no consumer code against unfrozen C1/lifecycle/review contracts; no new flags (use #290), no new timer/polling owner, no second token store, no vendor-specific UI, no re-authoring of #289–#294 bytes, no PR creation or remote write, no fabricated PR numbers, no invented usability metrics (9/10 is an owner target with zero observed sessions), no interruption of the S5/S6/S7 heavy slot or CPU-bound hook steps.

## 4. Coordination with the journey worker

Provisional canonical references this register depends on from `journey/*.md`: setup states `created / awaiting_extension / paired / awaiting_source_auth / source_ready / expired`; phases `discovering / transferring / reconciling`; terminals `complete / partial / blocked / failed / cancelled / timed_out`; Roman responses Yes / I am starting fresh / Later; screen names Source selection, Phone continuation, Desktop setup, Source browser, Ready, Running, Verified result, Incomplete result (plan "Screen-by-screen contract"). If the journey spec renames any of these, the spec wins and this register is re-pointed; job boundaries and gates do not change.

Bradley decision required: **NO**.
