# S7-2 C1 on accepted foundation — formatted successor, source READY for dual independent review

Builder `canonical_s7_continuation_map_muei9t11` (sole schema/generator owner for this slice; requested Claude Fable 5 / High, not observed runtime identity). Parent EXEC-e7d2385c authorization 2026-09-23 ~21:36Z: source-only application of the exact prepared 10-file formatter patch; T1 mechanical child, cumulative T4. Static patch/hash work only — no generator, Prisma, tests, hooks, commit, DB, install or network. Heavy runtime was already released 21:35:18Z and was not re-acquired. Original packet `execution/e7d2385c/s7-c1/` is preserved unchanged (`MANIFEST.sha256` = `128496e2cf9d2090ddf69df077c58a09473db7db61cafe348728d5af47b94b43`); this directory is the additive successor.

## 1. Observed timeline of the whole slice (log timestamps, not estimates)

| Step | Observed (UTC) | Evidence |
|---|---|---|
| merge `881c4c79` onto `5c760b77`, two predicted conflicts | 21:28:39 (mtime `s7-c1/logs/01-merge.log`) | `s7-c1/logs/01-*` |
| Prisma client generate (own node_modules), rc 0 | 21:30:51 → 21:30:57 | `s7-c1/logs/04-*` |
| `npm run contract:importer`, rc 0, artifact byte-identical | 21:31:10 → 21:31:39 | `s7-c1/logs/05-*` |
| heavy runtime released | 21:35:18 | `s7-c1/RUNTIME_RELEASE.txt` |
| formatter patch `git apply --index`, rc 0 | 21:36:49 | `logs/03-apply.*` |

(The first READY's "21:27–21:40" range was an estimate written before release; it is left as-is in the preserved packet and superseded by this table.)

## 2. Formatter application (`logs/00`–`04`)

Preconditions verified: HEAD `5c760b77`, MERGE_HEAD `881c4c79`, index tree `b56e984b87dafe4d9c9307f3f92f804995f8fe91`, 0 unstaged/untracked; patch copy sha256 `e6b883070e5b7cdc84d33332cf73ce7d202eab74beecceeee6af3957493d5e08` (== prepared). `git apply --check --index` rc 0 → `git apply --index` rc 0 → `git write-tree` = **`87798e742c7b48f56b05e9b5c30efa877180a9b3` = tree guard, OK**. All 10 formatted index blobs equal the prepared `FMT_BLOBS10.txt` blobs (`logs/06`), which were produced by the pinned Prettier 3.9.6 (`6e922134…`) under the unchanged `.prettierrc.json ee1ad136` and had `--debug-check` rc 0 / `--check` rc 0 / idempotent second write in the original packet. Generator, artifact and `CONTRACT_VERSION = '2.0.0-c1-s1.1'` unchanged (artifact sha256 still `bdb022dd…`; the JSON was not in the formatter set).

## 3. Frozen successor candidate

| Field | Value |
|---|---|
| HEAD | `5c760b774598532e90d5d217e15adc9285c3c3f4` (accepted foundation, tree `7800ecb4`) |
| MERGE_HEAD (retained, uncommitted) | `881c4c791727adef8d423931e1cca83a0ffbb9c9` |
| **Index tree** | **`87798e742c7b48f56b05e9b5c30efa877180a9b3`**; porcelain 18 staged / 0 unstaged / 0 untracked |
| Diff vs HEAD | `c1-formatted-on-foundation-5c760b77.patch` sha256 `a413891afad541414d0313566accfe9e1f7cdcb7dfd1b496b3a77aad0906879b`, 18 files, raw +2050/−81; blobs `INDEX_BLOBS_18.txt` |
| Pre-format state | `STATE_BEFORE_FORMAT.txt` (tree `b56e984b`), original diff in `s7-c1/c1-on-foundation-5c760b77.patch` |
| Config/manifests | unchanged: lefthook `54d03749`, tsconfig `93f3baab`, .prettierrc `ee1ad136`, eslint `78aa2b64`, jest `769a4146`, package.json `656d11a2`, lock `354de3da`, installed record `05bc530a`, own Prisma client d.ts `bf679a16` |
| Hooks | not installed (`.git/hooks/pre-commit` absent, hooksPath unset) — part of the later commit grant |
| Identity | repo-local Bradley Gleave <bradley@bradleytgpcoaching.com>; origin never pushed |

## 4. Actual byte-identity accounting vs PR526 `881c4c79` (`REUSE_AFTER_FORMAT.txt`, `logs/08`)

- **Before formatter:** 14/18 byte-identical (recorded in the original packet).
- **Now, counted:** **5 byte-identical** (`docs/decisions/2026-09-17-c1-durable-paired-intent.md`, both `20270117000000_durable_import_setup/*.sql`, `extension-pair-redeem-contract.spec.ts`, `extension-pair.controller.spec.ts`); **10 formatter-touched** (8 `src/extension-pair/**`, `test/rls-c1-setup.spec.ts`, `test/contracts/importer-contract.spec.ts`); **3 reconciled** (`prisma/schema.prisma` auto-merge `+source_platform String?`; `scripts/importer-contract.ts` version constant + comment; `docs/contracts/importer-openapi.json` version line + T/Q0 cursor hunks) — `residual-vs-pr526-3files.patch` sha256 `5372c69b…`.
- Normalized-text comparison (strip whitespace, `(`, `)`, `,`, `;`, leading `|`) of each of the 10 formatted files against the PR526 blob: 9/10 identical; `test/contracts/importer-contract.spec.ts` differs by exactly one character, the version literal `0`→`1`. So beyond formatting, the entire authored delta vs PR526 is: one schema line inherited from E, the version constant/comment, one literal, and the regenerated artifact.

## 5. Proposed commit message — frozen for parent hash approval

`07-merge-message.r2.txt` sha256 **`288048d7b7e908f8803d3d70e57465f52cfc9f102bb4bc4b1dba30143ce7cb83`**; 0 banned tokens under the repo's commit-msg regex (`logs/09`). Changes vs the first draft (`d3e7c7a3…`, not approved, superseded): states 14/18 identity applied before formatting; gives the actual 5/10/3 split with the named files; identifies the spec as formatter + one literal; replaces "Not a consumer freeze, merge, …" with "Local composition only: not a remote merge, deployment, consumer contract freeze or activation."

## 6. Prepared, NOT run (unchanged from original packet except step 2 is now done)

From `worktrees/s7-c1`, env `NODE_OPTIONS=--max-old-space-size=4096 CHECKPOINT_DISABLE=1 npm_config_offline=true`: (1) `npx --no-install lefthook install`; (2) guard `git write-tree == 87798e74…`; (3) `git commit -F execution/e7d2385c/s7-c1-formatted/07-merge-message.r2.txt` under real pre-commit (prod-readiness-quick, banned-cast-tokens, prettier, eslint, tsc) and commit-msg — expected two-parent commit `HEAD^1=5c760b77`, `HEAD^2=881c4c79`, Bradley author=committer, no trailers; (4) targeted `npx --no-install jest --ci --runInBand test/contracts/importer-contract.spec.ts src/extension-pair/__tests__` (includes the byte-drift check); (5) later, separately granted, one run of `test/rls-c1-setup.spec.ts` on a confirmed disposable PostgreSQL — never E/T-Q0 again; (6) bundle `c23b9d9f..HEAD` + receipt.

## 7. Findings / not claimed

No Class A/B. Class C carried: crude token-multiset script limitation (original packet; not fixed, not needed); first READY's estimated time range (superseded by §1). Review ask for the two independent nonbuilders: complete C1 source (18 files) + integration on the foundation + the formatter diff; S3/S5/S7-1 parents are accepted and not under review. Not claimed: hooks, tsc, lint, tests, commit, real PG, review, merge readiness, activation. No process, lock or runtime held.
