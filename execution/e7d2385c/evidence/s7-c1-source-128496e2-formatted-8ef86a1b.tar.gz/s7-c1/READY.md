# S7-2 C1 on accepted foundation — source READY (composition + generation done; no tests, DB, hooks or commit)

Builder `canonical_s7_continuation_map_muei9t11`, sole schema/generator mutation owner for this slice; parent EXEC-e7d2385c; requested Claude Fable 5 / High (requested setting, not observed runtime identity). Individual/cumulative T4. Executed 2026-09-23 21:27–21:40 UTC. Sole writes: `worktrees/s7-c1/**`, `execution/e7d2385c/s7-c1/**`. Accepted S7/S5/S6 worktrees, stores and dependency trees were read only; nothing pushed, merged, deployed, installed from network or run against a database.

## 1. Inputs (verified before use)

| Input | Identity | Check |
|---|---|---|
| Foundation bundle `s7-foundation-format/s7-foundation-5c760b77…-from-public-c23b9d9f.bundle` | sha256 `3e81299de71ab01afae66bd0188cedd3eb7737135e1e8b52667377b2f0fc8b97`; head `5c760b774598532e90d5d217e15adc9285c3c3f4`, tree `7800ecb4d294a48ed3d7282363265e5f07339f97`, parents `be0ba827`/`98d39610`, 59 commits over `c23b9d9f` | `git bundle verify` ok; == `S7_FOUNDATION_FINAL_ACCEPTANCE.md` |
| PR526 head | `881c4c791727adef8d423931e1cca83a0ffbb9c9` ← `8e25c27b2c92e59e6265e9edcb385eef70c0e588` ← `925780e0` | fetched from origin (depth 3; `.git/shallow` corrected to `c23b9d9f` only so history connects through the bundle); `merge-base(5c760b77, 881c4c79) = 925780e0` |
| Dependency tree | copied `cp -a` from `worktrees/s7-foundation/node_modules` (read-only source) into own `worktrees/s7-c1/node_modules`; installed record `.package-lock.json` sha256 `05bc530a…`; `package.json` blob `656d11a2` and `package-lock.json` blob `354de3da` identical on foundation, PR526 and candidate (`logs/03-manifest-pins.txt`) | no npm ci/install, no network |
| Pinned formatter | existing link `node_modules/.bin/prettier` → S5 tooling `prettier-3.9.6` CLI sha256 `6e922134…` (same binding S3/S5/S7-1 hooks used) | read-only use |

## 2. Composition (`logs/01-*`, `02-*`)

`git checkout --detach 5c760b77` → `git merge --no-commit --no-ff 881c4c79` → **exactly the two predicted conflicts**, both single version lines: `scripts/importer-contract.ts` (`CONTRACT_VERSION '1.4.1'` vs `'2.0.0-c1-s1.0'`) and `docs/contracts/importer-openapi.json` (`info.version`). `prisma/schema.prisma` auto-merged (both `model ImportIntent` and `source_platform String?`). No other conflict, no scope change → no STOP.

Resolution (both via `edit` tool, i.e. manual text edit; no regeneration by hand): `CONTRACT_VERSION = '2.0.0-c1-s1.1'` with a three-line comment naming the two composed lineages; artifact version line likewise; the single existing assertion `test/contracts/importer-contract.spec.ts:432` re-pinned `'2.0.0-c1-s1.0'` → `'2.0.0-c1-s1.1'`. Rationale: smallest forward step on the already-published C1 prerelease lineage that now also carries the 1.4.1 cursor-limit repair; still an unfrozen prerelease.

**Exact reuse** (`logs/02-reuse-check.txt`): 14 of PR526's 18 files have index blobs identical to `881c4c79`. The 4 that differ, and by exactly what (`residual-vs-pr526-4files.patch` sha256 `37f71167…`): `prisma/schema.prisma` +1 line (`source_platform String?`, from E); `scripts/importer-contract.ts` version constant + comment; `test/contracts/importer-contract.spec.ts` one literal; `docs/contracts/importer-openapi.json` version line + the two T/Q0 cursor hunks (`maxLength` 512→8192, descriptions).

## 3. Generation (heavy slot used only here; `logs/04-*`, `05-*`)

1. Prisma client (necessary: C1 adds `ImportIntent`/relation fields the service uses): `env CHECKPOINT_DISABLE=1 PRISMA_HIDE_UPDATE_MESSAGE=1 npm_config_offline=true GIT_NO_LAZY_FETCH=1 node node_modules/prisma/build/index.js generate --schema prisma/schema.prisma` → rc 0, 2.73 s, prisma 6.19.3 / @prisma/client 6.19.3 / engines `debian-openssl-3.0.x` already present (no download observed; run time excludes any fetch). Own `node_modules/.prisma/client/index.d.ts` sha256 `4568250a…` → `bf679a16…` (`ImportIntent` 0 → 1173 occurrences). Written only inside `worktrees/s7-c1/node_modules` — no shared writable client.
2. Contract: `env NODE_OPTIONS=--max-old-space-size=4096 CHECKPOINT_DISABLE=1 npm_config_offline=true npm run contract:importer` (= existing `ts-node scripts/export-importer-contract.ts`) → rc 0, 21:31:10–21:31:39Z, "13 paths, 30 schemas". **Artifact sha256 `bdb022dd6c4fb64cdf291fdde3796b99e4b23004f676b7cb46a58460526ba4e5` before and after generation — generator output is byte-identical to the merge resolution**, so the drift test's byte-equality precondition holds at this tree.

## 4. Frozen candidate

| Field | Value |
|---|---|
| HEAD (unchanged) | `5c760b774598532e90d5d217e15adc9285c3c3f4` |
| MERGE_HEAD (retained, uncommitted) | `881c4c791727adef8d423931e1cca83a0ffbb9c9` |
| **Index/worktree tree** | **`b56e984b87dafe4d9c9307f3f92f804995f8fe91`**; porcelain: 18 staged, 0 unstaged, 0 untracked |
| Diff vs HEAD | `c1-on-foundation-5c760b77.patch` sha256 `f6a31f0a…`, 18 files, raw +1620/−82 (non-test src/prisma/scripts +347/−62); blobs in `INDEX_BLOBS_18.txt` |
| Config/manifests | `lefthook.yml 54d03749`, `tsconfig 93f3baab`, `.prettierrc.json ee1ad136`, `eslint.config.js 78aa2b64`, `jest.config.js 769a4146`, `package.json 656d11a2`, lock `354de3da` — unchanged |
| Identity | repo-local `Bradley Gleave <bradley@bradleytgpcoaching.com>`; `core.abbrev=8`; 1 remote (origin, never pushed); refs `refs/s7/foundation-5c760b77`, `refs/s7/c1-881c4c79` |
| Prepared message | `07-merge-message.txt` sha256 `d3e7c7a3…`, 0 banned tokens under the repo's own commit-msg regex |
| Hooks | NOT installed yet (`.git/hooks/pre-commit` absent, hooksPath unset) — installation is part of the later commit grant |

## 5. Predicted hook outcome and one prepared, NOT applied, correction (`logs/06-*`, `07-*`, `format/`)

Read-only prediction with the pinned Prettier on the 15 staged `ts/json/md` files: **10 files would be refused by the pre-commit `prettier --check`** (all PR526-authored: 8 under `src/extension-pair/**`, `test/contracts/importer-contract.spec.ts`, `test/rls-c1-setup.spec.ts`; list `format/FILES10.txt`). Same pattern as the foundation's 13-file refusal; PR526 CI does not run the repo hook.

Prepared on copies only (candidate index untouched): `format/format-10files.patch` sha256 `e6b883070e5b7cdc84d33332cf73ce7d202eab74beecceeee6af3957493d5e08` (10 files, 790+/359− raw), produced by the pinned Prettier with the repo's unchanged config. Neutrality evidence: `prettier --debug-check` on the originals rc 0 (AST-equal), `--check` after rc 0, second `--write` idempotent; normalized-text identity (strip whitespace, `(`, `)`, `,`, `;`, leading `|`) 10/10 identical. The crude token-multiset script flagged 3 files only because its regex misreads apostrophes inside comments as string delimiters — tokenizer limitation, not a content difference (Class C, recorded). **Predicted tree if the parent approves applying it: `87798e742c7b48f56b05e9b5c30efa877180a9b3`** (`diff-tree` vs `b56e984b` = exactly FILES10; blobs `format/FMT_BLOBS10.txt`). Decision is the parent's; without it the commit attempt is predicted to be refused by the real hook.

## 6. Existing targeted proof and normal hook commands (prepared, NOT run)

From `worktrees/s7-c1`, env `NODE_OPTIONS=--max-old-space-size=4096 CHECKPOINT_DISABLE=1 npm_config_offline=true`:
1. `npx --no-install lefthook install` (true hooks; no bypass, no config change).
2. (only if §5 approved) `git apply --index execution/e7d2385c/s7-c1/format/format-10files.patch` → guard `git write-tree == 87798e74…`.
3. `git commit -F execution/e7d2385c/s7-c1/07-merge-message.txt` — real pre-commit (prod-readiness-quick, banned-cast-tokens, prettier, eslint, tsc) + commit-msg; expected two-parent commit `HEAD^1=5c760b77 HEAD^2=881c4c79`, Bradley author=committer, no trailers.
4. Targeted Jest (existing suites only): `npx --no-install jest --ci --runInBand test/contracts/importer-contract.spec.ts src/extension-pair/__tests__` — includes the drift check (artifact byte-equal to fresh regeneration) and all C1 unit/contract specs.
5. Later, separately granted, exactly once: `test/rls-c1-setup.spec.ts` on an explicitly confirmed disposable PostgreSQL (its own guard; never E/T-Q0 again — S5 fresh51 covers those).
6. Bundle `c23b9d9f..HEAD` and receipt.

## 7. Findings, applicability, not claimed

No Class A/B. Class C: (i) 10-file formatter refusal prediction with prepared neutral correction (§5); (ii) `.git/shallow` correction (origin depth-fetch marked `925780e0` shallow although its parent exists via the bundle; entry removed, `fsck --connectivity-only` clean); (iii) token-multiset script limitation. S3/S5/S7-1 proof applicability is preserved: their bytes are unchanged in this tree except the auto-merged `prisma/schema.prisma` and the 4 shared contract files named above; E/T-Q0 runtime is untouched (`src/scout/**` identical to foundation).

Not claimed: tests, tsc, lint, hooks, commit, real PG, review, merge readiness, consumer freeze, activation. Runtime released with this packet (`RUNTIME_RELEASE.txt`); no process, lock or hold retained.
