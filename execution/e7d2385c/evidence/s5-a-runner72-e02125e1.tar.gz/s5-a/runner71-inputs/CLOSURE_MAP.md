# S5 runner correction — Class B closure map (EXEC-e7d2385c, T4, source-only; nothing executed)

Builder: s5_exact_candidate_continuation (requested Claude Fable 5 / High). Scope: `execution/e7d2385c/s5-runner-correction/**` only. Product/candidate `98d39610`, fixture `3a7d57bf`, helper `g2-pg17-old-root.sh`, launcher `a03836d5`, controls: **unchanged**. `execution/s5-r4/run-proof.sh` still = rev 7 `19ab936a` (not swapped; swap is an activation step after dual review). Only static `bash -n` on the patched copy; no runtime, probe, fault test, install, commit or retry.

## 1. Blocked decision and actual failure (frozen bytes, `frozen-failure/`)
- `run-full-20260923T202133Z.log` (sha256 `0c2d436d…`), `exit-full-…` (`23f6d998…`), `oldroot-…` (`0fde23fe…`), sentinel (`c93ed3c2…`), rev-7 runner (`19ab936a…`), candidate helper copy (`21941c5e…`).
- Sequence: guard child rc 0 → old-root child `bash test/utils/g2-pg17-old-root.sh create` **rc 0**, last stdout line `G2_PG17_OLD_ROOT_OK` → runner `child()` line 264–265 (rev 7): `members="$(group_members "$pid")"` non-empty → `OWNED_GROUP_LEFTOVER pgid=5967 after exit rc=0: 6140 6142 6154 6156 6168 6170 6184 6186 6198 6200` → `terminate_group` → `OWNED_GROUP_REAPED pgid=5967 term_wait=0s` → `rc=3` → `old-root stage failed rc=3; no connection attempted` → `PROOF_EXIT=3 FIRST_RC=3 … SURVIVORS=none QUARANTINE=no`, sentinel `FULL_EXIT=3 OUTER_BOUND=no`.
- The proof never reached init/start/preflight/bootstrap/live; the decision "fresh51 on 98d39610" is blocked by a prerequisite refusal of the evidence runner, not by the candidate.

## 2. Exact cause (from source + logs; pid identities NOT asserted)
Rev-7 `child()` classifies **any** process whose pgrp equals the child's pid in the single `/proc` scan performed immediately after `wait "$pid"` returns, with no grace. What the frozen evidence establishes:
1. The leader (pid 5967, the helper script) had exited normally (`wait` returned 0) after its final statement (`echo G2_PG17_OLD_ROOT_OK`), so every command it waited for had completed.
2. `terminate_group` found the group **already empty on its first re-scan, before any sleep** (`term_wait=0s`) — the members disappeared within the interval between two consecutive `/proc` scans (each scan forks one `cat` per system process, i.e. tens–hundreds of ms). Whether TERM ended them or they ended on their own cannot be distinguished from the log (rev 7 records pids only, no state/cmdline); the patch below records that next time.
3. By construction of bash, the only processes that can remain in an exited script's process group are (a) children bash does not wait for — the helper's three `cmp -s <file> <(git -C "$ROOT" show …)` process substitutions (helper lines 65–68; the sole `<(` construct in the file) — and (b) exit-path/unreaped residue of already-finished commands visible in `/proc` (state Z/X or exiting) until the new parent reaps them. Both classes are transient by nature; neither holds a lock, a database connection or a data directory. A durable daemon (the postmaster) is started later by `pg_ctl` in the `start` stage and its liveness is checked independently (`postmaster.pid`, `lock_exclusive_check`, fixture `stop`), not by this group scan.
4. Ten pids in five pairs is consistent with, but not proof of, (a)+(b); the count includes pid gaps consumed by the runner's own polling (`sleep`, `date`, `cat` per scan). Identity is therefore left open and will be recorded by rev 7.1's `members_detail` output if it recurs.
Conclusion: the refusal is an **immediate-scan race in the runner's survivor rule**, applied to a stage that succeeded. The checkpoint-1 REPORT had listed the runner's group verification as its highest-risk unexecuted assumption; this run executed it and it refused a good stage.

## 3. Minimal closure: external runner patch only (`runner-rev7-to-rev7.1.patch`, 20 added / 4 removed lines)
`run-proof.rev7.1.sh` sha256 **`87b6ac256ed4a910789310491fa0aa9e1f49e590c8ecb1a0802dce97dc06b4bc`**; patch sha256 `e726b063…f6c2`; `bash -n` OK. Changes, all inside the runner:
1. `RUNNER_REV=7` → `7.1` (log attribution: `rev=7.1`, `REV=7.1` in the stamp).
2. New lane constant `DRAIN_BUDGET=5` (seconds) in the substitutable lane block; echoed in the `LANE` stamp line.
3. New helper `members_detail <pid…>` → `pid(state):cmdline` best-effort, for logging only.
4. `child()` after `wait`: if the immediate scan finds members, record them with `members_detail`, then **poll once per second without signalling** until the group is empty or `DRAIN_BUDGET` elapses; log `OWNED_GROUP_DRAIN pgid rc drained_s remaining initial=[…]`. If members remain after the drain, the **unchanged** rev-7 path runs: `OWNED_GROUP_LEFTOVER …` (now with cmdlines), `terminate_group` (TERM → REAP_BUDGET → KILL → survivors), `rc 0 → 3`.
Nothing else changed: offline guard, lock, stamp facts, deadline loop, `OWNED_GROUP_UNVERIFIED` fail-closed path, timeout (124) path, `terminate_group`, `finish`, quarantine, fixture/stop/destroy semantics, preflight, stage order, budgets.

## 4. Contract preservation (what reviewers can check line-by-line)
| Rev-7 guarantee | Rev 7.1 | Where |
|---|---|---|
| Actual child nonzero rc preserved | untouched (`rc=$?` from `wait`; only `rc=0 → 3` on leftover as before) | child() |
| Timeout → 124, group terminated at the deadline | untouched; after a deadline termination the group is already empty so drain is a no-op (0 s) | child() deadline loop |
| One supervisor owns the lock; no second runner | untouched | flock / launcher |
| Final zero-survivor requirement | unchanged: any member still present after ≤5 s → LEFTOVER → TERM/KILL → survivors recorded → `finish` quarantines and forces rc≠0 | child(), terminate_group(), finish() |
| No masking of a real surviving process | the drain **never signals** and never clears anything; a live process (daemon, stuck grandchild) remains a member after 5 s and is treated exactly as in rev 7, now with its cmdline logged | child() |
| Deadlines / launcher bounds | worst case +`DRAIN_BUDGET` per owned child (6 children in `full` → ≤30 s), consumed from the same absolute `DEADLINE`; a drain after the last child can extend the runner tail by ≤5 s inside the launcher's 100 s margin (1740 − 1560 − 80). Launcher unchanged. | lane block |
| Stamp / RECREATE substitutable block | one line added (`DRAIN_BUDGET=5`), recorded in `LANE` | stamp() |
| Password never logged / env hygiene / offline guard literals | untouched | — |

## 5. Why no helper/fixture/candidate change
An external, bounded drain removes the refusal without touching candidate source `98d39610` (the helper is part of the reviewed tree; editing it would move the head and reopen source review). The helper's process substitutions are read-only `git show` pipes; the runner already owns their process group and will still kill and flag them if they do not end within the drain. No alternative is needed. If reviewers instead judge that the runner must not tolerate any post-exit member for any duration, the only alternative that preserves the contract is a helper change replacing `<(git show …)` with a waited temporary-file compare — which is a candidate source change and a new head; not proposed.

## 6. Activation bindings (after the two reviews of the changed runner only)
1. Swap the runner file only: `cp /home/user/workspace/execution/e7d2385c/s5-runner-correction/run-proof.rev7.1.sh /home/user/workspace/execution/s5-r4/run-proof.sh` (mode 0755) → verify sha256 `87b6ac25…b4bc`; fixture `3a7d57bf…`, launcher `a03836d5…` untouched. The launcher records `runner_sha256` at launch and the stamp records `REV=7.1 RUNNER_SHA256=…` — the run is self-attributing.
2. Preconditions (runner-enforced): `/home/user/pg17/clusters/s5` absent (true now), `execution/s5-r4/QUARANTINE` absent (true), lock free, worktree HEAD `98d39610` clean (true).
3. Same command, once: `G2_PG17_PASSWORD=s5_local_synthetic STAGE=full bash /home/user/workspace/execution/s5-r4/launch-full.sh`.
4. **Old-root reuse (no destroy):** `execution/s5-r4/old-root-925780e0` already exists (detached at `925780e0`, 164 migrations, no node_modules, no `.g2-old-client`). The helper's `create` is idempotent: when the path exists with `.git` it skips cloning and runs the same identity gates (HEAD, detached, manifests equal, 164 migrations, byte-identical scout sources, ledger model) — expected output `G2_PG17_OLD_ROOT_OK` again; bootstrap then adds the shared `node_modules` symlink and generates the O client as designed. Reviewer A's C2 qualification applies unchanged.
5. Frozen acceptance = `s5-proof-preparation/readiness/ACTIVATION_AND_EXPECTED_ACCEPTANCE.md` §4 with: stamp `REV=7.1`, `RUNNER_SHA256=87b6ac25…`, `LANE … DRAIN_BUDGET=5`; zero or more `OWNED_GROUP_DRAIN … remaining=none` lines are acceptable and must be attested with their `initial=[…]` identities; any `OWNED_GROUP_LEFTOVER`, `SURVIVORS≠none` or `QUARANTINE=yes` remains a FAIL.
6. Preserve the failed run's logs (`*20260923T202133Z*`) in place; the new run has its own TS.

## 7. Not done
No execution of any stage, no probe of the drain, no fault injection, no install, no commit, no change under `execution/s5-r4/`, `worktrees/s5-r4/`, `/home/user/pg17/`.
