# S5 independent A — rev 7.1 finding

## S5-A-R71-B01 — B — new natural-drain wait drops the owned-group handle before cleanup can use it

**Exact code:** `run-proof.rev7.1.sh:266-279` waits for the leader, stores its status, clears `OWNED_PGID=""` at 267, then may spend five polling intervals waiting for known group members to finish; `on_signal():228-239` and `finish():304-317` terminate/check a group only through that now-empty handle. ([frozen rev 7.1](runner71-inputs/run-proof.rev7.1.sh))

**Reachable harm / proof invalidation:** while the new natural-drain loop still has a nonempty `members` list, an already-supported TERM/INT/HUP interruption invokes `on_signal`, which skips `terminate_group` because `OWNED_PGID` is empty and calls `finish`. `finish` likewise skips owned-group cleanup, can record `SURVIVORS=none QUARANTINE=no`, and releases the lock although that group's descendants were never terminated or rechecked. The result is nonzero for the signal, but its claimed ownership/zero-survivor release is untrustworthy and a later lane can overlap work that was still running. ([signal, drain and finish implementations](runner71-inputs/run-proof.rev7.1.sh))

This consequence uses the runner's existing cancellation contract and the newly introduced deliberate wait, not a hypothetical new control requirement; the original instantaneous post-wait scan is not being broadly reopened.

**Decision blocked:** only activation of this corrected evidence runner; product head `98d39610`, fixture, helper and substantive test acceptance remain untouched.

**Minimum closure:** retain `OWNED_PGID="$pid"` through member diagnostics, natural drain and any existing leftover TERM/KILL path; move the clear to after the group is empty or termination has completed/recorded survivors. The existing signal and `finish` handlers then already have the needed group identity—no new manager or framework.

**Execution unlocked:** inspect that exact small follow-up delta, then immediately the existing one-shot fresh `full` execution when the parent releases runtime ownership; reuse the pinned O checkout, no destroy and no new control/fault test.

**Counts:** A=0; B=1; C qualifications are in `RUNNER71_REPORT.md`. No candidate/source or runtime mutation by this reviewer.
