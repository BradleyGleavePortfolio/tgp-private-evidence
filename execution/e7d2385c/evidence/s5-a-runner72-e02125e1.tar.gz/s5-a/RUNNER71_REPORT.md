# S5 independent A — rev 7.1 narrow runner review

**Verdict: NOT GRANTABLE as written; one concrete B finding, S5-A-R71-B01. Minimum closure is to keep `OWNED_PGID` live across the newly added natural-drain interval and clear it only after that group is verified empty or the existing termination path has completed. No product, fixture, helper, launcher, test or control change is requested.** ([finding](RUNNER71_FINDINGS.md), [exact runner](runner71-inputs/run-proof.rev7.1.sh))

Independent nonbuilder A; T4 individual/cumulative; static changed-runner review only, no peer conclusions or runtime. Existing source/head, failed attempt and accepted prior scopes are not re-audited.

## Exact binding

Packet manifest `4b77082ed98ba22435d4e159100f42b1b99cea913ad0122a6f8b2bee53fd2abd` verifies **9/9** entries; reviewed runner SHA-256 `87b6ac256ed4a910789310491fa0aa9e1f49e590c8ecb1a0802dce97dc06b4bc`, patch SHA-256 `e726b0634d8c107659a9006a89fc28a7c4b591a1c7f47a2503cf23a02d37f6c2`. ([verification](runner71-evidence/packet-manifest-check.txt), [independent hashes](runner71-evidence/independent-pins.txt))

Actual source remains clean HEAD `98d39610f511505558373f3a59fa019804c94bd7`, tree `67fc1db5f353f0d363fe7134a78d455c0decfb55`; original helper/runner copies compare equal, fixture and launcher pins are unchanged, and active runner is still rev 7—not swapped. ([independent bindings](runner71-evidence/independent-pins.txt))

## Preserved and weakened behavior

- The correction reasonably permits natural exit before declaring a leftover: five poll/sleep iterations under the same canonical lock, then the existing nonzero conversion and TERM/KILL/survivor/quarantine path. Child nonzero statuses are not turned into zero, and existing timeout detection still returns 124. ([runner lines 260–284, 304–322](runner71-inputs/run-proof.rev7.1.sh))
- **Ownership is not preserved during the new grace interval:** line 267 clears the only global group handle before lines 275–279 observe/wait on members; the already-supported TERM/INT/HUP handler at 228–239 then sees no owned group and proceeds to final cleanup/release without terminating or checking that group. This is the exact new delayed boundary requiring one-line lifecycle correction, not an invented fault framework. ([runner](runner71-inputs/run-proof.rev7.1.sh), [finding](RUNNER71_FINDINGS.md))
- The old-root reuse proposal is appropriate: its existing `create` path verifies the same detached O checkout and immutable source/dependency/migration pins rather than adopting arbitrary state; no destroy is needed. ([unchanged old-root helper](inputs/source/test/utils/g2-pg17-old-root.sh), [activation proposal](runner71-inputs/CLOSURE_MAP.md))

## C — record, qualify, continue

The prior ten PID identities remain unknown; the receipt cannot establish that they were necessarily transient helper/exit residue or that the initial refusal was definitively a harmless race. That attribution is not needed to justify trying a bounded natural drain, and no diagnosis control is requested. ([prior actual attestation](PART3_ACTUAL_RESULT.md), [builder causal claims](runner71-inputs/CLOSURE_MAP.md))

`DRAIN_BUDGET=5` bounds five one-second sleeps, not precisely five wall-clock seconds including `/proc` scans/diagnostics; the unchanged outer bound remains the last backstop. This precision qualification alone creates no fixer or test cycle. ([new loop](runner71-inputs/run-proof.rev7.1.sh), [unchanged launcher](inputs/runner/launch-full.sh))

## Execution unlocked by minimum closure

After the single ownership-lifetime correction is frozen and this narrow delta is reviewed, permit the same one-shot `full` activation with the pinned existing O checkout and unchanged candidate/fixture/launcher, preserving first-attempt failure and new attempt attribution. No runtime was performed and no fresh51 acceptance exists.
