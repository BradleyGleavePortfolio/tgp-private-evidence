# S5 independent A — rev 7.2 tiny-delta closure

**GRANTABLE: S5-A-R71-B01 CLOSED. No new A/B finding. Authorize the existing one-shot `full` execution when the parent transfers the free runtime slot; no candidate/fixture/helper/launcher change, new control, fault test or source re-audit is required.** ([exact delta](runner72-inputs/runner-rev7.1-to-rev7.2.patch), [ownership trace](runner72-inputs/run-proof.rev7.2.sh))

Independent nonbuilder A, T4 individual/cumulative, parent-model inheritance without asserted runtime identity. Static delta/pin review only; no peer current conclusions, candidate edit, runner swap or runtime execution.

## Exact inputs

| Item | SHA-256 / identity |
|---|---|
| Packet manifest | `6c51404ca35d32ec8932721b005e7b747a88c1bc1f6c579d913dd8be780751d0` |
| **Reviewed rev 7.2 runner** | **`16c763f408544529ca4a11b40d61a57bc61e5e0c07023091b70253b541b9a73a`** |
| Rev 7.1→7.2 delta | `fe4b20c59cc23b3b276ce6c9e942c110eae7885c5ac57845145bec1931c785ad` |
| Cumulative rev 7→7.2 patch | `069e4c774ae8c33c302912728cd453b0d74085fc2bbac9e1cb8feeaae3bedbdc` |
| Unchanged candidate | HEAD `98d39610f511505558373f3a59fa019804c94bd7`; tree `67fc1db5f353f0d363fe7134a78d455c0decfb55` |

All **6/6** packet entries verify; the supplied predecessor matches this review's frozen rev 7.1, source is clean, fixture/helper/launcher hashes remain unchanged, and active runner is still `19ab936a…` pending authorized swap. ([independent pins](runner72-evidence/independent-pins.txt), [packet verification](runner72-evidence/packet-manifest-check.txt))

## Why the finding is closed

The sole semantic delta moves `OWNED_PGID=""` from immediately after `wait` to line **284**, after natural drain and any existing leftover termination; revision-label/comments are the only accompanying changes. ([tiny patch](runner72-inputs/runner-rev7.1-to-rev7.2.patch))

During the new grace interval, `OWNED_PGID` now still names the child's verified group: existing TERM/INT/HUP handling at 228–239 can terminate/recheck it, and `finish` retains its survivor/quarantine handling under the held lock; normal flow clears the handle only once the group is empty or termination has recorded survivors. Child nonzero status, timeout return 124, deadline logic and leftover rc0→3 conversion are unchanged. ([rev 7.2 lines 228–287 and 307–324](runner72-inputs/run-proof.rev7.2.sh))

That closes the concrete ownership gap without weakening the zero-survivor decision or adding a new mechanism.

## Execution binding and remaining truth

The executor may swap only the runner to the exact SHA above, then use the unchanged launcher for one `STAGE=full` attempt on head `98d39610`; the existing detached O checkout is reverified by the unchanged helper rather than destroyed/recreated. Expected stamp becomes `REV=7.2`, the reviewed runner SHA and `DRAIN_BUDGET=5`; substantive acceptance remains the same real 51-case result and raw first/final/stop/sentinel outcomes. ([activation proposal](runner72-inputs/CLOSURE_MAP_R2.md), [original actual-source grant](ACTIVATION_ATTESTATION.md))

Prior C qualifications remain: five sleep iterations are not an exact five-second wall-clock cap including scans; failed-attempt PID identities remain unknown; expected O-root/bootstrap artifacts do not constitute unintended npm-root drift. None creates another cycle. ([rev 7.1 qualifications](RUNNER71_REPORT.md), [prior actual failure](PART3_ACTUAL_RESULT.md), [activation qualification](ACTIVATION_ATTESTATION.md))

The first failed run remains failed, and neither rev 7.1 nor rev 7.2 has produced fresh51 evidence in this review. Append the next actual result here; **no 51-case or all-evidence final acceptance is claimed**. ([preserved failure](PART3_ACTUAL_RESULT.md))
