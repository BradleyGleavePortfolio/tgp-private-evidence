# S5 fresh51 `full` — actual result receipt (EXEC-e7d2385c, T4): **PROOF_EXIT=3 at the old-root stage; no database was created, no cluster initialised, no live case ran. NOT a pass. NOT retried.**

Executor s5_exact_candidate_continuation (requested Claude Fable 5 / High). Authority `S5_FRESH51_ACTIVATION.md`; runtime transferred by parent after S6 release 20:19:59Z; launched once 20:21:33Z; runner terminal 20:21:49Z; slot released (RUNTIME_RELEASE.txt). No edit, install, control, retry, resume, reset, destroy, or product/private remote write.

## 1. Launch identity (as executed)
- Pre-launch re-read 20:21:33Z (`PRELAUNCH.txt`): HEAD `98d39610`, porcelain 0, runner/fixture/launcher `19ab936a`/`3a7d57bf`/`a03836d5`, data dir + QUARANTINE absent, canonical lock probe free, fd holders 0.
- Command exactly: `G2_PG17_PASSWORD=s5_local_synthetic STAGE=full bash /home/user/workspace/execution/s5-r4/launch-full.sh` → `launched: pid=5298 sentinel=…/full-20260923T202133Z.sentinel` (`LAUNCH.stdout`, launcher rc 0).
- Runner stamp (`env-full-20260923T202133Z.log`): `RUNNER_SHA256=19ab936a… FIXTURE_SHA256=3a7d57bf…`, lane constants as archived, `HEAD=98d39610f511505558373f3a59fa019804c94bd7 TREE=67fc1db5f353f0d363fe7134a78d455c0decfb55 CLEAN=yes DIRTY_FINGERPRINT=none`, `PACKAGE_LOCK_BLOB=354de3da… NODE_MODULES_PACKAGE_LOCK_SHA256=05bc530a…`, `PG_DIST … postgres_sha256=23cd1748… version=postgres (PostgreSQL) 17.6`, `PROVENANCE result=success`, `DATA_DIRECTORY_STATE=absent`, psql 18.6. **Exact expected stamp.**
- `OFFLINE_GUARD_OK stage=full rev=7`; `LOCK_HELD /home/user/workspace/execution/test-validation.lock … pid=5305 deadline=20:47:33Z`.

## 2. Actual stage results (raw child statuses, verbatim in `RESULT_SUMMARY.txt`)
| stage | child | raw | outcome |
|---|---|---|---|
| guard | `./node_modules/.bin/jest test/scout/g2-pg17-db-guard.spec.ts` (20:21:34–20:21:45Z) | **rc=0** | `Tests: 27 passed, 27 total`, `Test Suites: 1 passed` |
| oldroot | `bash test/utils/g2-pg17-old-root.sh create` (20:21:45–20:21:49Z) | child **rc=0**, printed `old_root=…/old-root-925780e0 head=925780e0… detached=yes migrations=164 alternates=none` and `G2_PG17_OLD_ROOT_OK` — then runner: `OWNED_GROUP_LEFTOVER pgid=5967 after exit rc=0: 6140 6142 6154 6156 6168 6170 6184 6186 6198 6200`, `OWNED_GROUP_REAPED pgid=5967 term_wait=0s`, `END … rc=3 timed_out=0` | **runner converted 0 → 3** (rev-7 rule: a group member alive after the child's exit is a survivor, not a pass) |
| init/start/preflight/bootstrap/live/stop | — | not reached | `old-root stage failed rc=3; no connection attempted` |

Exit record: `PROOF_EXIT=3 FIRST_RC=3 STAGE=full STOP_RC=na DAEMON=none SURVIVORS=none SIGNALLED=none CLEANUP_SECONDS=0 QUARANTINE=no START=20:21:33Z END=20:21:49Z`. Sentinel: `FULL_EXIT=3 OUTER_BOUND=no END=2026-09-23T20:21:49Z pid=5298`. Lock log: `HOLDER=s5-r4 … pid=5305` / `RELEASE=s5-r4 stage=full first_rc=3 rc=3 stop_rc=na daemon=none survivors=none cleanup_s=0`. Frozen acceptance §4 items 1, 2, 7, 8, 9: **NOT met** (3 ≠ 0; no fixture/bootstrap/live logs exist). Items 3 (stamp), 5 (guard PASS), 6 (`G2_PG17_OLD_ROOT_OK`), 10 (source unchanged) met.

## 3. Observation on the failing check (attribution offered for reviewers; no fix applied)
The ten leftover pids are five pairs, each 2 apart, and were gone within the same second (`term_wait=0s`, no survivors, no quarantine). The old-root helper's last verification loop runs `cmp -s <file> <(git -C "$ROOT" show …)` (process substitution) for three files, plus other `$(...)`/pipeline children, and bash does not wait for process-substitution children before the script exits; the runner's `group_members` scan runs immediately after `wait`, so still-exiting grandchildren in the group were counted. This is the rev-7 A-02 survivor rule firing on transient, already-terminating processes of a stage that itself succeeded — an evidence-harness refusal, not a product, source, PG or dependency failure. checkpoint-1 REPORT listed the runner's group verification as an unexecuted assumption; this run executed it. Whether the minimum correction is on the runner (bounded grace/re-scan before declaring a leftover) or on the helper (avoid `<(...)`), and whether that requires re-review, is a parent decision; I did not change either file. Class: concrete blocked boundary (a real result that must be attested as observed), not a pass; not retried.

## 4. State left in place (POSTRUN_IDENTITY.txt, 20:23:09Z)
- Source unchanged: HEAD `98d39610`, tree `67fc1db5`, porcelain 0, hooks `pre-commit`/`commit-msg` real, `node_modules/.package-lock.json` `05bc530a…`, spec `2b7d1969…`.
- Expected creation (reviewer A C2): `execution/s5-r4/old-root-925780e0` exists — detached at `925780e0`, 164 migrations, no `node_modules` link yet, no `.g2-old-client` (bootstrap never ran); its `package.json`/`package-lock.json` (lock sha256 `b7fed5ed…9c55` = candidate lock) are the only npm-root fact changes; `/home/user/node_modules` (11038 files, pre-existing platform tree, not ours) identical before/after; all other roots absent before and after.
- Fixture: `/home/user/pg17/clusters` **never created** (init not reached); no postmaster, no listener on 54325, no postgres process. Nothing to retain or destroy.
- Runner: launcher pid 5298 and runner pid 5305 gone; leftover pids 6140–6200 all gone; lock fd holders 0; `QUARANTINE` absent; sealed continuation and preparation manifests re-verify OK.
- Logs left in place under `execution/s5-r4/logs/` (env/run/exit/guard-unit/oldroot/launcher/pid/sentinel for TS 20260923T202133Z) and `execution/test-validation.lock.log`; sha256+bytes of each listed in `RESULT_SUMMARY.txt`.

## 5. Not done / not claimed
No 51-case live result exists; no bootstrap; no PG17.6 cluster identity proof (preflight not reached). No retry/resume/reset/destroy. No product acceptance. Runtime slot released after the runner's own terminal record; `RUNTIME_RELEASE.txt`.
