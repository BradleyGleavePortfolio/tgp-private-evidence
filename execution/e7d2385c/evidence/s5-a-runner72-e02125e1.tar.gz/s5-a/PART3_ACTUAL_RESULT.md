# S5 independent A — Part 3: actual first fresh51 attempt

**Actual verdict: FAILED / INCOMPLETE, not accepted. `PROOF_EXIT=3`, `FIRST_RC=3`, `FULL_EXIT=3`; no database/cluster initialization, bootstrap or live 51-case execution was reached. The source/hooked-head review remains unchanged, but the first grant is consumed and provides no fresh51 acceptance.** ([runner terminal record](part3-inputs/logs/exit-full-20260923T202133Z.log), [launcher sentinel](part3-inputs/logs/full-20260923T202133Z.sentinel), [stage boundary](part3-inputs/logs/run-full-20260923T202133Z.log))

Independent nonbuilder A; T4 individual/cumulative. This is an additive actual-result attestation in the existing review, not a new source audit. No runtime, installation, census, candidate edit, retry or control was performed by this reviewer.

## Exact evidence and what actually ran

Attempt `20260923T202133Z`, packet manifest `537abdd9c2410ab5e7c3cc942bfdcfe56fcea74bc5e1c44f021958d481e424f9`: **10/10 manifested packet files verify**; attributable execution logs are preserved separately in this review's Part 3 seal. ([packet verification](part3-evidence/attempt-manifest-check.txt), [packet manifest](part3-inputs/MANIFEST.sha256))

The actual runner stamped clean HEAD `98d39610f511505558373f3a59fa019804c94bd7`, tree `67fc1db5f353f0d363fe7134a78d455c0decfb55`, runner `19ab936a…`, fixture `3a7d57bf…`, installed lock `05bc530a…`, PostgreSQL 17.6 binary `23cd1748…` and fresh data-directory absence. This matches the reviewed candidate and activation—not a different source or inherited old resume result. ([actual stamp](part3-inputs/logs/env-full-20260923T202133Z.log), [activation binding](ACTIVATION_ATTESTATION.md))

| Stage | Actual attributable result |
|---|---|
| Guard | **27/27 passed**, child raw 0, timed_out=0; valid narrow guard evidence only. |
| Old-root helper | Printed detached O `925780e0a1906593e5383c618311b6b17364b8dc`, 164 migrations and `G2_PG17_OLD_ROOT_OK`; runner records child rc=0 before its leftover rule. |
| Old-root supervision | Immediate group scan reported ten PIDs; runner logged `OWNED_GROUP_LEFTOVER`, then `OWNED_GROUP_REAPED … term_wait=0s` and converted the stage result to **3**. |
| Init/start/preflight/bootstrap/live/stop | **Not reached**; `STOP_RC=na`, not a successful real stop. |

These statuses are from the [guard log](part3-inputs/logs/guard-unit-20260923T202133Z.log), [old-root log](part3-inputs/logs/oldroot-20260923T202133Z.log) and [raw runner sequence, lines 42–49](part3-inputs/logs/run-full-20260923T202133Z.log).

## Failure attribution: facts versus conjecture

The observed failing boundary is the immediate post-child `group_members`/leftover conversion, not an observed product, migration or PostgreSQL failure; the runner then refused to proceed. ([actual run lines 44–49](part3-inputs/logs/run-full-20260923T202133Z.log), [reviewed runner lines 261–268](inputs/runner/run-proof.sh))

**The ten PID identities were not recorded.** Their numeric spacing and immediate disappearance do not establish that they were process-substitution children, zombies, already exiting, scanner helpers or any other particular process class; the executor's proposed explanation is a hypothesis, not this review's finding. ([raw leftover record](part3-inputs/logs/run-full-20260923T202133Z.log), [executor interpretation, section 3](part3-inputs/RECEIPT.md))

The terminal record reports no surviving owned group, daemon or quarantine, and the attributable post-run record reports unchanged source/hooks/dependencies, no cluster directory/listener/postmaster, all named PIDs gone and no lock holders. These observations establish the recorded stopped boundary; I did not repeat a census. ([terminal](part3-inputs/logs/exit-full-20260923T202133Z.log), [post-run identity](part3-inputs/POSTRUN_IDENTITY.txt), [release](part3-inputs/RUNTIME_RELEASE.txt))

## Disposition and next boundary

- Preserve the failed attempt and its true statuses permanently; no relabeling as pass, silent retry or claim that 51 cases ran.
- Retain the applicable exact-source, authentic-hook and narrow guard evidence; do not reopen unchanged head `98d39610`, fixture bytes or accepted S1–S4.
- The parent has assigned an external-runner-only minimum correction. Await its READY pins, review only the changed runner against this attributable failure, then decide the existing execution boundary; no new controls/fault tests or speculative framework requirement is introduced here.
- Actual fresh51 acceptance remains **missing** and must be appended after a later authorized real run with its own exact runner/source binding and terminal cleanup evidence.

Original source seal `be4cc108…` and activation seal `f321ced8…` remain preserved; this Part 3 records failure, not final acceptance. ([original manifest](MANIFEST.sha256), [activation manifest](ACTIVATION_MANIFEST.sha256))
