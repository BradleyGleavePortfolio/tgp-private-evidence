# S5 runner correction r2 — closure of S5-A-R71-B01 (ownership retention across the drain wait); source-only, nothing executed

Builder s5_exact_candidate_continuation (requested Claude Fable 5 / High), T4. Isolated packet `execution/e7d2385c/s5-runner-correction-r2/**`. Rev 7.1 packet (`s5-runner-correction/`, runner `87b6ac25…`) and reviewer A's seal are untouched; reviewer B's current conclusion was not read. No runtime, fault test, swap, install, commit. `execution/s5-r4/run-proof.sh` remains rev 7 `19ab936a`. Product `98d39610`, fixture, helper, launcher, controls, timers, budgets, protocol: unchanged.

## Finding closed (A, verbatim scope)
Rev 7.1 cleared `OWNED_PGID=""` immediately after `wait` (line 267) and then could spend up to `DRAIN_BUDGET` seconds polling a still non-empty group; a TERM/INT/HUP in that window made `on_signal()` skip `terminate_group` and `finish()` skip owned-group cleanup, so a release with `SURVIVORS=none QUARANTINE=no` could be recorded over an untreated group.

## Single move (`runner-rev7.1-to-rev7.2.patch`, sha256 `fe4b20c5…85ad`; +5/−2 lines, of which 3 are comment lines and 1 is the `RUNNER_REV` label)
- Removed: `OWNED_PGID=""` right after `wait "$pid"` (rev 7.1 line 267).
- Added: `OWNED_PGID=""` immediately after the leftover block (new line 284), i.e. after the group is observed empty **or** `terminate_group` has completed and recorded survivors, and before the `END` record.
- Label: `RUNNER_REV=7.1` → `7.2` so the stamp/`rev=` lines attribute the run to the new bytes (the launcher also records `runner_sha256`).
- Three comment lines explaining the retention.
Everything else is byte-identical to rev 7.1 (DRAIN_BUDGET=5, members_detail, drain loop, leftover path, deadline loop, terminate_group, on_signal, finish, quarantine).

New full runner: **`run-proof.rev7.2.sh` sha256 `16c763f408544529ca4a11b40d61a57bc61e5e0c07023091b70253b541b9a73a`** (0755, `bash -n` OK). Cumulative vs rev 7 (`19ab936a`): `runner-rev7-to-rev7.2.cumulative.patch` (`069e4c77…`, +24/−5).

## Ownership trace after the move (all `OWNED_PGID` assignments in rev 7.2)
| line | statement | meaning |
|---|---|---|
| 204 | `OWNED_PGID=""` | initial |
| 234 | `OWNED_PGID=""` in `on_signal` after its own `terminate_group "$OWNED_PGID"` | unchanged |
| 260 | `OWNED_PGID="$pid"` once the child's group id is verified | unchanged |
| **284** | `OWNED_PGID=""` after drain / leftover termination, before `END` | **moved here** |
| 312 | `finish`: `if [ -n "$OWNED_PGID" ]; then terminate_group … ; OWNED_PGID=""; fi` | unchanged |

Consequences, case by case (existing handlers, no new code path):
1. Signal during the polling loop before the child exits — as rev 7: `on_signal` → `terminate_group "$pid"` → `finish`.
2. Signal during the **drain** (child exited rc r, group non-empty) — new: `OWNED_PGID` = `$pid`, so `on_signal` runs `terminate_group "$pid"` (TERM → REAP_BUDGET → KILL → survivors recorded) and then `finish`, which quarantines on survivors and forces rc≠0; the lock is held until that record is written. Closes B01.
3. Signal during the leftover `terminate_group` itself — `on_signal` calls `terminate_group` again on the same group (idempotent: kill on an empty/absent group fails silently; members scan authoritative); `finish` follows. Same as rev 7's behaviour when signalled inside `terminate_group`.
4. Normal exit with empty group — drain skipped, line 284 clears, `END` recorded; `finish` sees `OWNED_PGID=""` exactly as in rev 7.
5. Deadline timeout — `terminate_group` at line 263 empties the group; `wait`; drain is a no-op; line 284 clears; return 124. Unchanged outcome.
6. `OWNED_GROUP_UNVERIFIED` path returns before line 260 — unchanged.
No timer/budget/protocol change: `WORK_BUDGET/REAP_BUDGET/STOP_BUDGET/DRAIN_BUDGET`, launcher bounds, lock, stamp format (other than `REV=7.2`) untouched.

## Activation bindings (after dual review of the changed bytes only)
1. `cp /home/user/workspace/execution/e7d2385c/s5-runner-correction-r2/run-proof.rev7.2.sh /home/user/workspace/execution/s5-r4/run-proof.sh` (0755); verify sha256 `16c763f4…9a73a`; fixture `3a7d57bf…` and launcher `a03836d5…` untouched.
2. Preconditions (runner-enforced, currently true): `/home/user/pg17/clusters/s5` absent, `execution/s5-r4/QUARANTINE` absent, lock free, worktree HEAD `98d39610` clean.
3. Once, when the parent transfers the slot: `G2_PG17_PASSWORD=s5_local_synthetic STAGE=full bash /home/user/workspace/execution/s5-r4/launch-full.sh`.
4. Reuse pinned O checkout `execution/s5-r4/old-root-925780e0` (helper `create` is idempotent on an existing detached checkout; no destroy).
5. Acceptance = `s5-proof-preparation/readiness/ACTIVATION_AND_EXPECTED_ACCEPTANCE.md` §4 with stamp `REV=7.2`, `RUNNER_SHA256=16c763f4…`, `LANE … DRAIN_BUDGET=5`; `OWNED_GROUP_DRAIN … remaining=none` lines acceptable (attest `initial=[…]` identities); any `OWNED_GROUP_LEFTOVER`, `SURVIVORS≠none`, `QUARANTINE=yes` or nonzero `PROOF_EXIT/FIRST_RC/STOP_RC` remains FAIL. Failed rev-7 run logs `*20260923T202133Z*` stay in place.
