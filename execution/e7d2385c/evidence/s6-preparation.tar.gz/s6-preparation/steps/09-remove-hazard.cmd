set -e; TESTDIR=src/services/__tests__
for f in persistedQueryCache.hazardControls.test.tsx persistedQueryCache.hazardAdapter.tsx; do [ "$(sha256sum $TESTDIR/$f | cut -d' ' -f1)" = "$(sha256sum $HZ/$f | cut -d' ' -f1)" ] || { echo "RETAINED $f: bytes differ from frozen source"; exit 4; }; rm -f "$TESTDIR/$f"; echo "copy $f removed (hash-guarded, equal to frozen source)"; done
[ "$(git status --porcelain --untracked-files=all | wc -l)" = 9 ]; [ "$(ctree)" = 845d83ad5731f86b34bfca2ca67142c98498165f ]; git status --porcelain
