node node_modules/typescript/bin/tsc --noEmit
