taskset -c 0,1 node node_modules/jest/bin/jest.js src/__tests__/rootNavigatorPersistedCacheGate.test.tsx --ci --runInBand --verbose
