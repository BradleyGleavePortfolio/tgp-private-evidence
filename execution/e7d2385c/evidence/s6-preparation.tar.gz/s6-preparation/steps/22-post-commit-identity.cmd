source $P/steps/chk.sh
git log -1 --format='%H%n%T%n%P%n%an <%ae>%n%cn <%ce>%n%B' | tee $O/identity.txt
eq "%T tree" 845d83ad5731f86b34bfca2ca67142c98498165f "$(git log -1 --format=%T)"
eq "%P parent" d51a191098f483cea9abec6cc7e9f3beffd18c06 "$(git log -1 --format=%P)"
eq "author" "Bradley Gleave <bradley@bradleytgpcoaching.com>" "$(git log -1 --format='%an <%ae>')"
eq "committer" "Bradley Gleave <bradley@bradleytgpcoaching.com>" "$(git log -1 --format='%cn <%ce>')"
eq "trailers" "" "$(git log -1 --format='%(trailers)')"
eq "message == authored file" "$(cat $P/steps/21-commit-message.txt)" "$(git log -1 --format=%B)"
eq "porcelain lines" 0 "$(git status --porcelain --untracked-files=all | wc -l)"
eq "banned-token grep count in commit object" 0 "$(git cat-file -p HEAD | grep -c -iE 'co-authored|generated with|claude|anthropic|openai|perplexity')"
eq "detached HEAD" detached "$(git symbolic-ref -q HEAD >/dev/null && echo branch || echo detached)"
eq "diff-tree parent..HEAD = nine exact blobs" $':100644 100644 bac96bb7ac5a867183713693b04550e3bef34536 55bf758e6c4f1997425640049853a92382c76c38 M\tApp.tsx\n:000000 100644 0000000000000000000000000000000000000000 536f57dce2b6dc9bf2bba7eec2821d6c9541ada0 A\tsrc/__tests__/rootNavigatorPersistedCacheGate.test.tsx\n:100644 100644 3b5217da709c25bd52dad3b0c37f6a6661e7f358 b028ba5e08a058f008dde2f9a52b1c852542ac78 M\tsrc/navigation/RootNavigator.tsx\n:000000 100644 0000000000000000000000000000000000000000 f732a69e939fb0ffd07821b7fe9db372df99b3fb A\tsrc/services/PersistedQueryCacheGate.tsx\n:000000 100644 0000000000000000000000000000000000000000 250f642369b4b628507128d800002b218028d878 A\tsrc/services/__tests__/persistedQueryCache.identityGate.test.tsx\n:100644 100644 8377a44dda7c2aa067f49c0fa0d897d092aafff1 49477d3d947d5488c2eaf3b3dcc8518d5f5a8d76 M\tsrc/services/__tests__/queryClient.persister.test.ts\n:100644 100644 82ee02088be36d25ff7f3afcb1e5896e5008f633 7ce86111b05fd2cd2461f92591c69f117f2c34c5 M\tsrc/services/__tests__/queryClient.signout.test.ts\n:100644 100644 386a78022c9af0303bd76c31ffa417e4506bc959 15cba04a72abf2e737642777294828209c637c6d M\tsrc/services/authActions.ts\n:100644 100644 8a3f2820fe94b1cc6ea8bde1a58d1060a5271e89 acd80dbe080d0f1afbd77228b430c5b144652ef6 M\tsrc/services/queryClient.ts' "$(git diff-tree -r --abbrev=40 HEAD^ HEAD)"
eq "numstat" $'16\t35\tApp.tsx\n192\t0\tsrc/__tests__/rootNavigatorPersistedCacheGate.test.tsx\n32\t0\tsrc/navigation/RootNavigator.tsx\n152\t0\tsrc/services/PersistedQueryCacheGate.tsx\n486\t0\tsrc/services/__tests__/persistedQueryCache.identityGate.test.tsx\n15\t3\tsrc/services/__tests__/queryClient.persister.test.ts\n47\t0\tsrc/services/__tests__/queryClient.signout.test.ts\n10\t2\tsrc/services/authActions.ts\n295\t49\tsrc/services/queryClient.ts' "$(git diff-tree -r --numstat HEAD^ HEAD)"
eq "refs unchanged" $'a5933fd6de5616493de75f0db907098b149b955c commit\trefs/heads/main\nd51a191098f483cea9abec6cc7e9f3beffd18c06 commit\trefs/restored/execute/20260921-s6-r3' "$(git for-each-ref)"
eq "package-lock unchanged" 840be0b8d5f4ed8272afd20290c8ebf6f6dacc394e6edae4ae5403e9fabe6b69 "$(sha256sum package-lock.json | cut -c1-64)"
echo "HEAD=$(git rev-parse HEAD) commit_object_sha256=$(git cat-file -p HEAD | sha256sum | cut -d' ' -f1) gpgsig=$(git cat-file -p HEAD | grep -c '^gpgsig') committer_ts=$(git log -1 --format=%ct)"
exit $FAIL
