mkdir -p $O/bundle && B=$O/bundle/s6-p1-hooked-$(git rev-parse --short=8 HEAD)-from-public-a5933fd6.bundle
git bundle create "$B" a5933fd6de5616493de75f0db907098b149b955c..HEAD && git bundle verify "$B" && git bundle list-heads "$B" && sha256sum "$B"
