set -e; test ! -e $O/.started && touch $O/.started
[ "$(git rev-parse HEAD)" = d51a191098f483cea9abec6cc7e9f3beffd18c06 ]; [ "$(git rev-parse HEAD^{tree})" = 62bf67b88e0f123f1a23ee34a1a75cb43029d9fb ]
[ "$(ctree)" = 845d83ad5731f86b34bfca2ca67142c98498165f ]
[ "$(git status --porcelain --untracked-files=all | sort | tr '\n' ';')" = " M App.tsx; M src/navigation/RootNavigator.tsx; M src/services/__tests__/queryClient.persister.test.ts; M src/services/__tests__/queryClient.signout.test.ts; M src/services/authActions.ts; M src/services/queryClient.ts;?? src/__tests__/rootNavigatorPersistedCacheGate.test.tsx;?? src/services/PersistedQueryCacheGate.tsx;?? src/services/__tests__/persistedQueryCache.identityGate.test.tsx;" ]
[ "$(git diff --cached --name-only | wc -l)" = 0 ]   # index still at HEAD
[ "$(sha256sum package-lock.json | cut -c1-64)" = 840be0b8d5f4ed8272afd20290c8ebf6f6dacc394e6edae4ae5403e9fabe6b69 ]; [ "$(sha256sum package.json | cut -c1-64)" = 63e2e2e2327b5a305fd184c0737ff4eea91f2283e8aa5d313041bffbdf130d5f ]
(cd /home/user/workspace/execution/e7d2385c/s6-inputs/2026-09-23/6c2a68ac/s6-p1-product-build && sha256sum -c --quiet MANIFEST.sha256 && [ "$(sha256sum MANIFEST.sha256 | cut -c1-64)" = 698cf631a421c8835928912aa0e180917a95be88e2672ac5f61878db63c71808 ])
for f in App.tsx src/navigation/RootNavigator.tsx src/services/__tests__/queryClient.persister.test.ts src/services/__tests__/queryClient.signout.test.ts src/services/authActions.ts src/services/queryClient.ts src/services/PersistedQueryCacheGate.tsx src/services/__tests__/persistedQueryCache.identityGate.test.tsx src/__tests__/rootNavigatorPersistedCacheGate.test.tsx; do cmp -s "$f" /home/user/workspace/execution/e7d2385c/s6-inputs/2026-09-23/6c2a68ac/s6-p1-product-build/candidate/$f || { echo "candidate byte drift: $f"; exit 92; }; done
[ "$(sha256sum $HZ/persistedQueryCache.hazardControls.test.tsx | cut -c1-64)" = a91bb732716b500122e291714bf437872cb81930c020812042f84ed87f6a184d ]; [ "$(sha256sum $HZ/persistedQueryCache.hazardAdapter.tsx | cut -c1-64)" = 3796be8fae738993bcc5c30dd7d4cf9b303329b8faa990ca03e31c2460cd35f3 ]
test ! -e src/services/__tests__/persistedQueryCache.hazardControls.test.tsx; test ! -e src/services/__tests__/persistedQueryCache.hazardAdapter.tsx
test -d node_modules; test -f node_modules/jest/bin/jest.js; test -f node_modules/typescript/bin/tsc; test -f node_modules/jest-expo/package.json
[ "$(ls .git/hooks | grep -vc '\.sample$')" = 0 ]; [ -z "$(git config --get core.hooksPath)" ]; [ -z "$(git config --local --get user.name)" ]
test ! -e /home/user/package.json; test ! -e $O/QUARANTINE; env | grep -E '^(S5X_|LEFTHOOK|HUSKY)' && exit 94 || true
git for-each-ref; git log -1 --format='%H %an <%ae> %cn <%ce>'; ls -A node_modules | wc -l; echo PINS_OK
