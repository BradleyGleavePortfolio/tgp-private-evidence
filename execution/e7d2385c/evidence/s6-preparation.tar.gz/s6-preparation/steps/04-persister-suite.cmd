taskset -c 0,1 node node_modules/jest/bin/jest.js src/services/__tests__/queryClient.persister.test.ts --ci --runInBand --verbose
