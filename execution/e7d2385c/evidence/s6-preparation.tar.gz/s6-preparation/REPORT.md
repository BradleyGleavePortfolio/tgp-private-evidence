# S6 frozen-source recovery + validation preparation — REPORT (EXEC-e7d2385c, sealed 2026-09-23T19:50Z)

Role: S6 source recovery/validation preparer (requested Claude Fable 5 / High; runtime identity not observable). Not an auditor; no P1 product byte changed. Intake private `cc62002bfd08c3cb677025b651965d36e6a1aaec`. Sole writes: `worktrees/s6-diagnostic` (new), `execution/e7d2385c/s6-preparation/**`, `execution/e7d2385c/s6-inputs/**` (immutable publication, all files chmod a-w). Parent private checkout `repos/tgp-private-evidence` read only (`ls-tree` for blob ids, no lazy fetch); no credential output. Reviewer outputs not read.

## 1. Recovered (exact; logs R1–R7)
- 82 frozen blobs fetched via `gh api …/git/blobs/<sha>` raw, each `git hash-object` == tree id (44 + 38, 0 failures). Published under `s6-inputs/<original private path>`: s6-r3 checkpoint-1 bundle + SHA256SUMS; `s6-p1-product-build/**` (16); `op88/s6-c6-prep/**` (20); `s6-restore/**` (6); selected `s6-exclusion-v1`, `s6-setup-result`, `s6-c6-result`, `s5-hooked-candidate-prep`, `s6-p1-staging-1` files.
- Pins verified: bundle `c0ad2994…` = checkpoint SHA256SUMS; P1 `MANIFEST.sha256` sha256 **`698cf631…`**, 15/15 OK; patch **`20c6594c…`**; C6 prep manifest `04d761f0…` 19/19, c6 subset 11/11; hazard **`a91bb732…`**, adapter **`3796be8f…`**, runner `746e244d…`, observer `f140787a…`, classifier `2715cf11…`, instrument `cf470101…`; s6-restore manifest OK.
- Baseline: public main still `a5933fd6`; depth-1 clone into `worktrees/s6-diagnostic`, origin removed (0 remotes), bundle verified and fetched offline, `checkout --force --detach` → HEAD **`d51a191098f483cea9abec6cc7e9f3beffd18c06`**, tree **`62bf67b88e0f123f1a23ee34a1a75cb43029d9fb`**, parent `55db31a0…`, 15 commits from a5933fd6, porcelain 0, 1090 = 1090, fsck ok, lock `840be0b8…`, hooks 0, `node_modules` absent — every identity equals archived s6-restore M1.
- Candidate: `git apply` of the frozen patch into the working tree only (index sha unchanged before/after); nine files byte-identical to `candidate/**` and manifest; porcelain = PINS_FINAL's nine lines. Derived candidate tree **`845d83ad5731f86b34bfca2ca67142c98498165f`** via scratch index; `diff-tree` = exactly nine paths with the patch's blob ids; re-derived per-file patch sections byte-identical to the frozen patch, frozen order reproduces `20c6594c…`. Early pins published in `READY_PINS.md`.

## 2. Preparation output
`S6_VALIDATION_PREPARATION.md` (setup needs, incompatibilities, 14-step bounded command list with raw/postcheck expectations, hook/identity route, stop rules, write set, privacy), `steps/**` (derived, unexecuted, unparsed), `diffs/` (step.sh vs S5; proposed setup-runner candidate-pin binding), `INPUTS.sha256`, `MANIFEST.sha256` (non-self-including).

## 3. Dispositions (owner Safety-ROI classes)
- **C (record/continue)** — `.git/index` sha differs from the builder's `4b37d9b7…` (stat data of a fresh checkout); tree identical. No consequence.
- **C** — mobile repo has no hook policy at d51/a5933fd6; "true-hooked commit" = normal `git commit` with no hooks; no hook can write source; no installation proposed. CI is push/PR-only. Recorded in §3 of the preparation.
- **C** — accepted S6 setup and C6 compositions each carry clean-tree gates (and the C6 runner a six-pass expectation) incompatible with the dirty candidate worktree; minimum choice and a 23-line constant-binding diff are reported, not applied. No new mechanism built.
- **B-class execution prerequisite, not a product defect** — `node_modules` absent in this fresh sandbox: one `npm ci` on the unchanged lock is required before any step; distinct from the accepted setup695558f8 evidence. Blocks only the proof; unlocked by the S5 slot release + parent activation.
- No A finding raised here (not an audit). Any P2 successor changes the candidate tree: steps 00/20–22 pins must be re-derived for that tree; steps 01–09 are reusable as written.

## 4. Not done / not claimed
No install, node/npm/jest/tsc/eslint/formatter, hook, commit, lock creation/probe, signal, process change, DB, remote write, product edit, private-checkout write, or reading of reviewer findings. `worktrees/s5-r4` untouched. Success here proves exact source bytes and exact pins only.
