#!/usr/bin/env bash
# Retrieval helper (retrieval only): fetch named frozen blobs from private commit cc62002b via gh api raw blob endpoint,
# verify each fetched file's git blob id equals the tree's blob id. No credential output.
set -u
COMMIT=cc62002bfd08c3cb677025b651965d36e6a1aaec
REPO=BradleyGleavePortfolio/tgp-private-evidence
SRC=/home/user/workspace/repos/tgp-private-evidence
DST=/home/user/workspace/execution/e7d2385c/s6-inputs
export GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1
ok=0; bad=0
while IFS= read -r path; do
  [ -z "$path" ] && continue
  line=$(git -C "$SRC" ls-tree "$COMMIT" -- "$path")
  mode=$(awk '{print $1}' <<<"$line"); sha=$(awk '{print $3}' <<<"$line")
  if [ -z "$sha" ]; then echo "MISSING-IN-TREE $path"; bad=$((bad+1)); continue; fi
  out="$DST/$path"; mkdir -p "$(dirname "$out")"
  if [ -e "$out" ]; then echo "EXISTS-SKIP $path"; continue; fi
  gh api -H 'Accept: application/vnd.github.raw+json' "repos/$REPO/git/blobs/$sha" > "$out.part" 2>"$out.err"
  rc=$?
  got=$(git hash-object "$out.part")
  if [ $rc -eq 0 ] && [ "$got" = "$sha" ]; then
    mv "$out.part" "$out"; rm -f "$out.err"
    [ "$mode" = "100755" ] && chmod 755 "$out" || chmod 644 "$out"
    echo "OK $mode $sha $path"; ok=$((ok+1))
  else
    echo "FAIL rc=$rc want=$sha got=$got $path"; bad=$((bad+1)); rm -f "$out.part"
  fi
done
echo "SUMMARY ok=$ok bad=$bad"
