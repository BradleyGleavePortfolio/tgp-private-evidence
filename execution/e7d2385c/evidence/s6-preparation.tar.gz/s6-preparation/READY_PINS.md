# S6 READY PINS — baseline + exact frozen candidate restored (EXEC-e7d2385c, S6 preparer)

Published early for independent reviewers. Recorded 2026-09-23T19:39Z. Source-only: no install/npm/node/tsc/Jest/formatter/hook/commit/DB/runtime/lock/process change. Retrieval + static git/hash/diff only.

## Intake
- Private evidence commit: `cc62002bfd08c3cb677025b651965d36e6a1aaec` (parent checkout `/home/user/workspace/repos/tgp-private-evidence`, partial/sparse, read-only, not written).
- Frozen inputs fetched blob-by-blob via `gh api .../git/blobs/<sha>` (raw), each verified `git hash-object == tree blob id` (44/44 OK, log `logs/R1-fetch-frozen-1.txt`). Published read-only under `/home/user/workspace/execution/e7d2385c/s6-inputs/<original private path>`.

## Baseline worktree — `/home/user/workspace/worktrees/s6-diagnostic`
| Fact | Value |
|---|---|
| Public baseline | `git ls-remote main` = `a5933fd6de5616493de75f0db907098b149b955c` (unchanged since archived run); `clone --depth 1 --no-tags`; origin removed → 0 remotes |
| Bundle | `s6-inputs/2026-09-21/remediation/s6-r3/checkpoint-1/s6-r3.bundle` sha256 `c0ad2994f899775bd821029b62c1c492991bf1ddf1ab184ec0a88a9d7e439662` (= checkpoint SHA256SUMS), `git bundle verify` okay, fetched offline to `refs/restored/execute/20260921-s6-r3` |
| HEAD (detached) | **`d51a191098f483cea9abec6cc7e9f3beffd18c06`** |
| HEAD tree | **`62bf67b88e0f123f1a23ee34a1a75cb43029d9fb`** |
| Parent | `55db31a0696ebd07d0cb9abb18ffd31dce29457d`; a5933fd6 is ancestor; 15 commits base..HEAD; shallow at a5933fd6 |
| Clean state at restore | porcelain 0 (`--untracked-files=all`), 1090 tracked = 1090 files, diff-index clean, fsck connectivity rc=0 |
| package-lock.json | blob `6c56385d33db5fa703f8dc37a78381b8e2ba89a1`, sha256 `840be0b8d5f4ed8272afd20290c8ebf6f6dacc394e6edae4ae5403e9fabe6b69` |
| package.json | sha256 `63e2e2e2327b5a305fd184c0737ff4eea91f2283e8aa5d313041bffbdf130d5f` |
| Refs | `refs/heads/main`=a5933fd6, `refs/restored/execute/20260921-s6-r3`=d51a1910 (2 refs) |
| Hooks / modules | 0 active hooks, `core.hooksPath` unset; `node_modules` ABSENT; `dist` ABSENT |
| Identity | HEAD author/committer `Bradley Gleave <bradley@bradleytgpcoaching.com>` |

Every value equals archived `2026-09-23/6c2a68ac/s6-restore/REPORT.md` §1 row 2 (log `logs/R4-restore-worktrees-s6-diagnostic.txt`).

## Candidate packet — `s6-inputs/2026-09-23/6c2a68ac/s6-p1-product-build/`
| Fact | Value |
|---|---|
| `MANIFEST.sha256` sha256 | **`698cf631a421c8835928912aa0e180917a95be88e2672ac5f61878db63c71808`**, 15 entries, `sha256sum -c` 15/15 OK, non-self-including |
| `p1-product.patch` sha256 | **`20c6594c200d38c9946f4f62d2c778f634bcacbe26b430b05e8291cc5f571cbd`**, 1562 lines, exactly nine paths |

## Candidate restored in the worktree (working tree only; `.git/index`, HEAD, refs, config untouched)
`git apply --check` ok; `git apply` of the frozen patch. Porcelain = exactly the nine PINS_FINAL lines (6 ` M`, 3 `??`). All nine worktree files byte-identical (sha256) to `candidate/**` and to the manifest (log `logs/R5-restore-candidate-patch.txt`).

| Path | Pre-image blob (HEAD) | Candidate blob | Candidate sha256 |
|---|---|---|---|
| `App.tsx` | `bac96bb7ac5a867183713693b04550e3bef34536` | `55bf758e6c4f1997425640049853a92382c76c38` | `123162b2d38626038d043accc8aed50615828296016c7e825825efd5631d8408` |
| `src/navigation/RootNavigator.tsx` | `3b5217da709c25bd52dad3b0c37f6a6661e7f358` | `b028ba5e08a058f008dde2f9a52b1c852542ac78` | `dd70665e0debeffc6dc3f66e20798c8b24252185d71c06d6c643b1b3acc9db2a` |
| `src/services/__tests__/queryClient.persister.test.ts` | `8377a44dda7c2aa067f49c0fa0d897d092aafff1` | `49477d3d947d5488c2eaf3b3dcc8518d5f5a8d76` | `ee59e4dee2e55b6908fe2071c373cc6636bca280153eb751b111fe05b222e521` |
| `src/services/__tests__/queryClient.signout.test.ts` | `82ee02088be36d25ff7f3afcb1e5896e5008f633` | `7ce86111b05fd2cd2461f92591c69f117f2c34c5` | `ebeb78146697d7a88fa4b745bb46d471cc7de69d535fff120b14efd005995266` |
| `src/services/authActions.ts` | `386a78022c9af0303bd76c31ffa417e4506bc959` | `15cba04a72abf2e737642777294828209c637c6d` | `b7e0b7d5d7ca056b9b6d422a73e3ab15a9032a45ab33dfb792caf1a0c2485ec7` |
| `src/services/queryClient.ts` | `8a3f2820fe94b1cc6ea8bde1a58d1060a5271e89` | `acd80dbe080d0f1afbd77228b430c5b144652ef6` | `1c38d0fd50a79ca7f9e5baac79389fc148d9f3f607a89fd6ea9ccd137896ad66` |
| `src/services/PersistedQueryCacheGate.tsx` (new) | — | `f732a69e939fb0ffd07821b7fe9db372df99b3fb` | `7325287f82065afd393b7f1da6e69751919d8204858b094eac3102504e1590a0` |
| `src/services/__tests__/persistedQueryCache.identityGate.test.tsx` (new) | — | `250f642369b4b628507128d800002b218028d878` | `44031dcb7eabc0889d64932e4dd825e9544d0f2ca44a398eda6dc5791f0872d5` |
| `src/__tests__/rootNavigatorPersistedCacheGate.test.tsx` (new) | — | `536f57dce2b6dc9bf2bba7eec2821d6c9541ada0` | `b1ed2f46943df458547f07a9a6989e1ea70ea0c6db3d0f81a647eacd671e7e9d` |

**Derived candidate tree (scratch index only, real index untouched): `845d83ad5731f86b34bfca2ca67142c98498165f`.** `git diff-tree -r 62bf67b8…  845d83ad…` = exactly the nine paths above (log `logs/R6-derive-candidate-tree.txt`). Re-deriving the patch from the two trees gives nine `diff --git` sections each byte-identical to the frozen patch's; concatenated in the frozen order the sha256 is again `20c6594c…` (log `logs/R7-patch-section-compare.txt`).

## Frozen hazard inputs (NOT placed in the worktree)
- `s6-inputs/2026-09-22/op88/remediation/s6-c6-prep/c6/inputs/persistedQueryCache.hazardControls.test.tsx` sha256 **`a91bb732716b500122e291714bf437872cb81930c020812042f84ed87f6a184d`**
- `s6-inputs/2026-09-22/op88/remediation/s6-c6-prep/c6/inputs/persistedQueryCache.hazardAdapter.tsx` sha256 **`3796be8fae738993bcc5c30dd7d4cf9b303329b8faa990ca03e31c2460cd35f3`**
- C6 prep packet `MANIFEST.sha256` sha256 `04d761f0421cfbdc99058bbbcf9c5ad4d420a76ae45b258c33c0ed0e925709a6`, 19/19 OK; `c6/MANIFEST.c6.sha256` 11/11 OK; runner `run-c6-hazard-v5-conly.sh` `746e244d…`.

## Recorded, not acted on (C)
- `.git/index` sha256 here is `a51133754658048a271e4dd4437b4736c7af103f6bd4f8e0a2c0aada481002ab`, not the builder's `4b37d9b7…`: the index carries per-checkout stat data; the tree it describes is identical (`62bf67b8…`, diff-index clean before apply, unchanged by `git apply`). No consequence for candidate bytes.
- `node_modules` ABSENT in this fresh sandbox (builder's run had 699 entries). Any validation needs a new-environment minimum setup — see `S6_VALIDATION_PREPARATION.md` (not a repeat of accepted C6/setup evidence).
- Reviewers may read the worktree and `s6-inputs/**` read-only; do not run anything in it.
