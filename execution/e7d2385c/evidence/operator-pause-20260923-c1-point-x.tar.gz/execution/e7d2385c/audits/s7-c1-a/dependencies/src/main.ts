import 'reflect-metadata';
// IMPORTANT: instrument.ts must be imported before any other application
// module so Sentry's auto-instrumentation can patch the runtime. Do not
// reorder these lines.
import './instrument';
import { NestFactory } from '@nestjs/core';
import { Logger, ValidationPipe } from '@nestjs/common';
import helmet from 'helmet';
import { AppModule } from './app.module';
import { ThrottlerExceptionFilter } from './filters/throttler-exception.filter';
import { HttpExceptionFilter } from './filters/http-exception.filter';
import { assertEnv } from './common/env-validation';
import { computeCorsAllowedOrigins } from './common/cors-origins';
import { setupSwagger } from './common/openapi';
import { CacheControlInterceptor } from './common/cache-control.interceptor';
import { MetricsService } from './observability/metrics.service';
import { promHttpMiddleware } from './observability/prom-metrics';
import { LANDING_PUBLIC_PREFIX_EXCLUDE } from './landing-pages/public-route-prefix';
import { featureFlagNotFoundMiddleware } from './common/feature-flag/feature-flag-not-found.middleware';
import { reportProcessError } from './observability/process-errors';

async function bootstrap() {
  // Fail fast at boot if required env vars are missing. See
  // src/common/env-validation.ts for the full rule set; in production /
  // staging the prod-tier rules also throw, while dev only enforces hard
  // rules and warns about the rest.
  assertEnv();
  const app = await NestFactory.create(AppModule, {
    // Capture raw request bodies so the Stripe webhook controller can verify
    // HMAC signatures over the exact byte sequence Stripe signed. Nest's
    // express adapter exposes this via `bodyParser: false` + manual parsing,
    // but the simpler `rawBody: true` flag is supported on Nest 11 and adds
    // `req.rawBody` to every request without disabling JSON parsing.
    rawBody: true,
  });

  // OBSERVABILITY (H3): register the prom-client duration middleware FIRST —
  // ahead of helmet/CORS/validation/auth — so its timer spans the full request
  // lifecycle (incl. short-circuited or 401/403 responses). It only reads the
  // `finish` event and never mutates the request, so this ordering is safe.
  app.use(promHttpMiddleware());

  // SECURITY (audit E-1): register helmet before any routes so every response
  // carries sensible defaults — HSTS, frameguard (X-Frame-Options: SAMEORIGIN),
  // X-Content-Type-Options: nosniff, Referrer-Policy, X-DNS-Prefetch-Control,
  // etc. CSP is disabled because this is a JSON API consumed by mobile and a
  // future browser console; the default helmet CSP is HTML-oriented and would
  // not block any meaningful attack vector for our JSON responses.
  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginResourcePolicy: { policy: 'cross-origin' },
    }),
  );

  // OPS (audit M-4): forward SIGTERM/SIGINT to module lifecycle hooks so
  // PrismaService.onModuleDestroy() (which calls $disconnect()) actually
  // runs on Fly redeploys. Without this, in-flight requests are killed
  // mid-flight when Fly sends SIGTERM. PrismaService already implements
  // OnModuleDestroy → $disconnect (see src/prisma.service.ts).
  app.enableShutdownHooks();

  // SECURITY: CORS was previously `origin: '*'` (audit C6). Deny-all
  // allow-list by default; the origin math (CORS_ORIGINS parsing, wildcard
  // rejection, R43 storefront auto-include) lives in
  // src/common/cors-origins.ts — shared with featureFlagNotFoundMiddleware
  // so the dark-route 404's CORS echo uses the exact same allow-list.
  const corsOrigins = computeCorsAllowedOrigins(new Logger('bootstrap'));

  // R-DARK-1: feature-flag route gate. Registered as raw express middleware so
  // it runs BEFORE the entire Nest guard chain (guards resolve after all
  // express middleware). A route whose flag is OFF returns a uniform 404 —
  // identical to an unmounted route — so an unauth/wrong-role caller cannot
  // distinguish "flag off" from "route does not exist" (no 401/403 leak).
  //
  // Round-2 hardening: positioned BEFORE enableCors so a browser preflight
  // OPTIONS on a dark route hits the 404 gate instead of being answered 204
  // by the cors package — R-DARK-1 covers ALL methods, OPTIONS included. The
  // middleware emits its own Access-Control-Allow-Origin echo against the
  // same allow-list (computeCorsAllowedOrigin) so allow-listed browser
  // clients can still read the 404 body. Still after promHttpMiddleware +
  // helmet (full-lifecycle metrics, security headers on every response) and
  // before useGlobalPipes/guards, exactly as the ruling requires.
  app.use(featureFlagNotFoundMiddleware);

  app.enableCors({
    origin: corsOrigins.length > 0 ? corsOrigins : false,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Idempotency-Key', 'X-Recent-Auth-Token'],
    // Coach console BFF reads the Supabase access token from a cookie/header
    // depending on how the console is hosted; allow credentials so the
    // browser will actually send them when the origin is in the allow-list.
    credentials: true,
  });

  // Global validation pipe using class-validator
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  // Global exception filters. Order matters: the LAST filter registered runs
  // FIRST for a given exception type, and Nest picks the most-specific @Catch()
  // first regardless of registration order. ThrottlerExceptionFilter stays as a
  // specific @Catch(ThrottlerException); HttpExceptionFilter is the catch-all
  // with @Catch() that normalizes every other HttpException into
  // { statusCode, message, error, timestamp, path }.
  // HttpExceptionFilter forwards 5xx (server) errors to Sentry internally;
  // 4xx are deliberately not sent to avoid noise from validation failures.
  // ThrottlerExceptionFilter receives MetricsService from the DI container
  // so each 429 increments `throttler_rejected_total`. MetricsService is
  // resolved at module init time; if observability is not wired (tests),
  // the filter falls back to logging-only.
  const metrics = app.get(MetricsService, { strict: false });
  app.useGlobalFilters(new HttpExceptionFilter(), new ThrottlerExceptionFilter(metrics));

  // Global Cache-Control interceptor — adds `private, max-age=60` to safe
  // GET responses, `no-store` to /auth/*, /messaging/*, /admin/*, /health*,
  // /.well-known/*. See src/common/cache-control.interceptor.ts.
  app.useGlobalInterceptors(new CacheControlInterceptor());

  // Surface unhandled rejections / uncaught exceptions to Sentry. Without
  // these, async errors that escape Nest's filter chain (e.g. setTimeout
  // callbacks) would be silently swallowed in production.
  process.on('unhandledRejection', (reason) => {
    reportProcessError('UnhandledRejection', reason);
  });
  process.on('uncaughtException', (err) => {
    reportProcessError('UncaughtException', err);
  });

  // API prefix — exclude /health so Fly.io liveness probes hit /health,
  // and exclude /join/:code and /invite/:code so the public invite landing
  // pages match the universal-link config (https://app.tgp.com/join/...)
  // without the /api prefix. The invite-landing controller's `api/invite/:code`
  // JSON alias is *not* excluded — it intentionally lives under /api alongside
  // the existing /api/invite/:code/preview JSON route.
  // /download/* and /signup are durable public status pages used as the
  // destinations for the APP_STORE_URL, PLAY_STORE_URL, and
  // PUBLIC_WEB_SIGNUP_URL secrets until the real App Store / Play Store
  // listings exist; they must be reachable as bare paths under
  // app.trygrowthproject.com, so they are excluded from the /api prefix.
  app.setGlobalPrefix('api', {
    exclude: [
      'health',
      'healthz',
      'readyz',
      'join/:code',
      'invite/:code',
      'download/ios',
      'download/android',
      'signup',
      'signup/:code',
      // Universal Links / App Links require these documents at the apex
      // domain (not under /api). See WellKnownController.
      '.well-known/apple-app-site-association',
      '.well-known/assetlinks.json',
      // Public trust surface (privacy, terms, security, status). Mounted
      // outside /api so they resolve as bare paths under
      // app.trygrowthproject.com — that is the URL shape app store
      // reviewers and early customers expect.
      'privacy',
      'terms',
      'security',
      'status',
      // Public help surface (coach-facing self-serve content). Mounted
      // outside /api for the same reason as trust pages — bare URLs
      // under the public hostname so coaches can be linked here from
      // welcome emails and the console without an /api prefix.
      'help',
      'help/setup',
      'help/first-client',
      'help/tour',
      'help/faq',
      'help/support',
      'help/contact',
      // R46 — Public coach landing pages (canonical `/p/...` slug routes) AND
      // B3 (PR-18) — verified custom-domain apex routes (`GET /`,
      // `GET /checkout`, `POST /leads`, `POST /view`). Both shapes are pinned
      // in LANDING_PUBLIC_PREFIX_EXCLUDE so the route-registration spec boots
      // against the EXACT same exclude list — a future edit that drops an
      // exclusion fails the test rather than silently regressing routing
      // (the prior P0 was a bare custom-domain route mounted under /api).
      // The custom-domain entries are method-scoped, so no `/api/...` route
      // is shadowed and `/p/...` is never hijacked.
      ...LANDING_PUBLIC_PREFIX_EXCLUDE,
    ],
  });

  // OpenAPI spec + Swagger UI. No-op when ENABLE_API_DOCS!=true in
  // production. Mounted before listen() so /docs-json and /docs are
  // registered routes when the server starts accepting connections.
  setupSwagger(app);

  const port = parseInt(process.env.PORT || '3000', 10);
  // Must bind to 0.0.0.0 for Fly.io — binding to localhost won't be reachable
  await app.listen(port, '0.0.0.0');
  Logger.log(`The Growth Project API running on port ${port}`, 'Bootstrap');
}

bootstrap();
