import re, sys, difflib, collections
P="/home/user/workspace/execution/e7d2385c/s7-c1/format/"
files=[l.strip() for l in open(P+"FILES10.txt") if l.strip()]
PUNCT=sorted(["...","=>","===","!==","==","!=","<=",">=","&&","||","??","?.","++","--","+=","-=","*=","/=","**","<<",">>",">>>","&&=","||=","??=",
 "{","}","(",")","[","]",";",",","<",">","+","-","*","/","%","&","|","^","!","~","?",":","=",".","@","#"],key=len,reverse=True)
def tokenize(src):
    i=0;n=len(src);out=[]
    while i<n:
        c=src[i]
        if c in " \t\r\n": i+=1; continue
        if src.startswith("//",i):
            j=src.find("\n",i); j=n if j<0 else j; out.append(("cmt",src[i:j].rstrip())); i=j; continue
        if src.startswith("/*",i):
            j=src.find("*/",i+2); j=n if j<0 else j+2; out.append(("cmt",re.sub(r"\s+"," ",src[i:j]))); i=j; continue
        if c in "'\"":
            j=i+1;buf=[]
            while j<n and src[j]!=c:
                if src[j]=="\\": buf.append(src[j:j+2]); j+=2
                else: buf.append(src[j]); j+=1
            s="".join(buf)
            # normalise quote escapes for requote comparison
            s=s.replace("\\'","'").replace('\\"','"')
            out.append(("str",s)); i=j+1; continue
        if c=="`":
            j=i+1;depth=0;buf=[]
            while j<n:
                if src[j]=="\\": buf.append(src[j:j+2]); j+=2; continue
                if depth==0 and src[j]=="`": break
                if src.startswith("${",j): depth+=1; buf.append("${"); j+=2; continue
                if depth>0 and src[j]=="}": depth-=1
                if depth>0 and src[j]=="{": depth+=1
                buf.append(src[j]); j+=1
            out.append(("tpl","".join(buf))); i=j+1; continue
        m=re.match(r"[A-Za-z_$][\w$]*",src[i:])
        if m: out.append(("id",m.group())); i+=len(m.group()); continue
        m=re.match(r"\d[\w.]*",src[i:])
        if m: out.append(("num",m.group())); i+=len(m.group()); continue
        for p in PUNCT:
            if src.startswith(p,i): out.append(("p",p)); i+=len(p); break
        else: out.append(("?",c)); i+=1
    return out
tot=collections.Counter(); files_ok=0
for f in files:
    a=tokenize(open(P+"orig/"+f).read()); b=tokenize(open(P+"fmt/"+f).read())
    # template literals: prettier may reflow ${ } content whitespace; compare with whitespace removed
    norm=lambda t:(t[0], re.sub(r"\s+","",t[1]) if t[0]=="tpl" else t[1])
    A=[norm(t) for t in a]; B=[norm(t) for t in b]
    sm=difflib.SequenceMatcher(None,A,B,autojunk=False)
    res=collections.Counter(); other=[]
    for tag,i1,i2,j1,j2 in sm.get_opcodes():
        if tag=="equal": continue
        for t in A[i1:i2]: res[("-",)+t]+=1
        for t in B[j1:j2]: res[("+",)+t]+=1
    # non-punct residual
    np={k:v for k,v in res.items() if k[1]!="p"}
    pun={k:v for k,v in res.items() if k[1]=="p"}
    # ids/strings multiset equality
    ms=lambda T,k: collections.Counter(t[1] for t in T if t[0]==k)
    same_ids = ms(A,"id")==ms(B,"id"); same_str=ms(A,"str")==ms(B,"str"); same_num=ms(A,"num")==ms(B,"num"); same_cmt=ms(A,"cmt")==ms(B,"cmt"); same_tpl=ms(A,"tpl")==ms(B,"tpl")
    print(f"{f}: tokens {len(A)}->{len(B)} ids={same_ids} str={same_str} num={same_num} cmt={same_cmt} tpl={same_tpl} punct_residual={dict(((k[0]+k[2]),v) for k,v in pun.items())} nonpunct_residual={dict(((k[0]+k[1]+':'+k[2][:60]),v) for k,v in np.items())}")
