# Handoff bundle — environmental rehydration only (no repeat proof, no product state change)

Purpose: let a fresh sandbox reach the exact frozen S7-2 C1 candidate **without refetching or recomposing C1**. Restoring is environment rehydration; it does not re-prove anything and grants nothing. All items below already existed; nothing new was committed, no new ref or product index write was made to `worktrees/s7-c1` (bundle built from existing `refs/s7/*`, verification done in a scratch index file that was deleted).

## Contents

| File | sha256 | Role |
|---|---|---|
| `s7-c1-parents-5c760b77-881c4c79-from-public-c23b9d9f.bundle` (416 KB) | `a238a7b17ce112a59a4f3c262c30f618e88dbb11c1648dfc86257ea4ebed427d` | heads `refs/s7/foundation-5c760b77` = `5c760b774598532e90d5d217e15adc9285c3c3f4`, `refs/s7/c1-881c4c79` = `881c4c791727adef8d423931e1cca83a0ffbb9c9`; prerequisite public `c23b9d9f3fcc106b92c061ceb7d04d7ec53038d7`; `git bundle verify` okay |
| `c1-formatted-on-foundation-5c760b77.patch` | `a413891afad541414d0313566accfe9e1f7cdcb7dfd1b496b3a77aad0906879b` | exact frozen 18-path staged diff vs `5c760b77` (= `git diff --cached HEAD` of the candidate) |
| `INDEX_BLOBS_18.txt` | `541e5c52…` | expected `git ls-files -s` blob ids of the 18 paths |
| `PATCH_RESTORE_VERIFY.txt` | — | scratch-index proof: `read-tree 5c760b77` + `apply --cached patch` → tree `87798e742c7b48f56b05e9b5c30efa877180a9b3` (match) |
| `07-merge-message.r2.txt` | `288048d7b7e908f8803d3d70e57465f52cfc9f102bb4bc4b1dba30143ce7cb83` | parent-APPROVED commit message — READY_NOT_RUN |
| `09-validate-launch.READY_NOT_RUN.sh` | `a57c224c6e8e9364393318efaa99c33f4a90877287d7e1a7e370b1c75b220448` | validation binding (hooks install → hooked commit → targeted Jest) — READY_NOT_RUN; requires a fresh explicit grant after the operator STOP |

## Restore route (source state only)

1. Obtain public `c23b9d9f` (depth-1 fetch from `BradleyGleavePortfolio/growth-project-backend` is the only network step, and only if the object is absent; alternatively any store already holding it, e.g. `execution/e7d2385c/s7-foundation-format/*.bundle` also requires `c23b9d9f`).
2. `git fetch <bundle> 'refs/s7/*:refs/s7/*'` → verify `git rev-parse refs/s7/foundation-5c760b77^{tree}` = `7800ecb4d294a48ed3d7282363265e5f07339f97`.
3. `git config user.name "Bradley Gleave"; git config user.email bradley@bradleytgpcoaching.com` (repo-local).
4. `git checkout --detach 5c760b77…` then **either** replay the merge state: `git merge --no-commit --no-ff 881c4c79…` (two version-line conflicts) and `git checkout --theirs`/resolve is NOT needed — instead: `git read-tree 5c760b77 && git apply --index c1-formatted-on-foundation-5c760b77.patch` → `git write-tree` must equal `87798e742c7b48f56b05e9b5c30efa877180a9b3`; to reproduce the two-parent commit later, write `.git/MERGE_HEAD` = `881c4c791727adef8d423931e1cca83a0ffbb9c9` (this is how the live worktree stands: HEAD `5c760b77`, MERGE_HEAD `881c4c79`, index `87798e74`).
5. Compare `git ls-files -s <18 paths>` with `INDEX_BLOBS_18.txt`.

## Dependency / generated-client pins — restore only if absent (NOT archived: 717 MB)

- Manifests (unchanged by C1): `package.json` blob `656d11a20c6abee819a0b04e9f04c0b66c0a05ef`, `package-lock.json` blob `354de3dae19449970497da6e4d87f0a1225a8f43`; accepted installed record `node_modules/.package-lock.json` sha256 prefix `05bc530aa44bfa6d` (651 entries). Canonical install command of record (S5/S7): `npm ci --no-audit --no-fund --ignore-scripts --loglevel=error` (network; requires a separate grant) — or copy an accepted tree read-only as done here (`cp -a worktrees/s7-foundation/node_modules …`). Strict pins: jest 30.4.2, ts-jest 29.4.9, typescript 5.9.3, @prisma/client 6.19.3, prisma 6.19.3, lefthook 2.1.9 (+ `lefthook-linux-x64`), eslint 10.5.0; Prettier 3.9.6 via existing link `node_modules/.bin/prettier` → `execution/e7d2385c/s5-continuation/tooling/prettier-3.9.6/…/prettier.cjs` (`6e922134…`).
- Prisma client for the C1 schema (regenerate only if absent; this is environmental, not proof): `env CHECKPOINT_DISABLE=1 PRISMA_HIDE_UPDATE_MESSAGE=1 npm_config_offline=true node node_modules/prisma/build/index.js generate --schema prisma/schema.prisma` → expected `node_modules/.prisma/client/index.d.ts` sha256 prefix `bf679a16e50a6f0c` (engine `debian-openssl-3.0.x` already in `@prisma/engines`; no download observed).
- Contract artifact is **committed state**, do not regenerate to restore: `docs/contracts/importer-openapi.json` sha256 `bdb022dd6c4fb64cdf291fdde3796b99e4b23004f676b7cb46a58460526ba4e5`; the recorded one-time generation command was `env NODE_OPTIONS=--max-old-space-size=4096 CHECKPOINT_DISABLE=1 npm_config_offline=true npm run contract:importer` (output byte-identical to the resolution; that proof stands, do not repeat).
- Hooks: none installed anywhere yet; installation is stage 1 of the READY_NOT_RUN binding.

No network activity was performed to build this directory.
