#!/usr/bin/env bash
# S7-2 C1 validation binding: install real hooks (offline lefthook), ordinary hooked commit of the frozen
# formatted candidate with the parent-approved message, then the existing targeted Jest suites only.
# Same persistent-launch/timeout pattern as s7-foundation-format/08-commit-launch-r2.sh: absolute paths,
# guards stop on mismatch (rc 70/71/72), each child bounded `timeout -k 30 600`, sentinel marks terminal.
# NOT to be launched before the dual source grants + explicit transfer. Launch (then):
#   setsid nohup bash /home/user/workspace/execution/e7d2385c/s7-c1-formatted/09-validate-launch.sh \
#     > /home/user/workspace/execution/e7d2385c/s7-c1-formatted/logs/09-launcher.out 2>&1 &
#   poll /home/user/workspace/execution/e7d2385c/s7-c1-formatted/logs/09-validate.sentinel
set -u
P=/home/user/workspace/execution/e7d2385c/s7-c1-formatted; L=$P/logs; W=/home/user/workspace/worktrees/s7-c1
export GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 NODE_OPTIONS=--max-old-space-size=4096 PRISMA_HIDE_UPDATE_MESSAGE=1 npm_config_update_notifier=false npm_config_fund=false npm_config_audit=false npm_config_offline=true CHECKPOINT_DISABLE=1 LEFTHOOK_VERBOSE=1 CI=1
mkdir -p "$L"; log=$L/09-validate.log; sent=$L/09-validate.sentinel
cd "$W" || { echo "RC=74 STAGE=cd END=$(date -u +%FT%TZ)" > "$sent"; exit 74; }
echo "START $(date -u +%FT%TZ) pid=$$ NODE_OPTIONS=$NODE_OPTIONS bound=600s/kill30 node=$(node -v)" > "$log"
stop(){ echo "STOP $1 rc=$2 $(date -u +%FT%TZ)" >> "$log"; echo "RC=$2 STAGE=$1 END=$(date -u +%FT%TZ) HEAD=$(git rev-parse HEAD)" > "$sent"; exit "$2"; }

# --- preconditions: exact candidate / identity / manifest / message guards (rc 70) ---
[ "$(git rev-parse HEAD)" = 5c760b774598532e90d5d217e15adc9285c3c3f4 ] || stop precondition-HEAD 70
[ "$(cat .git/MERGE_HEAD 2>/dev/null)" = 881c4c791727adef8d423931e1cca83a0ffbb9c9 ] || stop precondition-MERGE_HEAD 70
[ "$(git write-tree)" = 87798e742c7b48f56b05e9b5c30efa877180a9b3 ] || stop precondition-index-tree 70
[ -z "$(git diff --name-only)$(git ls-files --others --exclude-standard)" ] || stop precondition-dirty 70
[ "$(git diff --cached --name-only HEAD | wc -l)" = 18 ] || stop precondition-staged-count 70
[ "$(sha256sum "$P/07-merge-message.r2.txt" | cut -c1-64)" = 288048d7b7e908f8803d3d70e57465f52cfc9f102bb4bc4b1dba30143ce7cb83 ] || stop precondition-message-hash 70
[ "$(sha256sum "$P/MANIFEST.sha256" | cut -c1-64)" = 8ef86a1b24b43c2aafc2bc9279393d54734d0f06ac42da34b0088d338ae7802a ] || stop precondition-manifest-hash 70
( cd "$P" && sha256sum -c --quiet MANIFEST.sha256 ) >> "$log" 2>&1 || stop precondition-manifest-contents 70
[ "$(sha256sum /home/user/workspace/execution/e7d2385c/s7-c1/MANIFEST.sha256 | cut -c1-64)" = 128496e2cf9d2090ddf69df077c58a09473db7db61cafe348728d5af47b94b43 ] || stop precondition-original-packet 70
[ "$(git var GIT_AUTHOR_IDENT | sed 's/ [0-9]* [+-][0-9]*$//')" = "Bradley Gleave <bradley@bradleytgpcoaching.com>" ] || stop precondition-author-identity 70
[ "$(git var GIT_COMMITTER_IDENT | sed 's/ [0-9]* [+-][0-9]*$//')" = "Bradley Gleave <bradley@bradleytgpcoaching.com>" ] || stop precondition-committer-identity 70
[ -z "$(git config core.hooksPath)" ] || stop precondition-hooksPath 70
[ "$(git hash-object lefthook.yml)" = 54d037490460fcddf2523ce05801bae9860489ff ] || stop precondition-lefthook-yml 70
[ "$(git hash-object package.json)" = 656d11a20c6abee819a0b04e9f04c0b66c0a05ef ] || stop precondition-package-json 70
[ "$(git hash-object package-lock.json)" = 354de3dae19449970497da6e4d87f0a1225a8f43 ] || stop precondition-lock 70
[ "$(sha256sum node_modules/.package-lock.json | cut -c1-16)" = 05bc530aa44bfa6d ] || stop precondition-installed-record 70
[ "$(sha256sum node_modules/.prisma/client/index.d.ts | cut -c1-16)" = bf679a16e50a6f0c ] || stop precondition-prisma-client 70
[ "$(sha256sum docs/contracts/importer-openapi.json | cut -c1-64)" = bdb022dd6c4fb64cdf291fdde3796b99e4b23004f676b7cb46a58460526ba4e5 ] || stop precondition-artifact 70
[ -x node_modules/.bin/lefthook ] && [ -x node_modules/.bin/jest ] || stop precondition-bins 70
echo "PRECONDITIONS_OK $(date -u +%FT%TZ)" >> "$log"

# --- stage 1: real hooks via the existing offline lefthook (no fetch: binary already in node_modules/lefthook-linux-x64) ---
echo "HOOKS_START $(date -u +%FT%TZ)" >> "$log"
timeout -k 30 600 ./node_modules/.bin/lefthook install >> "$log" 2>&1; rc=$?
echo "HOOKS_END $(date -u +%FT%TZ) rc=$rc" >> "$log"
[ $rc = 0 ] || stop hooks-install "$rc"
[ -x .git/hooks/pre-commit ] && [ -x .git/hooks/commit-msg ] && grep -q "$W/node_modules/.bin/lefthook" .git/hooks/pre-commit || stop hooks-missing 71
[ -z "$(git config core.hooksPath)" ] || stop hooks-hooksPath 71
[ "$(git write-tree)" = 87798e742c7b48f56b05e9b5c30efa877180a9b3 ] && [ -z "$(git diff --name-only)$(git ls-files --others --exclude-standard)" ] || stop hooks-changed-tree 71

# --- stage 2: ordinary hooked commit (real pre-commit + commit-msg; no --no-verify) ---
echo "COMMIT_START $(date -u +%FT%TZ)" >> "$log"
timeout -k 30 600 git commit -F "$P/07-merge-message.r2.txt" >> "$log" 2>&1; rc=$?
echo "COMMIT_END $(date -u +%FT%TZ) rc=$rc HEAD=$(git rev-parse HEAD)" >> "$log"
[ $rc = 0 ] || stop commit "$rc"
H=$(git rev-parse HEAD)
[ "$(git rev-parse 'HEAD^{tree}')" = 87798e742c7b48f56b05e9b5c30efa877180a9b3 ] || stop commit-tree 71
[ "$(git rev-parse HEAD^1)" = 5c760b774598532e90d5d217e15adc9285c3c3f4 ] && [ "$(git rev-parse HEAD^2)" = 881c4c791727adef8d423931e1cca83a0ffbb9c9 ] && [ -z "$(git rev-parse -q --verify HEAD^3 2>/dev/null)" ] || stop commit-parents 71
[ "$(git log -1 --format='%an <%ae>|%cn <%ce>')" = "Bradley Gleave <bradley@bradleytgpcoaching.com>|Bradley Gleave <bradley@bradleytgpcoaching.com>" ] || stop commit-identity 71
[ "$(git log -1 --format=%B | sha256sum | cut -c1-64)" = "$(sha256sum "$P/07-merge-message.r2.txt" | cut -c1-64)" ] || echo "NOTE message-bytes-differ-from-file (git may strip trailing newline); recorded" >> "$log"
git log -1 --format=%B | grep -qiE 'co-authored-by|generated with|signed-off-by' && stop commit-trailer 71
[ ! -e .git/MERGE_HEAD ] && [ -z "$(git status --porcelain --untracked-files=all)" ] || stop commit-state 71
{ echo "COMMIT=$H"; echo "TREE=$(git rev-parse 'HEAD^{tree}')"; echo "PARENTS=$(git rev-parse HEAD^1) $(git rev-parse HEAD^2)"; echo "IDENT=$(git log -1 --format='%an <%ae> | %cn <%ce> | %aI | %cI')"; } > "$P/COMMIT_RESULT.txt"

# --- stage 3: existing targeted Jest only (default config; test/rls-*.spec.ts is ignored by that config) ---
echo "JEST_START $(date -u +%FT%TZ)" >> "$log"
timeout -k 30 600 ./node_modules/.bin/jest --ci --runInBand test/contracts/importer-contract.spec.ts src/extension-pair/__tests__ > "$L/09-jest.log" 2>&1; rc=$?
echo "JEST_END $(date -u +%FT%TZ) rc=$rc" >> "$log"
grep -E '^(Test Suites|Tests|Snapshots|Time):' "$L/09-jest.log" >> "$log" 2>/dev/null
grep -E '^(PASS|FAIL) ' "$L/09-jest.log" >> "$log" 2>/dev/null
[ "$(git rev-parse HEAD)" = "$H" ] && [ -z "$(git status --porcelain --untracked-files=all)" ] || stop jest-changed-tree 71
[ $rc = 0 ] || stop jest "$rc"
echo "DONE $(date -u +%FT%TZ)" >> "$log"
echo "RC=0 STAGE=done END=$(date -u +%FT%TZ) HEAD=$H" > "$sent"
