#!/usr/bin/env bash
# R2: replay archived patches onto clean 143d451e and recover the exact latest staged tree 756a0d79.
#  (a) frozen two-file patch c36258b3 (2026-09-22/remediation/s5-r4/checkpoint-1/s5-r4-dirty-from-143d451e.patch) -> working tree; core.abbrev=8 (archived S3 decision (a))
#      => status pin, dirty fingerprint 6850b32e, post-image blobs ff5a38b8 / 85a636ba
#  (b) archived 06F formatting-only delta c43b4d1b (s5-hooked-candidate-continuation/preimage/formatting-only-vs-index-3d30.patch) -> spec only
#      => spec sha256 338defe8; staging both files must reproduce tree 756a0d79 and full parent diff 2c92a964 byte-for-byte (archived new-two-file-parent.patch)
# Pure recovery from archived bytes: no formatter, no install, no product authorship.
set -u
export GIT_OPTIONAL_LOCKS=0
WS=/home/user/workspace
W=$WS/worktrees/s5-r4
RET=$WS/execution/e7d2385c/s5-continuation/retrieved
P1=$RET/2026-09-22/remediation/s5-r4/checkpoint-1/s5-r4-dirty-from-143d451e.patch
P2=$RET/2026-09-23/6c2a68ac/s5-hooked-candidate-continuation/preimage/formatting-only-vs-index-3d30.patch
P3=$RET/2026-09-23/6c2a68ac/s5-hooked-candidate-continuation/preimage/new-two-file-parent.patch
PRE=$RET/2026-09-23/6c2a68ac/s5-hooked-candidate-continuation/preimage/rls-g2-pg17-etq0.spec.ts.staged-01f3cfc0
SPEC=test/rls-g2-pg17-etq0.spec.ts; BOOT=test/utils/g2-pg17-bootstrap.sh
FAIL=0
eq(){ if [ "$2" = "$3" ]; then echo "ok   $1 | $3"; else echo "FAIL $1 | expected=$2 actual=$3"; FAIL=1; fi; }
cd "$W" || exit 70
echo "utc=$(date -u +%FT%TZ) R2 start"
eq "HEAD" 143d451ead6ccdbebd92ca3031ba7a89867d6cfc "$(git rev-parse HEAD)"
eq "clean write-tree" d0e122d35022377196908b7d132fc34c1af2fc6b "$(git write-tree)"
eq "patch1 sha256" c36258b39d0c92f0b760f11982a61427c6e7cce963eecffe2554f447346c5491 "$(sha256sum "$P1" | cut -c1-64)"
eq "patch2 sha256" c43b4d1bd793ef9cdfdf3e04a05ddbe497b90600922e74553153e8ec5d1ad21d "$(sha256sum "$P2" | cut -c1-64)"
eq "archived new parent diff sha256" 2c92a96464238d88bfe4acb9dbe5e17400f5e51d154e1c1b99c8612b373746df "$(sha256sum "$P3" | cut -c1-64)"
eq "archived preimage spec sha256" 01f3cfc09a700f1b3c76625774d08b37cdcc407453515e635cc0e7c2c7bac25d "$(sha256sum "$PRE" | cut -c1-64)"
eq "pre-image blobs at HEAD" "77bb94b638dfe74ed8e6b33d25d853cf51362ad2 c85eaca0cb3cb959d6238af2d20fe80fd4b2ef76" "$(git rev-parse HEAD:$SPEC) $(git rev-parse HEAD:$BOOT)"
[ $FAIL = 0 ] || { echo "STOP: preconditions"; exit 71; }
# (a)
git apply --check "$P1"; echo "apply --check patch1 exit=$?"
git apply "$P1"; a=$?; echo "apply patch1 exit=$a"; [ $a = 0 ] || { echo "STOP"; exit 72; }
eq "status pin" $' M test/rls-g2-pg17-etq0.spec.ts\n M test/utils/g2-pg17-bootstrap.sh' "$(git status --porcelain)"
eq "untracked beyond ignored" 0 "$(git status --porcelain --untracked-files=all | grep -c '^??')"
eq "post-image spec blob (worktree)" ff5a38b89ecc4de064f04df1dd9213be6a05c15a "$(git hash-object $SPEC)"
eq "post-image bootstrap blob (worktree)" 85a636ba75607604032cef7af1d285cb198ca263 "$(git hash-object $BOOT)"
eq "bootstrap mode" 755 "$(stat -c %a $BOOT)"
eq "patched spec sha256 == archived staged preimage 01f3cfc0" 01f3cfc09a700f1b3c76625774d08b37cdcc407453515e635cc0e7c2c7bac25d "$(sha256sum $SPEC | cut -c1-64)"
eq "index untouched" d0e122d35022377196908b7d132fc34c1af2fc6b "$(git write-tree)"
echo "fingerprint with core.abbrev unset=$({ git diff HEAD; printf '%s\n' "$(git status --porcelain --untracked-files=all)"; } | sha256sum | cut -c1-64) (archived: 16cc5e72… != pin; index-line abbrev only)"
git config --local core.abbrev 8; echo "config write core.abbrev=8 exit=$?"
eq "core.abbrev" 8 "$(git config --local --get core.abbrev)"
eq ".git/config sha256 (archived S3 post-normalization)" 6ae9e03f2f3302c88364cd54aa2edccca09d09fdd87e07d6e5606d71a1bf9254 "$(sha256sum .git/config | cut -c1-64)"
eq "git diff HEAD == frozen patch" c36258b39d0c92f0b760f11982a61427c6e7cce963eecffe2554f447346c5491 "$(git diff HEAD | sha256sum | cut -c1-64)"
eq "dirty fingerprint (runner formula) == PIN" 6850b32ef19436abe5b02f96c770f4c36ca8bea070e0c759310f17234c616aa0 "$({ git diff HEAD; printf '%s\n' "$(git status --porcelain --untracked-files=all)"; } | sha256sum | cut -c1-64)"
eq "lock unchanged" b7fed5ed611c004615022cf69375b83956e9a69604807123fbe0e7965aea9c55 "$(sha256sum package-lock.json | cut -c1-64)"
[ $FAIL = 0 ] || { echo "STOP: (a) mismatch"; exit 73; }
echo "--- (a) complete: state == archived s5-source-restore S3 (fingerprint 6850b32e). utc=$(date -u +%FT%TZ)"
# intermediate check: staging both files here would give the original prep tree 3d30aeb0 (verified read-only via a temporary index)
TMPIDX=$(mktemp); cp .git/index "$TMPIDX"
GIT_INDEX_FILE="$TMPIDX" git add -- $SPEC $BOOT; eq "original staged tree 3d30aeb0 (temp index, not the real index)" 3d30aeb08c58d47b53837dfe22b60f8dbef37871 "$(GIT_INDEX_FILE="$TMPIDX" git write-tree)"; rm -f "$TMPIDX"
eq "real index still clean tree" d0e122d35022377196908b7d132fc34c1af2fc6b "$(git write-tree)"
# (b)
git apply --check "$P2"; echo "apply --check patch2 exit=$?"
git apply "$P2"; b=$?; echo "apply patch2 exit=$b"; [ $b = 0 ] || { echo "STOP"; exit 74; }
eq "formatted spec sha256 (archived 06F pin)" 338defe8c68834b8f6e23df58547a7b6830c673bcb540a7985823532ee66a430 "$(sha256sum $SPEC | cut -c1-64)"
eq "formatted spec blob (archived 06F)" 2cc0a3dc31278f6ea626f799a17b0a3cddd1e6da "$(git hash-object $SPEC)"
eq "bootstrap still 85a636ba" 85a636ba75607604032cef7af1d285cb198ca263 "$(git hash-object $BOOT)"
eq "status pin" $' M test/rls-g2-pg17-etq0.spec.ts\n M test/utils/g2-pg17-bootstrap.sh' "$(git status --porcelain)"
[ $FAIL = 0 ] || { echo "STOP: (b) mismatch"; exit 75; }
git add -- $SPEC $BOOT; s=$?; echo "git add two files exit=$s"
eq "STAGED TREE" 756a0d7966c9125749339abbcfd681eb7e713ede "$(git write-tree)"
eq "staged spec entry" "100644 2cc0a3dc31278f6ea626f799a17b0a3cddd1e6da 0	$SPEC" "$(git ls-files -s $SPEC)"
eq "staged bootstrap entry" "100755 85a636ba75607604032cef7af1d285cb198ca263 0	$BOOT" "$(git ls-files -s $BOOT)"
eq "full parent diff sha256 == archived new-two-file-parent.patch" 2c92a96464238d88bfe4acb9dbe5e17400f5e51d154e1c1b99c8612b373746df "$(git diff --cached HEAD | sha256sum | cut -c1-64)"
eq "numstat" $'971\t356\ttest/rls-g2-pg17-etq0.spec.ts\n34\t4\ttest/utils/g2-pg17-bootstrap.sh' "$(git diff --cached --numstat HEAD)"
eq "status" $'M  test/rls-g2-pg17-etq0.spec.ts\nM  test/utils/g2-pg17-bootstrap.sh' "$(git status --porcelain)"
git diff --quiet; eq "worktree == index" 0 "$?"
eq "HEAD unchanged" 143d451ead6ccdbebd92ca3031ba7a89867d6cfc "$(git rev-parse HEAD)"
eq "refs unchanged" $'c23b9d9f3fcc106b92c061ceb7d04d7ec53038d7 commit\trefs/heads/main\n143d451ead6ccdbebd92ca3031ba7a89867d6cfc commit\trefs/restored/execute/20260921-s5-r3' "$(git for-each-ref)"
eq "hooks active" 0 "$(ls .git/hooks | grep -vc '\.sample$')"
eq "node_modules absent" yes "$([ ! -e node_modules ] && echo yes || echo no)"
echo "utc_end=$(date -u +%FT%TZ) FAIL=$FAIL"
exit $FAIL
