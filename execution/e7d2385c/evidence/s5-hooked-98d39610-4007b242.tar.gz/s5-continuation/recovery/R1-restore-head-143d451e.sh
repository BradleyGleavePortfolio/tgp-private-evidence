#!/usr/bin/env bash
# R1: fresh standalone worktrees/s5-r4 = clean 143d451e.
# Reproduces archived 2026-09-23/6c2a68ac/s5-source-restore S1 with the ONLY substitution forced by the empty sandbox:
# the baseline object database is a fresh depth-1 fetch of the public backend commit c23b9d9f (previously: cp -a of an
# already-present source/backend/.git). Bundle and refs layout identical: refs/heads/main=c23b9d9f, refs/restored/execute/20260921-s5-r3=143d451e, 0 remotes.
set -u
export GIT_OPTIONAL_LOCKS=0
WS=/home/user/workspace
W=$WS/worktrees/s5-r4
RET=$WS/execution/e7d2385c/s5-continuation/retrieved
BUNDLE=$RET/2026-09-21/remediation/s5-r3/b3-pinned-resume/checkpoint-5-B3/s5-r3-candidate.bundle
BASE=c23b9d9f3fcc106b92c061ceb7d04d7ec53038d7
HEADX=143d451ead6ccdbebd92ca3031ba7a89867d6cfc
echo "utc=$(date -u +%FT%TZ) R1: restore worktrees/s5-r4 = clean $HEADX (standalone, no origin) from depth-1 public baseline $BASE + verified S5 bundle"
echo "git_version=$(git --version)"
echo "pre: worktrees/s5-r4 absent=$([ ! -e "$W" ] && echo yes || echo NO)"
[ ! -e "$W" ] || { echo "STOP: worktree path exists"; exit 70; }
echo "bundle sha256=$(sha256sum "$BUNDLE" | cut -c1-64) (expect e42aa021442a8a004bf796e2958461bf79d11c1666fe8fb08ef46dd80bd75b48)"
[ "$(sha256sum "$BUNDLE" | cut -c1-64)" = e42aa021442a8a004bf796e2958461bf79d11c1666fe8fb08ef46dd80bd75b48 ] || { echo "STOP: bundle hash mismatch"; exit 71; }
mkdir -p "$W" && cd "$W" || exit 72
git init -q . || exit 73
git remote add origin https://github.com/BradleyGleavePortfolio/growth-project-backend.git || exit 74
echo "fetch baseline (depth 1, exact commit) start=$(date -u +%FT%TZ)"
git fetch -q --depth 1 origin "$BASE" 2>&1 | sed 's/^/  fetch: /'; frc=${PIPESTATUS[0]}
echo "fetch baseline exit=$frc end=$(date -u +%FT%TZ)"
[ "$frc" -eq 0 ] || { echo "STOP: baseline fetch failed"; exit 75; }
git update-ref refs/heads/main "$BASE" || exit 76
git remote remove origin || exit 77
git config --local --remove-section branch.main 2>/dev/null
echo "remotes=$(git remote | wc -l) promisor=$(git config --get-regexp 'remote\..*\.promisor' || echo none)"
echo "baseline HEAD ref main=$(git rev-parse refs/heads/main) shallow=$(git rev-parse --is-shallow-repository) in-pack=$(git count-objects -v | awk '/in-pack/{print $2}')"
git bundle verify "$BUNDLE" 2>&1 | sed 's/^/  /'; brc=${PIPESTATUS[0]}
echo "bundle verify exit=$brc"
[ "$brc" -eq 0 ] || { echo "STOP: bundle does not verify against baseline"; exit 78; }
git fetch -q "$BUNDLE" refs/heads/execute/20260921-s5-r3:refs/restored/execute/20260921-s5-r3 2>&1 | sed 's/^/  fetch: /'; f2=${PIPESTATUS[0]}
echo "bundle fetch exit=$f2"
[ "$f2" -eq 0 ] || { echo "STOP: bundle fetch failed"; exit 79; }
echo "refs/restored/execute/20260921-s5-r3=$(git rev-parse refs/restored/execute/20260921-s5-r3)"
git checkout -q --force --detach "$HEADX" 2>&1 | sed 's/^/  checkout: /'; crc=${PIPESTATUS[0]}
echo "checkout exit=$crc"
[ "$crc" -eq 0 ] || { echo "STOP: checkout failed"; exit 80; }
H=$(git rev-parse HEAD); echo "HEAD=$H (expect $HEADX) match=$([ "$H" = "$HEADX" ] && echo YES || echo NO)"
T=$(git rev-parse HEAD^{tree}); echo "BASE_TREE=$T (expect d0e122d35022377196908b7d132fc34c1af2fc6b) match=$([ "$T" = d0e122d35022377196908b7d132fc34c1af2fc6b ] && echo YES || echo NO)"
echo "parent=$(git rev-parse HEAD^) base c23b ancestor=$(git merge-base --is-ancestor $BASE HEAD && echo yes || echo no) commits_c23b..HEAD=$(git rev-list --count $BASE..HEAD) shallow=$(git rev-parse --is-shallow-repository)"
echo "clean state: porcelain_untracked_all=$(git status --porcelain --untracked-files=all | wc -l) tracked=$(git ls-files | wc -l) worktree_files=$(find . -path ./.git -prune -o -type f -print | wc -l)"
echo "fsck_connectivity=$(git fsck --connectivity-only 2>&1 | grep -v '^dangling' | head -3 | tr '\n' ' '; echo ok)"
echo "lock_blob=$(git ls-files -s package-lock.json | awk '{print $2}') (expect 354de3dae19449970497da6e4d87f0a1225a8f43) lock_sha256=$(sha256sum package-lock.json | cut -c1-64)"
echo "clean_fingerprint (before patch)=$({ git diff HEAD; printf '%s\n' "$(git status --porcelain --untracked-files=all)"; } | sha256sum | cut -c1-64)"
echo "refs:"; git for-each-ref | sed 's/^/  /'
echo "config keys=$(git config --local --list | wc -l)"; git config --local --list | sed 's/^/  /'
echo "utc_end=$(date -u +%FT%TZ)"
