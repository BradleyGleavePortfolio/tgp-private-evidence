# Mechanical substitutions frozen before 07R (S5_LINT_DISPOSITION_AND_COMMIT_ACTIVATION §Allowed source correction and bounded execution)
Derived from candidate/logs/06L-format-spec.log (raw 0): NEW_TREE=67fc1db5f353f0d363fe7134a78d455c0decfb55; NEW_SPEC_BLOB=b3af897e103a4a27e3cf3acaac51d0053513cdc9; NEW_SPEC_SHA256=2b7d1969f64ca837caa075e5bec91174242355804db8d37daa672cc240568e7f; NEW_PARENT_DIFF_SHA256=9f37223b889b31580ba8024b14d86ac3d0fb9feab08ef4b250292d50a735921d (candidate/preimage/new-two-file-parent.patch); spec numstat 975/357; bootstrap numstat 34/4 unchanged.
| file | continuation original (9d47c0dc packet) | substitution |
|---|---|---|
| 07R-identity-and-hooked-commit.cmd | expected staged tree 756a0d79… (guard exit 92) | 67fc1db5… (1 line) |
| 08-post-commit-identity.cmd | `%T` 756a0d79…; `diff --quiet 756a0d79 HEAD^{tree}` (+label) | 67fc1db5… |
| 08-post-commit-identity.cmd | parent-diff sha256 2c92a964… (label "06F-recorded …") | 9f37223b… (label "06L-recorded …") |
| 08-post-commit-identity.cmd | numstat `971\t356` spec | `975\t357` spec |
| step.sh | O/P/TOOL/LOCK roots, label slot-H2 | this sandbox's roots, slot-H3 (steps/step.sh.diff-vs-continuation) |
Unchanged: parent 143d451e, bootstrap numstat 34/4, two paths, author/committer, message file `$P/steps/07-commit-message.txt` (1da44908…, frozen prep e9f4a5d5 copy), `%(trailers)`, `%B`, porcelain/untracked 0, banned tokens, detached, refs, gpgsig. 09/10 are the ORIGINAL prep command files byte-for-byte (d5a0f8e0…, eb072c6c…) run through the substituted step.sh (O exported to candidate root).
