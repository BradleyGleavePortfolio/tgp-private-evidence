source $P/steps/chk.sh
SPEC=test/rls-g2-pg17-etq0.spec.ts; BOOT=test/utils/g2-pg17-bootstrap.sh
# 06L (S5_LINT_DISPOSITION grant): modeled on frozen 06F (cd8c3cd3) with the recovered/binding-edited pins.
# 1. reassert: index == recovered staged tree 756a0d79 (spec 338defe8); worktree spec == recorded five-binding pre-format file; binding-only diff already recorded by B1
eq "staged tree before" 756a0d7966c9125749339abbcfd681eb7e713ede "$(git write-tree)"
eq "staged spec sha256 before" 338defe8c68834b8f6e23df58547a7b6830c673bcb540a7985823532ee66a430 "$(git show :$SPEC | sha256sum | cut -c1-64)"
eq "worktree spec == recorded binding-edited pre-format file" "$(cut -c1-64 $O/preimage/BINDING_EDITED_SPEC.sha256)" "$(sha256sum $SPEC | cut -c1-64)"
eq "binding-only diff vs index 756a == recorded" "$(cut -c1-64 $O/preimage/BINDING_ONLY_DIFF.sha256)" "$(git diff | sha256sum | cut -c1-64)"
eq "binding-only numstat 5/5 single path" "5	5	$SPEC" "$(git diff --numstat)"
eq "only the spec differs from index" "$SPEC" "$(git diff --name-only)"
[ "$FAIL" = 0 ] || { echo "preassertion failed; formatter NOT run"; exit 80; }
# 2. one formatting pass with the pinned CLI directly
node "$TOOL/node_modules/prettier/bin/prettier.cjs" --write $SPEC; w=$?; echo "prettier --write raw exit=$w"
eq "prettier --write raw" 0 "$w"
[ "$FAIL" = 0 ] || { echo "formatter write failed; stopping, nothing staged"; exit 81; }
echo "FORMATTED_SPEC_SHA256=$(sha256sum $SPEC | cut -c1-64)"
# 3. --check once, raw status preserved
node "$TOOL/node_modules/prettier/bin/prettier.cjs" --check $SPEC; c=$?; echo "prettier --check raw exit=$c"
eq "prettier --check raw" 0 "$c"
[ "$FAIL" = 0 ] || { echo "check failed after write; stopping, nothing staged"; exit 82; }
# 4. deltas kept separate: (i) binding-only (B1, preimage/binding-only-vs-index-756a.patch) (ii) formatter-only = binding-edited pre-format file -> formatted file (iii) combined vs index 756a
git diff > $O/preimage/binding-plus-format-vs-index-756a.patch; echo "binding+format vs index 756a sha256=$(sha256sum $O/preimage/binding-plus-format-vs-index-756a.patch | cut -c1-64) numstat=$(git diff --numstat | tr '\t' '/')"
diff -u $O/preimage/rls-g2-pg17-etq0.spec.ts.binding-edited-preformat $SPEC > $O/preimage/formatter-only-delta.patch; echo "formatter-only delta sha256=$(sha256sum $O/preimage/formatter-only-delta.patch | cut -c1-64) lines_changed=$(grep -cE '^[-+][^-+]' $O/preimage/formatter-only-delta.patch)"
eq "only the spec differs from index" "$SPEC" "$(git diff --name-only)"
eq "no untracked beyond ignored" 0 "$(git status --porcelain --untracked-files=all | grep -c '^??')"
eq "bootstrap blob/mode unchanged (index)" "100755 85a636ba75607604032cef7af1d285cb198ca263 0	$BOOT" "$(git ls-files -s $BOOT)"
eq "bootstrap worktree bytes == staged blob" 85a636ba75607604032cef7af1d285cb198ca263 "$(git hash-object $BOOT)"
eq "lock unchanged" b7fed5ed611c004615022cf69375b83956e9a69604807123fbe0e7965aea9c55 "$(sha256sum package-lock.json | cut -c1-64)"
# semantic-neutrality after formatting (whitespace-insensitive token counts)
FLAT=$(tr -d ' \n\r\t' < $SPEC)
eq "aliased _families literal present" 1 "$(printf '%s' "$FLAT" | grep -o "const_families=\['clients','workouts','client_history'\];" | wc -l)"
eq "aliased source_platform rest bindings" 3 "$(printf '%s' "$FLAT" | grep -o 'const{source_platform:_source_platform,\.\.\.rest}=r;' | wc -l)"
eq "aliased updated_at rest binding" 1 "$(printf '%s' "$FLAT" | grep -o '({updated_at:_updated_at,\.\.\.rest}:any)=>rest' | wc -l)"
eq "no unaliased original bindings remain" 0 "$(printf '%s' "$FLAT" | grep -oE "constfamilies=|const\{source_platform,\.\.\.rest\}=r;|\(\{updated_at,\.\.\.rest\}:any\)=>rest" | wc -l)"
[ "$FAIL" = 0 ] || { echo "side-effect/semantic check failed; stopping, nothing staged"; exit 83; }
# 5. stage only the spec; record new exact tree / full parent diff / numstat
git add -- $SPEC; a=$?; echo "git add raw exit=$a"; eq "git add raw" 0 "$a"
echo "NEW_TREE=$(git write-tree)"
echo "NEW_SPEC_BLOB=$(git ls-files -s $SPEC)"
echo "NEW_SPEC_SHA256=$(git show :$SPEC | sha256sum | cut -c1-64)"
echo "NEW_PARENT_DIFF_SHA256=$(git diff --cached HEAD | sha256sum | cut -c1-64)"; git diff --cached HEAD > $O/preimage/new-two-file-parent.patch
echo "NEW_NUMSTAT_BEGIN"; git diff --cached --numstat HEAD; echo "NEW_NUMSTAT_END"
eq "two changed paths" $'test/rls-g2-pg17-etq0.spec.ts\ntest/utils/g2-pg17-bootstrap.sh' "$(git diff --cached --name-only HEAD)"
eq "bootstrap numstat unchanged" "34	4	$BOOT" "$(git diff --cached --numstat HEAD -- $BOOT)"
eq "status" $'M  test/rls-g2-pg17-etq0.spec.ts\nM  test/utils/g2-pg17-bootstrap.sh' "$(git status --porcelain)"
chk "worktree == index" git diff --quiet
eq "staged spec == formatted bytes" "$(sha256sum $SPEC | cut -c1-64)" "$(git show :$SPEC | sha256sum | cut -c1-64)"
eq "lock blob unchanged" 354de3dae19449970497da6e4d87f0a1225a8f43 "$(git ls-files -s package-lock.json | awk '{print $2}')"
eq "HEAD unchanged" 143d451ead6ccdbebd92ca3031ba7a89867d6cfc "$(git rev-parse HEAD)"
exit $FAIL
