npm ci --no-audit --no-fund --ignore-scripts --loglevel=error
