#!/usr/bin/env bash
# Phase 2 caller (grant §07R–10): sequential steps through steps/step.sh, stop at first nonzero. Detached; actual waited exits in caller-phase2.receipt.
set -u
S=/home/user/workspace/execution/e7d2385c/s5-continuation
W=/home/user/workspace/worktrees/s5-r4
R=$S/candidate/caller-phase2.receipt
echo "phase2 start=$(date -u +%FT%TZ) pid=$$ sid=$(ps -o sid= -p $$ | tr -d ' ')" > "$R"
run(){ bash "$S/steps/step.sh" "$1" "$2" "$3" "$4" "$5" "$6" "${7:-}"; rc=$?
  echo "step=$1 label=$2 waited_exit=$rc utc=$(date -u +%FT%TZ)" >> "$R"
  [ "$rc" -eq 0 ] || { echo "STOP at $1 ($2) rc=$rc" >> "$R"; echo "phase2 end=$(date -u +%FT%TZ) final=$rc" >> "$R"; exit "$rc"; }; }
run 07R identity-and-hooked-commit 1200 1 "$W" "$S/steps/07R-identity-and-hooked-commit.cmd"
run 08 post-commit-identity 30 1 "$W" "$S/steps/08-post-commit-identity.cmd"
run 09 bundle 60 1 "$W" "$S/steps/09-bundle.cmd"
run 10 check-r75-range 60 1 "$W" "$S/steps/10-check-r75-range.cmd"
echo "phase2 end=$(date -u +%FT%TZ) final=0" >> "$R"
