#!/usr/bin/env bash
# Phase F (fresh-sandbox minimum setup) caller: sequential steps through steps/step.sh, stop at first nonzero. Detached; actual waited exits recorded in caller-phaseF.receipt.
set -u
S=/home/user/workspace/execution/e7d2385c/s5-continuation
W=/home/user/workspace/worktrees/s5-r4
TOOL=$S/tooling/prettier-3.9.6
R=$S/candidate/caller-phaseF.receipt
echo "phaseF start=$(date -u +%FT%TZ) pid=$$ sid=$(ps -o sid= -p $$ | tr -d ' ')" > "$R"
run(){ # NN label T offline workdir cmd post
  bash "$S/steps/step.sh" "$1" "$2" "$3" "$4" "$5" "$6" "${7:-}"; rc=$?
  echo "step=$1 label=$2 waited_exit=$rc utc=$(date -u +%FT%TZ)" >> "$R"
  [ "$rc" -eq 0 ] || { echo "STOP at $1 ($2) rc=$rc" >> "$R"; echo "phaseF end=$(date -u +%FT%TZ) final=$rc" >> "$R"; exit "$rc"; }
}
run F0 tooling-npm-ci 300 0 "$TOOL" "$S/steps/F0-tooling-npm-ci.cmd" "$S/steps/F0-tooling-npm-ci.post"
run F1 npm-ci 1200 0 "$W" "$S/steps/F1-npm-ci.cmd" "$S/steps/F1-npm-ci.post"
run 02 prisma-generate-guarded 300 0 "$W" "$S/steps/02-prisma-generate-guarded.cmd" "$S/steps/02-prisma-generate-guarded.post"
run 03 lefthook-install 60 1 "$W" "$S/steps/03-lefthook-install.cmd" "$S/steps/03-lefthook-install.post"
run 04 link-formatter 10 1 "$W" "$S/steps/04-link-formatter.cmd" "$S/steps/04-link-formatter.post"
echo "phaseF end=$(date -u +%FT%TZ) final=0" >> "$R"
