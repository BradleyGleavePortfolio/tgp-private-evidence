#!/usr/bin/env bash
# B1: record-only. After the five binding aliases were applied to the worktree spec by visible manual patch (edit tool),
# prove: exactly five changed lines, exactly the authorized substitutions, unchanged property keys / rest expressions / everything else.
# Writes only under $O/preimage. No formatter, no staging.
set -u
export GIT_OPTIONAL_LOCKS=0
W=/home/user/workspace/worktrees/s5-r4
O=/home/user/workspace/execution/e7d2385c/s5-continuation/candidate
SPEC=test/rls-g2-pg17-etq0.spec.ts
FAIL=0
eq(){ if [ "$2" = "$3" ]; then echo "ok   $1 | $3"; else echo "FAIL $1 | expected=$2 actual=$3"; FAIL=1; fi; }
cd "$W" || exit 70
echo "utc=$(date -u +%FT%TZ) B1 record binding-only delta"
eq "index tree still 756a0d79" 756a0d7966c9125749339abbcfd681eb7e713ede "$(git write-tree)"
eq "staged spec 338defe8 (preimage saved by B0)" 338defe8c68834b8f6e23df58547a7b6830c673bcb540a7985823532ee66a430 "$(git show :$SPEC | sha256sum | cut -c1-64)"
cp $SPEC $O/preimage/rls-g2-pg17-etq0.spec.ts.binding-edited-preformat
sha256sum $SPEC | cut -c1-64 > $O/preimage/BINDING_EDITED_SPEC.sha256; echo "binding-edited pre-format spec sha256=$(cat $O/preimage/BINDING_EDITED_SPEC.sha256)"
git diff > $O/preimage/binding-only-vs-index-756a.patch
sha256sum $O/preimage/binding-only-vs-index-756a.patch | cut -c1-64 > $O/preimage/BINDING_ONLY_DIFF.sha256; echo "binding-only diff sha256=$(cat $O/preimage/BINDING_ONLY_DIFF.sha256)"
eq "only the spec differs from index" "$SPEC" "$(git diff --name-only)"
eq "numstat 5/5" "5	5	$SPEC" "$(git diff --numstat)"
eq "no untracked beyond ignored" 0 "$(git status --porcelain --untracked-files=all | grep -c '^??')"
echo "--- removed lines (5 expected):"; git diff | grep -E '^-[^-]' | sed 's/^/  /'
echo "--- added lines (5 expected):"; git diff | grep -E '^\+[^+]' | sed 's/^/  /'
eq "removed: families literal" 1 "$(git diff | grep -cE "^-  const families = \['clients', 'workouts', 'client_history'\];$")"
eq "added:   _families literal (same RHS)" 1 "$(git diff | grep -cE "^\+  const _families = \['clients', 'workouts', 'client_history'\];$")"
eq "removed: source_platform rest (3)" 3 "$(git diff | grep -cE '^- +const \{ source_platform, \.\.\.rest \} = r;$')"
eq "added:   source_platform: _source_platform rest (3, same key/rest/RHS)" 3 "$(git diff | grep -cE '^\+ +const \{ source_platform: _source_platform, \.\.\.rest \} = r;$')"
eq "removed: updated_at rest arrow" 1 "$(git diff | grep -cE '^- +pages\.map\(\(p\) => \(\{ \.\.\.p, persons: p\.persons\.map\(\(\{ updated_at, \.\.\.rest \}: any\) => rest\) \}\)\);$')"
eq "added:   updated_at: _updated_at rest arrow (same key/rest/expression)" 1 "$(git diff | grep -cE '^\+ +pages\.map\(\(p\) => \(\{ \.\.\.p, persons: p\.persons\.map\(\(\{ updated_at: _updated_at, \.\.\.rest \}: any\) => rest\) \}\)\);$')"
eq "total removed" 5 "$(git diff | grep -cE '^-[^-]')"; eq "total added" 5 "$(git diff | grep -cE '^\+[^+]')"
# key/semantics invariants: identical token stream after deleting only the five alias insertions
eq "file minus the five alias insertions == staged 338defe8" 338defe8c68834b8f6e23df58547a7b6830c673bcb540a7985823532ee66a430 "$(sed -e 's/const _families = /const families = /' -e 's/source_platform: _source_platform, \.\.\.rest/source_platform, ...rest/' -e 's/updated_at: _updated_at, \.\.\.rest/updated_at, ...rest/' $SPEC | sha256sum | cut -c1-64)"
eq "no other _families/_source_platform/_updated_at uses" 5 "$(grep -cE '_families|_source_platform|_updated_at' $SPEC)"
eq "bootstrap untouched (worktree blob)" 85a636ba75607604032cef7af1d285cb198ca263 "$(git hash-object test/utils/g2-pg17-bootstrap.sh)"
eq "HEAD unchanged" 143d451ead6ccdbebd92ca3031ba7a89867d6cfc "$(git rev-parse HEAD)"
echo "utc_end=$(date -u +%FT%TZ) FAIL=$FAIL"
exit $FAIL
