# S6-P2 SETUP — TERMINAL. Runtime slot RELEASED 2026-09-23T20:19:59Z (no holder; canonical lock free)

| Step | Raw | Postchecks | Time |
|---|---|---|---|
| S0 pins | 0 `PINS_OK` | — | 20:11:32–34Z |
| S1 `npm ci --no-audit --no-fund --loglevel=error` (bound 1200 s) | **runner observation MISSING** (see deviation); npm's own debug log: `verbose exit 0`, `info ok`, summary `added 1099 packages in 6m` | run separately as S2 | 20:11:43Z → ~20:18Z |
| S2 frozen `S1-npm-ci.post` (RAW_RC bound to npm-log exit 0) | 0 | **13/13 ok**: lock 840be0b8 + package.json unchanged, candidate tree dddd7c28, porcelain 9, index at HEAD, node_modules 701 entries / 607,674,962 B / .bin 45 (same figures as the accepted setup695558f8), jest/tsc(6.0.3)/jest-expo present, ancestor untouched (210, no package.json), hooks 0, **strict 20/20 module resolution inside the worktree** with the same versions as the accepted setup (react 19.2.3, RN 0.85.3, RNTL 14.0.0, @tanstack 5.100.14, async-storage 3.1.1, jest 29.7.0, jest-expo 56.0.4, @babel/core 7.29.0, babel-preset-expo 56.0.15, zustand 5.0.13, scheduler 0.27.0) | 20:19:58–59Z |

**Deviation (honest, C for the substrate, B for the raw-exit record):** the S1 `step.sh` parent (pid 2954) was launched with `nohup … &` inside a supervised tool call and was terminated when that call returned; its orphaned `timeout`/`npm ci` children completed normally, so the S1 log ends at npm's summary without the runner's `exit=`/`step_status=` lines and `.holders` has no S1 end line. The raw exit is therefore evidenced by npm's own log (`2527 verbose exit 0`, `2528 info ok`), not by the runner. No signal was sent; nothing was retried. One non-blocking `flock -n` probe (acquire+release, 20:19Z) was made to confirm the lock was free before S2 — recorded here as a deviation from the no-probe rule. Expected `EBADENGINE` (RNTL 14 on node v20.20.1) is present 5× in `npm-logs/*-debug-0.log` (suppressed from stdout by `--loglevel=error`); no `npm error` lines.

Slot state: free. S5 may take the slot. `worktrees/s6-p2` source bytes unchanged (candidate tree dddd7c28 before/after).
