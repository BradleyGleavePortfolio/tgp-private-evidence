# S6-P2 SETUP — frozen command (written BEFORE execution, 2026-09-23T20:11:27Z)

Grant: parent mail 13:09 PDT (S5 released the sole slot 20:07:25Z). Scope: minimal new-environment dependency recovery in `worktrees/s6-p2` only — NOT tests/tsc/hazard/hooks/commit. Alternative chosen: the documented simpler one (S6_VALIDATION_PREPARATION.md §1): one `npm ci` under the accepted S5 `step.sh` pattern with the canonical lock; the 23-line setup-launcher adaptation is NOT used. No control/harness reinvention, no pristine fixture, no C6.

Runner: `steps/step.sh` = sealed s6-preparation/steps/step.sh with only constant substitutions (O,P → s6-p2-setup; W → worktrees/s6-p2; label 'S6-P2 slot-S'); `steps/step.sh.diff-vs-sealed-p1` shows the whole delta. Lock `/home/user/workspace/execution/test-validation.lock` (`flock -n`, refuse 75 if held), `timeout --kill-after=30`, raw exit recorded separately from postchecks, holders receipts.

| Step | Command file | T | Expected raw | Writes |
|---|---|---|---|---|
| S0 pins | `steps/S0-pins.cmd` (static pins: HEAD d51, tree 62bf67b8, candidate tree dddd7c28, nine porcelain lines, index at HEAD, lock 840be0b8 / blob 6c56385d, package.json 63e2e2e2, nine `cmp` vs s6-p2/candidate, s6-p2 MANIFEST 1cf14b97, node_modules ABSENT, hooks 0, identity unset, env clean) | 60 | 0, `PINS_OK` | `logs/S0-pins.log`, `scratch/ctree.index`, lock file + `.holders` |
| S1 npm ci | `steps/S1-npm-ci.cmd` = `npm ci --no-audit --no-fund --loglevel=error --logs-dir=$O/npm-logs --logs-max=10 < /dev/null` (offline=0; env from step.sh: CI=1 NODE_OPTIONS=--max-old-space-size=2048 TZ=UTC npm_config_{update_notifier,fund,audit}=false CHECKPOINT_DISABLE=1) | **1200** | 0; expected retained warnings: `EBADENGINE` for @testing-library/react-native@14.0.0 on node v20.20.1 (no Node upgrade), deprecation notices | `worktrees/s6-p2/node_modules/**` (gitignored), `logs/S1-npm-ci.log`, `npm-logs/`, `logs/setup.module-paths.txt` |
| S1 post | `steps/S1-npm-ci.post`: raw 0; lock/package.json unchanged; candidate tree still dddd7c28; porcelain still 9; index at HEAD; node_modules + jest/tsc/jest-expo present; ancestor /home/user/{package.json absent, node_modules 210} untouched; hooks 0; **strict 20-module resolution** with the exact list/body of the accepted v101y runner (L269–275); counts of EBADENGINE/deprecated/`npm error` lines recorded | — | postchecks_exit in the S1 log |

Stop rule: any nonzero raw other than 0 on S1, 75/78, 124/137, or postcheck FAIL → stop, preserve everything, report; no repeat of an unchanged command. On completion: seal `MANIFEST.sha256`, release slot (the lock is released by `flock -u` at each step end; no holder remains).

Frozen hashes (`SETUP_COMMAND.sha256`):
12e45addcbd37d7ba3e369c8467d7fbb552f86f3cefbf9fe1453fe2d800a80c7  steps/S0-pins.cmd
7971d8fb12f85ac5b7a51a5719f9cf7e975c02bd26c810e79b0f11f21de6d572  steps/S1-npm-ci.cmd
5277bb040d0f4794779c681186dde6e5fc5cbea41b29165971b4a1665ca3a6d9  steps/S1-npm-ci.post
47eb70dd6d93a2b985e2b0f7601cceb624467de774848edd6c36fc9a1259c9f3  steps/step.sh
6eb8b0bc3622f72906db0436692f676185bbff0e9cc504c6b0f58bb0536e6364  steps/step.sh.diff-vs-sealed-p1
