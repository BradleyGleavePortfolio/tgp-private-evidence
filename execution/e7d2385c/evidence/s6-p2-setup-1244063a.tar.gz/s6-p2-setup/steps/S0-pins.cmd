set -e
[ "$(git rev-parse HEAD)" = d51a191098f483cea9abec6cc7e9f3beffd18c06 ]; [ "$(git rev-parse HEAD^{tree})" = 62bf67b88e0f123f1a23ee34a1a75cb43029d9fb ]
[ "$(ctree)" = dddd7c2872b4f9e52b2bb4382b4456d1ea3ea402 ]
[ "$(git status --porcelain --untracked-files=all | sort | tr '\n' ';')" = " M App.tsx; M src/navigation/RootNavigator.tsx; M src/services/__tests__/queryClient.persister.test.ts; M src/services/__tests__/queryClient.signout.test.ts; M src/services/authActions.ts; M src/services/queryClient.ts;?? src/__tests__/rootNavigatorPersistedCacheGate.test.tsx;?? src/services/PersistedQueryCacheGate.tsx;?? src/services/__tests__/persistedQueryCache.identityGate.test.tsx;" ]
[ "$(git diff --cached --name-only | wc -l)" = 0 ]   # real index still at HEAD
[ "$(git ls-files -s package-lock.json | awk '{print substr($2,1,8)}')" = 6c56385d ]   # lock blob pin (prefix, as recorded in S6-P1 READY_PINS)
[ "$(sha256sum package-lock.json | cut -c1-64)" = 840be0b8d5f4ed8272afd20290c8ebf6f6dacc394e6edae4ae5403e9fabe6b69 ]; [ "$(sha256sum package.json | cut -c1-64)" = 63e2e2e2327b5a305fd184c0737ff4eea91f2283e8aa5d313041bffbdf130d5f ]
for f in $(git diff-tree -r --name-only d51a191098f483cea9abec6cc7e9f3beffd18c06 dddd7c2872b4f9e52b2bb4382b4456d1ea3ea402); do cmp -s "$f" /home/user/workspace/execution/e7d2385c/s6-p2/candidate/$f || { echo "candidate byte drift: $f"; exit 92; }; done
(cd /home/user/workspace/execution/e7d2385c/s6-p2 && sha256sum -c --quiet MANIFEST.sha256 && [ "$(sha256sum MANIFEST.sha256 | cut -c1-64)" = 1cf14b97eb856b4dbd8e98ba53d2da25fd7abe47733cd042d3dda3d93454db6a ])
test ! -d node_modules; test ! -e /home/user/package.json; test ! -e $O/QUARANTINE
[ "$(ls .git/hooks | grep -vc '\.sample$')" = 0 ]; [ -z "$(git config --get core.hooksPath)" ]; [ -z "$(git config --local --get user.name)" ]
env | grep -E '^(S5X_|LEFTHOOK|HUSKY)' && exit 94 || true
echo "lockfileVersion=$(grep -m1 '"lockfileVersion"' package-lock.json)"; echo "node=$(node -v) node_path=$(command -v node) npm=$(npm -v) npm_path=$(command -v npm)"
echo "ancestor_node_modules_entries=$(ls -A /home/user/node_modules 2>/dev/null | wc -l) npm_cache=$(npm config get cache) registry=$(npm config get registry)"
echo "disk_avail=$(df -h --output=avail /home/user/workspace | tail -1 | tr -d ' ') mem_avail_mb=$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo)"
git for-each-ref; git log -1 --format='%H %an <%ae> %cn <%ce>'; echo PINS_OK
