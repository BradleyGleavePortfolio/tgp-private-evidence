# Deviation record: the S1 step.sh parent (pid 2954) was terminated by the builder's tool supervisor when the launching tool call returned;
# the orphaned `timeout`/`npm ci` children completed (npm summary in S1 log, npm debug log 'verbose exit 0' / 'info ok'), but step.sh never
# wrote its exit/step_status lines or ran the postchecks. This step runs the FROZEN S1-npm-ci.post unchanged, binding RAW_RC to npm's own
# recorded exit code (not a runner observation). No second npm command.
NPMLOG=$(ls -1 $O/npm-logs/*-debug-0.log | head -1); NPM_EXIT=$(awk '/verbose exit /{print $NF}' "$NPMLOG" | tail -1)
echo "npm_debug_log=$NPMLOG npm_log_exit=$NPM_EXIT npm_log_ok=$(grep -c '^[0-9]* info ok' "$NPMLOG") npm_summary=$(grep -m1 'added .* packages' $O/logs/S1-npm-ci.log)"
echo "raw_runner_observation=MISSING (step.sh parent terminated; see S1 log lacking exit=/step_status= lines and .holders lacking the end line)"
RAW_RC=$NPM_EXIT bash $O/steps/S1-npm-ci.post
