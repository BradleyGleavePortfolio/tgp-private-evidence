npm ci --no-audit --no-fund --loglevel=error --logs-dir="$O/npm-logs" --logs-max=10 < /dev/null
