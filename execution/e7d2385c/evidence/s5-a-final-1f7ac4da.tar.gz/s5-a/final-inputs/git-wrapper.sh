#!/bin/sh
# ASI CLI wrapper v7 for git
__asi_real=""
for __d in /usr/local/bin /usr/bin; do
    if [ -x "$__d/.git-real" ]; then __asi_real="$__d/.git-real"; break; fi
done
if [ -z "$__asi_real" ]; then
    echo "git: real binary not found" >&2
    exit 127
fi
__asi_start_ns=$(date +%s%N)
__asi_stderr_file=""
__asi_tmp_dir=""
if command -v mktemp >/dev/null 2>&1 && command -v mkfifo >/dev/null 2>&1 && command -v tee >/dev/null 2>&1; then
    __asi_tmp_dir=$(mktemp -d "${TMPDIR:-/tmp}/asi-cli.XXXXXX" 2>/dev/null || true)
fi
if [ -n "$__asi_tmp_dir" ] && mkfifo "$__asi_tmp_dir/stderr.fifo" 2>/dev/null; then
    __asi_stderr_file="$__asi_tmp_dir/stderr"
    # tee reads a FIFO instead of sitting in a pipeline so the wrapper waits on
    # the CLI's exit, not on pipe EOF — a background child that inherits the
    # CLI's stderr (e.g. a credential daemon) keeps the FIFO open and would
    # otherwise hang the wrapper. The watchdog bounds the post-exit drain.
    tee "$__asi_stderr_file" <"$__asi_tmp_dir/stderr.fifo" >&2 &
    __asi_tee_pid=$!
    "$__asi_real" "$@" 2>"$__asi_tmp_dir/stderr.fifo"
    __asi_exit=$?
    (sleep 1; kill "$__asi_tee_pid" 2>/dev/null) </dev/null >/dev/null 2>&1 &
    wait "$__asi_tee_pid" 2>/dev/null
else
    "$__asi_real" "$@"
    __asi_exit=$?
fi
if command -v asi-cli-telemetry >/dev/null 2>&1 && command -v jq >/dev/null 2>&1; then
    __asi_stderr=""
    if [ "$__asi_exit" -ne 0 ] && [ -n "$__asi_stderr_file" ] && [ -s "$__asi_stderr_file" ]; then
        __asi_stderr=$(tail -c 4096 "$__asi_stderr_file" 2>/dev/null || cat "$__asi_stderr_file" 2>/dev/null || true)
    fi
    # This CLI's agent-proxy session token, read from the env var whose name is
    # baked in at render time (build_cli_env_vars / cli_session_token_env_var).
    # Omitted from the payload when unset so non-credentialed CLIs are unaffected.
    __asi_session_token="${ASI_CLI_SESSION_TOKEN_GITHUB_MCP_DIRECT:-}"
    __asi_payload=$(jq -cn \
        --arg source_id github_mcp_direct \
        --argjson exit_code "$__asi_exit" \
        --argjson start_ns "$__asi_start_ns" \
        --arg command "$*" \
        --arg stderr "$__asi_stderr" \
        --arg session_token "$__asi_session_token" \
        '{source_id:$source_id,exit_code:$exit_code,start_ns:$start_ns,command:$command,stderr:$stderr}
         + (if $session_token == "" then {} else {session_token:$session_token} end)')
    # asi_exec may terminate this wrapper's process group the moment it exits.
    # SIG_IGN (unlike handlers) survives fork+exec, so installing it here — after
    # the real CLI has run — lets the detached recorder bounce that SIGTERM and
    # setsid out of the group before the delayed SIGKILL sweep.
    trap '' TERM HUP INT
    (setsid asi-cli-telemetry record "$__asi_payload" </dev/null >/dev/null 2>&1 &) >/dev/null 2>&1
fi
if [ -n "$__asi_tmp_dir" ]; then
    rm -rf "$__asi_tmp_dir"
fi
exit "$__asi_exit"
