# S6-A-P2-B04 closure map (test-only; runtime proof pending the accepted bounded validation)

CLASS B. Harm: identity suite's delayed storage implementations captured `AsyncStorage.getItem/setItem.bind(AsyncStorage)` AFTER `beforeEach` had replaced those methods with spies, so "delegating" re-entered the spy; the deferred-read unit test then armed a second unreleased Promise (hang), and the new unmount test counted its own KEY_B fixture seed as a forbidden write (deterministic false). Decision blocked: identity-suite acceptance proof only.

Minimum closure — `p2-to-p3.patch`, one file, three mechanical changes, all delays/releases/assertions retained:
1. **Delegate to the underlying mock implementation** (`AsyncStorageMemoryImpl` arrow-field methods of the pinned async-storage 3.1.1 Jest mock; not `jest.fn`, so `spyOn` wraps and `restoreAllMocks` restores them). `beforeEach` now captures `realGetItem`/`realSetItem` via `.bind(AsyncStorage)` BEFORE `jest.spyOn`; the ten in-test captures (five `realGet` at former lines 153/234/394/436/474, five `realSet` at 206/280/318/496/520) become `const realGet = realGetItem;` / `const realSet = realSetItem;` — bodies, guards (`!releaseA`, `!releaseWrite`), delays and releases unchanged.
2. **Baseline fixture writes** in the S6-A-01 unmount test: `const seededWrites = setItemSpy.mock.calls.length;` immediately after the KEY_A/KEY_B seeds; the post-boundary assertion becomes `setItemSpy.mock.calls.slice(seededWrites).filter(KEY_B) === []`. The count-based `writesAtUnmount` assertion and KEY_B read assertions are unchanged (no KEY_B read occurs before them).
3. **Deferred-read test** (`retire() before the read resolves…`): the held read is guarded `k === KEY_A && release === null`, so the release cannot arm a second wait even if the key is read again; combined with (1) the awaited `restoring` settles to `'retired'`.

Not changed: product bytes (A01/A02 closures at P2 stand), harness, acceptance criteria (19 intended cases), other suites, the RNTL `await`s, timers/fake-timer policy, hazard files. No new framework.

Remaining A/B known to the builder: none in scope. C (recorded, not edits): fixture seeds in other tests also pass through the spy but their assertions already baseline by count or by key-not-seeded; the `afterEach` anonymous-key criterion is unaffected (no test seeds the anonymous key).
