# S6-P3 test-only successor — exact pins (frozen 2026-09-23T20:2xZ; static copy/diff/hash only; nothing executed)

Grant: `S6_P3_TEST_CORRECTION.md` (CLASS B, S6-A-P2-B04). Input: frozen P2 packet `1cf14b97…` `candidate/` (copied, not the live worktree). Live `worktrees/s6-p2` NOT touched (porcelain 9, no object written); `s6-p2/**`, `s6-inputs/**`, `s6-preparation/**` immutable.

| Pin | Value |
|---|---|
| Baseline HEAD / tree | `d51a191098f483cea9abec6cc7e9f3beffd18c06` / `62bf67b88e0f123f1a23ee34a1a75cb43029d9fb` |
| P1 tree / P2 tree | `845d83ad5731f86b34bfca2ca67142c98498165f` / `dddd7c2872b4f9e52b2bb4382b4456d1ea3ea402` |
| **P3 candidate tree** | **`93ed7cfc4d0b8095148e0020ca40f901833595f6`** (scratch repo: `git archive d51` → `s6-p2/p2-product.patch` → reproduces dddd7c28 → P3 test file → write-tree) |
| `p2-to-p3.patch` (one file, 132 lines, visible manual patch) | sha256 `493a3ba2c2d3a07c197191491a30b547f10ff62b2d0fce804d6a7a4d532e9f92`; applies onto the frozen P2 `candidate/` and yields the P3 file byte-for-byte |
| `p3-product.patch` (d51 → P3, 1748 lines) | sha256 `17b68dc95852ec1b339cb0ab74010eae6288507ed7c1d865ce08bae985444c7c` |
| Changed blob | `src/services/__tests__/persistedQueryCache.identityGate.test.tsx` P2 `5192c842…` → **P3 `24640114cd391d7b658d8df8fe111f52e1327c46`** (+22 −12; file sha256 `62a02340350e89699ae43e57c07137bc186efa194bc2e0240fb701eaeb45badd`) |
| Eight other files | byte-identical to frozen P2 (`cmp` 8/8): App 55bf758e, RootNavigator b028ba5e, rootNavGate.test 536f57dc, persister.test 49477d3d, signout.test 77fa75c8, authActions 8bb68bff, queryClient 53f752d3, PersistedQueryCacheGate c41d176f — no product byte changed |
| Unchanged input pins | lock `840be0b8…`, package.json `63e2e2e2…`, hazard `a91bb732…`, adapter `3796be8f…` |

Static `it(` count in the identity suite: 19 (unchanged). `logs/diff-tree-*.txt`, `logs/numstat-*.txt`, `candidate/` (9 files).
