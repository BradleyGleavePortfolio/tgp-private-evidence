# S6 review B — final head/result attestation (same review; additive; no frozen bytes changed)

Reviewer B, lifecycle/integration priority, non-builder. No runtime, no source-audit restart, no new tests or criteria, no peer conclusions read. All repository queries read-only (`GIT_OPTIONAL_LOCKS=0`); the bundle test used throw-away scratch repositories only.

## 1. Exact final boundary (independently re-derived from the live repository)

| Item | Value |
|---|---|
| HEAD (detached) | `bc7b4e96fc1db54568bc209dbe1f7a4121501ac9` |
| tree | `acb41c2baab6e856573d86e02135430c3304828b` (= r2 pinned tree, ten paths) |
| parent | `d51a191098f483cea9abec6cc7e9f3beffd18c06` (baseline) |
| author / committer | `Bradley Gleave <bradley@bradleytgpcoaching.com>` both, `1790198630 +0000` (= 2026-09-23T21:23:50Z), no gpgsig, no trailers |
| message | byte-equal to sealed `s6-r2-validation/steps/21-commit-message.txt` (`06e7ae2d…`); banned-token grep 0 |
| commit object sha256 | `3394a52455f915482adefa9b26216bc2c801e97c0b77bce7e3f6f625a68a5ac6` |
| refs | exactly `refs/heads/main a5933fd6…`, `refs/restored/execute/20260921-s6-r3 d51a1910…` (unchanged); repository is shallow-rooted at `a5933fd6…` |
| porcelain | 0 lines (`--untracked-files=all`); `package-lock.json` `840be0b8…` |
| diff-tree d51→HEAD | exactly the ten blob pairs of the sealed step-22 expectation (`bac96bb7→55bf758e`, `+aa74a383`, `ca834fe3→0beaf7b0`, `3b5217da→b028ba5e`, `+c41d176f`, `+31d740c4`, `8377a44d→49477d3d`, `82ee0208→77fa75c8`, `386a7802→8bb68bff`, `8a3f2820→53f752d3`); numstat as re-derived in `RUNTIME_QUALIFICATION_R2_09-23_BINDING.md` §3 |
| HEAD blobs vs r2 candidate bytes | 10/10 identical (`git hash-object` of `s6-observed-test-fix-r2/candidate/*`) |
| bundle | `s6-r2-validation-result/bundle/s6-r2-bc7b4e96-from-public-a5933fd6.bundle` sha256 `85836076cc1a99211153a5ad292415e72dd130299ec9dcb13458fec788efccf7`; `git bundle verify` okay; one head `bc7b4e96… HEAD`; one prerequisite `a5933fd6…` |
| result packet | `s6-r2-validation-result/MANIFEST.sha256` sha256 `a9a580da029d008f661f8fdb28954a3ab6ac6cd5ddb7fb98f444d3a14309177f`, 36/36 OK |
| release | `RUNTIME_RELEASE.txt`: heavy slot released 2026-09-23T21:24:12Z after 20–23 terminal; lock free |

Independent bundle test: in a fresh repository seeded only with public `main` (`a5933fd6…`, fetched `--update-shallow`; `bc7b4e96…` and `d51a1910…` absent beforehand), `git bundle unbundle` supplied `bc7b4e96…` (commit), `acb41c2b…` (tree) and `d51a1910…`; range `a5933fd6..bc7b4e96` = 16 commits (15 public-ahead baseline commits + 1); commit object sha256 `3394a524…` reproduced; all ten HEAD blobs `cmp`-equal to the r2 candidate; full-tree `diff-tree d51..HEAD` = exactly 10 paths.

## 2. Steps 20–23 receipts, read against the frozen criteria

- **20** `exit=0`; staged tree (real index) `acb41c2b…`; worktree == index; untracked 0; hazard copies absent; strict post 1 solely `staged paths expected=9 actual=10` — the stale nine-path literal I identified in `RUNTIME_QUALIFICATION_R2_09-23_BINDING.md` §4; the ten staged paths are exactly the pinned set. Preserved as a strict failure; dispositioned by the parent as a criterion artifact (`S6_R2_VALIDATION_DISPOSITION.md`), which is the option I named. Not a proof defect.
- **21** ran the successor command (message literal `06e7ae2d…`, tree literal `acb41c2b…`); identities matched; `hooks about to run: [] core.hooksPath=[]`; `git commit -F -` → `[detached HEAD bc7b4e9]`, `10 files changed, 1455 insertions(+), 91 deletions(-)` (sum of the re-derived numstat: 1455/91); `exit=0`, `step_status=0`.
- **22** 13/13 post-checks rc=0 (`%T`, `%P`, author, committer, trailers, message, porcelain, banned tokens, detached, ten blobs, numstat, refs, lock); `identity.txt` matches §1; `step_status=0`.
- **23** bundle created, verified, listed, hashed `85836076…`; `exit=0`, `step_status=0`.

## 3. Transfer of prior qualifications to this boundary (unchanged, no restart)

- **Source (P1→P2→P3→r2):** the committed tree `acb41c2b…` is byte-identical to the r2 tree I re-derived by pure hashing in `R2_REPORT.md`; P1 verdict SOURCE-CLOSED/GRANTABLE (14 C), P2 closures A01/A02/A03 and S6-B-P2-01 as conditional C (`P2_REACHABILITY_DISPOSITION.md`), P3 B04 closure, r2 test-only mechanics (A:0 B:0 C:2) all attach to this head without change. No product byte changed after P2.
- **Runtime (r2 00–09):** 00–05 pass; 02 19/19, 03 4/4, 04 5/5, 05 4/4; 06 25/25 raw 0 with two criterion-pattern artifacts (`todo` matching `legacy-code-todo-rewrite` in the stack of a test-injected warning; one `did not exit` line with bounded self-exit ≈1–3 s, owner unidentified); 08 hazard 3F/3P at `:188/:208/:240`, T-WIRING/T0/T4 pass, normal exit, mode-header count artifact; 09 hash-guarded cleanup. Per `RUNTIME_QUALIFICATION_R2_00-08.md`.
- **Binding (20–23):** per `RUNTIME_QUALIFICATION_R2_09-23_BINDING.md`; the single mechanical mismatch (step-20 literal) materialized exactly as predicted and affected no staged content.

## 4. Attestation

Head `bc7b4e96…` (tree `acb41c2b…`, parent `d51a1910…`) is the exact boundary this review's source and runtime qualifications apply to; bundle `85836076…` carries that commit and nothing else beyond the public prerequisite. Open items remain C only: step-06 residual handle (bounded, unidentified owner), the three criterion-text artifacts (06 `todo` alternative, 08 mode-header count, 20 nine-path literal), S6-B-P2-01 conditional C, and the carry-forward C list. No A or B finding is open against this head. No further cycle is requested by this review.

Sealed: `MANIFEST.final.sha256` (this file + `final/inputs-read.sha256`); all earlier packets re-verified at sealing time.
