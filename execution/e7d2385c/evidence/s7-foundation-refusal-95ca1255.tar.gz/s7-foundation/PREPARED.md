# S7-1′ foundation composition — PREPARED (source-only; awaiting parent activation after dual S5 acceptance)

Builder s5_exact_candidate_continuation (T4, requested Claude Fable 5 / High). Nothing merged, checked out, installed or committed yet. Original S5 worktree `worktrees/s5-r4` untouched (still HEAD `98d39610`, clean, under final attestation). No remote/product push planned.

## 1. Exact parents (both imported from hash-verified bundles into the isolated store `worktrees/s7-foundation` — refs only, no checkout)
| parent | commit | tree | source | identity |
|---|---|---|---|---|
| P1 accepted S3 | `be0ba8274e486dee77f15d18fe367a13ff08ecf5` | `a584a1b95423f95dae8daabf673ef3776604acbb` | `s7-mapping/s3-overlap/s3-into-s1s2-be0ba827-from-public-c23b9d9.bundle` sha256 `d204a582…2d7b` | author=committer Bradley, no trailers |
| P2 final S5 | `98d39610f511505558373f3a59fa019804c94bd7` | `67fc1db5f353f0d363fe7134a78d455c0decfb55` | `s5-continuation/candidate/bundle/s5-r4-hooked-98d39610-from-public-c23b9d9f.bundle` sha256 `e624facc…1dc9fb` | author=committer Bradley, no trailers |
Store: `git init` + depth-1 public fetch of baseline `c23b9d9f` (remote removed; same layout as S5's R1) + both bundles; refs `refs/heads/main=c23b9d9f`, `refs/s7/s3-be0ba827`, `refs/s7/s5-98d39610`; shallow boundary c23b9d9f; 0 remotes (`logs/setup-store.log`). Merge base `925780e0a1906593e5383c618311b6b17364b8dc`; 25 S3-only / 11 S5-only commits.

## 2. Predicted result (`PREDICTION.txt`, `git merge-tree --write-tree`)
- **Clean**: rc 0, 0 conflict lines. **Predicted tree `c54386ec52a0c01050be4316f70efc45f5f13cc0`.**
- Consistency: `be0ba827 × 143d451e` reproduces the addendum's `0f3a27ff…` exactly; S3-only paths ∩ S5-only paths (vs 925780e0) = 0.
- Delta vs P1: 31 files = S5's E/T-Q0 product bytes (`prisma/schema.prisma`, migration `20270118000000_scout_ledger_platform_expand`, `src/scout/*`, `scripts/importer-contract.ts`, `docs/contracts/importer-openapi.json`, decisions) + S5 tests/harness. Delta vs P2: 49 files = S3's S1/S2 substrate. No authored change.
- Manifests identical on P1, P2 and predicted tree: `package.json 656d11a2`, **`package-lock.json 354de3da`**, `lefthook.yml 54d03749`, `tsconfig.json 93f3baab`, `eslint.config.js 78aa2b64`. `prisma/schema.prisma` = P2's `a5412353` (S5's E schema; S3 had the base `341bd148`) — the S5-generated client already matches it.

## 3. Dependencies: reuse, no fresh install, no mutation of S5
Lockfile identical → **copy** S5's installed tree once: `cp -a /home/user/workspace/worktrees/s5-r4/node_modules /home/user/workspace/worktrees/s7-foundation/node_modules` (717 MB incl. generated client + engine `a2924eab…`; 7.3 G free), then verify `node_modules/.package-lock.json` sha256 = `05bc530a…7b44`. The copy reads S5 only; S5's deps/client are never written. The copied `.bin/prettier` symlink points to the pinned Prettier 3.9.6 tooling under `s5-continuation/tooling/` (read-only reuse, exact pin `6e922134…`). No npm/prisma generate.

## 4. Bounded normal merge + hooks (single activation; each step waited, raw status recorded; stop on unexpected failure, no retry/bypass/amend)
```
cd /home/user/workspace/worktrees/s7-foundation
git checkout -q --detach be0ba8274e486dee77f15d18fe367a13ff08ecf5              # P1 checked out; porcelain must be empty
cp -a /home/user/workspace/worktrees/s5-r4/node_modules ./node_modules && sha256sum node_modules/.package-lock.json   # 05bc530a…
git config --local user.name "Bradley Gleave"; git config --local user.email bradley@bradleytgpcoaching.com
./node_modules/.bin/lefthook install                                           # real pre-commit + commit-msg, hooksPath unset
git merge --no-ff --no-commit refs/s7/s5-98d39610                              # expect: clean, no conflicts
test "$(git write-tree)" = c54386ec52a0c01050be4316f70efc45f5f13cc0            # tree guard before committing
LEFTHOOK_VERBOSE=1 git commit -F /home/user/workspace/execution/e7d2385c/s7-foundation/07-merge-message.txt   # runs pre-commit (prod-readiness-quick, banned-cast-tokens, prettier, eslint, tsc) + commit-msg (no-ai-tokens)
```
Frozen message `07-merge-message.txt` sha256 `d94f24fd…` (0 banned tokens). Post-checks: `HEAD^1 = be0ba827`, `HEAD^2 = 98d39610`, `HEAD^{tree} = c54386ec…`, author = committer Bradley, `%(trailers)` empty, porcelain empty, hooks files unchanged; then `git bundle create s7-foundation-<sha>-from-public-c23b9d9f.bundle c23b9d9f..HEAD` + verify. Receipt under `execution/e7d2385c/s7-foundation/**`.

## 5. Needed runtime
Ordinary bounded runtime, no database, no network: node_modules copy ≈ 1–2 min; hooks ≈ 1–2 min (tsc ≈ 50 s, eslint/prettier on 31 staged files); bound 600 s for the commit step. Not the heavy PG slot, but CPU-bound (tsc) — parent to schedule so it does not overlap another CPU-bound lane. No new PG proof; no S3/S5 acceptance rerun; no tests beyond the hooks' own checks.

## 6. Hook outcomes that would be recorded, not bypassed
- `banned-cast-tokens` (`scripts/check-r75.js --mode=staged`) compares staged vs P1: the staged product bytes are PR528/529's (already public and inside S5's range check `c23b..98d net 0`); a positive delta here would be a real refusal to report.
- `tsc --noEmit` typechecks the composed tree against the S5-generated client (schema identical to the predicted tree).
- `prod-readiness-quick` is a no-op only if `scripts/prod-readiness-precheck.sh` is absent on the composed tree (it is absent on both parents).
Any refusal → stop, report smallest boundary; no retry unchanged.

## 7. Not done now
No checkout, copy, install, hook install, merge, commit, bundle, push. `worktrees/s5-r4`, `/home/user/pg17/clusters/s5` (retained stopped fixture), all sealed packets untouched.
