#!/usr/bin/env bash
# persistent bounded commit step (prepared §4); waited by sentinel
cd /home/user/workspace/worktrees/s7-foundation || exit 74
export GIT_OPTIONAL_LOCKS=0 LEFTHOOK_VERBOSE=1
L=/home/user/workspace/execution/e7d2385c/s7-foundation/logs
echo "COMMIT_START $(date -u +%FT%TZ) pid=$$ bound=600s" > $L/06-commit.log
timeout -k 30 600 git commit -F /home/user/workspace/execution/e7d2385c/s7-foundation/07-merge-message.txt >> $L/06-commit.log 2>&1
rc=$?
echo "COMMIT_END $(date -u +%FT%TZ) rc=$rc" >> $L/06-commit.log
echo "COMMIT_RC=$rc END=$(date -u +%FT%TZ)" > $L/06-commit.sentinel
