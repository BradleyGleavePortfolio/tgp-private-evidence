# S7-1′ foundation composition — actual result: HOOK REFUSAL, no commit created (stopped, retained)

Builder s5_exact_candidate_continuation (T4). Activated by parent 20:53Z under PREPARED.md `ea0d3322`. Slot released 20:58:57Z. No bypass, amend, retry, source edit, install, network, PG/Jest, product push. S5 worktree/deps/client and stopped fixture unchanged (HEAD `98d39610`, porcelain 0, `05bc530a`).

## Steps (raw, `logs/`)
| step | result |
|---|---|
| 1 checkout `--detach be0ba827` | rc 0, porcelain 0 |
| 2 `cp -a` S5 node_modules → s7 (read-only on S5) | rc 0, 54,182 files, `.package-lock.json` `05bc530a…7b44` (= S5), prettier link → pinned 3.9.6 tooling |
| 3 Bradley local identity; `lefthook install` | rc 0; hooks `pre-commit`/`commit-msg` real, hooksPath unset (hook bytes differ from S5's only by the embedded worktree path) |
| 4 `git merge --no-ff --no-commit refs/s7/s5-98d39610` | rc 0, "Automatic merge went well", 0 conflicts, 31 staged files |
| 5 tree guard | `git write-tree` = **`c54386ec52a0c01050be4316f70efc45f5f13cc0`** = predicted |
| 6 `git commit -F 07-merge-message.txt` (persistent launch `06-commit-launch.sh` `d5f492e2…`, bound 600 s) | **rc 1** after 65.8 s — lefthook pre-commit: ✔ prod-readiness-quick, ✔ banned-cast-tokens (R75 `--cached`), ✔ eslint (4.99 s); **✖ prettier** (3.52 s); **✖ tsc** (65.74 s, exit 134). commit-msg not reached. |

## Exact refusals (`REFUSAL_DIAG.txt`, read-only)
1. **prettier `--check`** (pinned Prettier 3.9.6, repo has no prettier in package.json/lock, no `.prettierrc`): `[warn] src/scout/scout-cursor.ts` (46 diff lines vs formatter output) and `[warn] src/scout/scout-platform.ts` (8 lines). Both blobs are byte-identical in PR529 head `d7404cd4`, S5 `98d39610` and the staged index (`492ecd18`, `ea8c0e94`) — S5-lane product bytes that no accepted hook run ever formatted-checked (S5 07R staged only its two test files; S3 never touched `src/scout`). Delta is formatting-only (parenthesised multi-line boolean returns).
2. **tsc `--noEmit`**: `FATAL ERROR: Ineffective mark-compacts near heap limit … JavaScript heap out of memory`, heap limit 2096 MB (node v20.20.1 default; `NODE_OPTIONS` unset in my prepared command). The accepted S5 and S3 hook runs both exported `NODE_OPTIONS=--max-old-space-size=4096` (S5 `07R-identity-and-hooked-commit.log`, S3 step headers) — an environment omission in PREPARED.md §4 relative to the reviewed lanes, not a type error (none reported before the OOM). Composed tree has 1,640 `.ts` files (S3 1,627 / S5 1,637).

## Retained state (not touched further)
`worktrees/s7-foundation`: HEAD `be0ba827`, `MERGE_HEAD` `98d39610`, index tree `c54386ec`, 0 unstaged, 0 untracked, 0 commits created, 0 leftover processes. Store refs unchanged.

## Concrete minimum corrections (parent disposition required; nothing done)
- tsc: rerun the identical commit step with the reviewed lane environment `NODE_OPTIONS=--max-old-space-size=4096` (plus the same offline npm flags) — environment only, no source change.
- prettier: a formatting decision on two PR528/529 product files — either a formatter-only reformat (would be an authored, review-visible change like S5's accepted formatter-only test delta) or an explicit disposition on how PR528/529 bytes pass the pinned formatter. Not the builder's call.
