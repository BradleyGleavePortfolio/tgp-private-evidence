import { GdprScrubService } from '../src/users/gdpr-scrub.service';
import { AuditAction } from '../src/audit/audit.service';
import { DELETION_GRACE_PERIOD_DAYS } from '../src/users/account.service';

// PII-scrub worker tests. The worker is the second half of the GDPR
// delete lifecycle and writes `deleted_at`/zeroes out identifying
// columns. These tests pin:
//
//   - Cutoff arithmetic: a user 29 days into the grace window is NOT a
//     candidate; one 30+ days in IS.
//   - Dry-run never writes.
//   - Real run tombstones email + name + phone + supabase_id, sets
//     `deleted_at` AND `archived_at`, and writes exactly one
//     `user.account_deleted` audit row per scrubbed user with the
//     original email captured in metadata.
//   - One bad user does not poison the rest of the batch.

const DAY_MS = 24 * 60 * 60 * 1000;

function buildPrisma(seedUsers: any[]) {
  const state: {
    users: any[];
    profiles: Record<string, any>;
    aiDrafts: any[];
    coachBriefPushLedger: any[];
    coachBriefPreferences: any[];
    coachDailyLog: any[];
    coachBrief: any[];
  } = {
    users: seedUsers.map((u) => ({ ...u })),
    profiles: {},
    aiDrafts: [],
    coachBriefPushLedger: [],
    coachBriefPreferences: [],
    coachDailyLog: [],
    coachBrief: [],
  };

  const userTable = {
    findMany: jest.fn(async ({ where, take, orderBy }: any) => {
      const rows = state.users.filter((u) => {
        if (u.deleted_at) return false;
        if (!u.deletion_scheduled_at) return false;
        const cutoff = where?.deletion_scheduled_at?.lte;
        if (cutoff && u.deletion_scheduled_at > cutoff) return false;
        return true;
      });
      if (orderBy?.deletion_scheduled_at === 'asc') {
        rows.sort(
          (a, b) =>
            a.deletion_scheduled_at.getTime() -
            b.deletion_scheduled_at.getTime(),
        );
      }
      return rows.slice(0, take ?? rows.length).map((u) => ({
        id: u.id,
        email: u.email,
        deletion_scheduled_at: u.deletion_scheduled_at,
      }));
    }),
    update: jest.fn(async ({ where, data }: any) => {
      const idx = state.users.findIndex((u) => u.id === where.id);
      if (idx < 0) throw new Error(`user not found ${where.id}`);
      Object.assign(state.users[idx], data);
      return state.users[idx];
    }),
  };

  const userProfile = {
    updateMany: jest.fn(async ({ where, data }: any) => {
      const profile = state.profiles[where.user_id];
      if (profile) Object.assign(profile, data);
      return { count: profile ? 1 : 0 };
    }),
  };

  const notificationPreferences = {
    updateMany: jest.fn(async () => ({ count: 0 })),
  };

  const aIDraft = {
    deleteMany: jest.fn(async ({ where }: any) => {
      const before = state.aiDrafts.length;
      state.aiDrafts = state.aiDrafts.filter(
        (d) => d.clientId !== where.clientId,
      );
      return { count: before - state.aiDrafts.length };
    }),
  };

  const coachBriefPushLedger = {
    deleteMany: jest.fn(async ({ where }: any) => {
      const before = state.coachBriefPushLedger.length;
      state.coachBriefPushLedger = state.coachBriefPushLedger.filter(
        (r: any) => r.coach_id !== where.coach_id,
      );
      return { count: before - state.coachBriefPushLedger.length };
    }),
  };

  const coachBriefPreferences = {
    deleteMany: jest.fn(async ({ where }: any) => {
      const before = state.coachBriefPreferences.length;
      state.coachBriefPreferences = state.coachBriefPreferences.filter(
        (r: any) => r.coach_id !== where.coach_id,
      );
      return { count: before - state.coachBriefPreferences.length };
    }),
  };

  const coachDailyLog = {
    deleteMany: jest.fn(async ({ where }: any) => {
      const before = state.coachDailyLog.length;
      state.coachDailyLog = state.coachDailyLog.filter(
        (r: any) => r.coach_id !== where.coach_id,
      );
      return { count: before - state.coachDailyLog.length };
    }),
  };

  const coachBrief = {
    deleteMany: jest.fn(async ({ where }: any) => {
      const before = state.coachBrief.length;
      state.coachBrief = state.coachBrief.filter(
        (r: any) => r.coach_id !== where.coach_id,
      );
      return { count: before - state.coachBrief.length };
    }),
  };

  const $transaction = jest.fn(async (cb: any) =>
    cb({
      user: userTable,
      userProfile,
      notificationPreferences,
      aIDraft,
      coachBriefPushLedger,
      coachBriefPreferences,
      coachDailyLog,
      coachBrief,
    }),
  );

  return {
    state,
    user: userTable,
    userProfile,
    notificationPreferences,
    aIDraft,
    coachBriefPushLedger,
    coachBriefPreferences,
    coachDailyLog,
    coachBrief,
    $transaction,
  };
}

function buildAudit() {
  return { write: jest.fn(async () => {}), list: jest.fn(async () => []) } as any;
}

describe('GdprScrubService', () => {
  const NOW = new Date('2026-04-28T12:00:00.000Z');
  const TWENTY_NINE_DAYS_AGO = new Date(NOW.getTime() - 29 * DAY_MS);
  const THIRTY_ONE_DAYS_AGO = new Date(NOW.getTime() - 31 * DAY_MS);
  const FORTY_DAYS_AGO = new Date(NOW.getTime() - 40 * DAY_MS);

  const baseUsers = () => [
    {
      id: 'u-fresh',
      email: 'fresh@example.test',
      name: 'Fresh User',
      phone: '555-0001',
      supabase_id: 'sup-fresh',
      deletion_scheduled_at: TWENTY_NINE_DAYS_AGO,
      deleted_at: null,
      archived_at: null,
    },
    {
      id: 'u-ripe',
      email: 'ripe@example.test',
      name: 'Ripe User',
      phone: '555-0002',
      supabase_id: 'sup-ripe',
      deletion_scheduled_at: THIRTY_ONE_DAYS_AGO,
      deleted_at: null,
      archived_at: null,
    },
    {
      id: 'u-old',
      email: 'old@example.test',
      name: 'Old User',
      phone: '555-0003',
      supabase_id: 'sup-old',
      deletion_scheduled_at: FORTY_DAYS_AGO,
      deleted_at: null,
      archived_at: null,
    },
    {
      id: 'u-already-scrubbed',
      email: 'deleted-prev@scrub.invalid',
      name: 'Deleted user',
      phone: null,
      supabase_id: 'deleted-prev',
      deletion_scheduled_at: FORTY_DAYS_AGO,
      deleted_at: new Date(NOW.getTime() - 10 * DAY_MS),
      archived_at: new Date(NOW.getTime() - 10 * DAY_MS),
    },
    {
      id: 'u-not-scheduled',
      email: 'active@example.test',
      name: 'Active User',
      phone: '555-0004',
      supabase_id: 'sup-active',
      deletion_scheduled_at: null,
      deleted_at: null,
      archived_at: null,
    },
  ];

  it('selects only users past the 30-day cutoff (oldest first), skipping fresh and already-scrubbed', async () => {
    const prisma: any = buildPrisma(baseUsers());
    const svc = new GdprScrubService(prisma, buildAudit());
    const candidates = await svc.findCandidates(NOW, 100);
    expect(candidates.map((c) => c.user_id)).toEqual(['u-old', 'u-ripe']);
    // Verifies the cutoff math is exactly grace-period days, not "29.x".
    expect(candidates[0].scheduled_for_purge_at.getTime()).toBe(
      candidates[0].deletion_scheduled_at.getTime() +
        DELETION_GRACE_PERIOD_DAYS * DAY_MS,
    );
  });

  it('dry-run reports candidates without writing or auditing', async () => {
    const prisma: any = buildPrisma(baseUsers());
    const audit = buildAudit();
    const svc = new GdprScrubService(prisma, audit);
    const report = await svc.run({ dryRun: true, now: NOW });
    expect(report.dry_run).toBe(true);
    expect(report.scrubbed).toBe(0);
    expect(report.considered).toBe(2);
    expect(prisma.user.update).not.toHaveBeenCalled();
    expect(prisma.$transaction).not.toHaveBeenCalled();
    expect(audit.write).not.toHaveBeenCalled();
  });

  it('real run tombstones PII and writes one audit row per scrubbed user', async () => {
    const prisma: any = buildPrisma(baseUsers());
    const audit = buildAudit();
    const svc = new GdprScrubService(prisma, audit);

    const report = await svc.run({ dryRun: false, now: NOW });
    expect(report.dry_run).toBe(false);
    expect(report.scrubbed).toBe(2);
    expect(report.errors).toEqual([]);

    const scrubbedRipe = prisma.state.users.find((u: any) => u.id === 'u-ripe');
    expect(scrubbedRipe.email).toBe('deleted-u-ripe@scrub.invalid');
    expect(scrubbedRipe.name).toBe('Deleted user');
    expect(scrubbedRipe.phone).toBeNull();
    expect(scrubbedRipe.supabase_id).toBe('deleted-u-ripe');
    expect(scrubbedRipe.archived_at).toEqual(NOW);
    expect(scrubbedRipe.deleted_at).toEqual(NOW);

    // Fresh user untouched.
    const fresh = prisma.state.users.find((u: any) => u.id === 'u-fresh');
    expect(fresh.email).toBe('fresh@example.test');
    expect(fresh.deleted_at).toBeNull();

    // One audit row per scrubbed user, action and metadata pinned.
    expect(audit.write).toHaveBeenCalledTimes(2);
    const calls = audit.write.mock.calls.map((c: any[]) => c[0]);
    expect(calls.every((c: any) => c.action === AuditAction.USER_ACCOUNT_DELETED)).toBe(true);
    expect(calls.every((c: any) => c.metadata.scope === 'gdpr_scrub_worker')).toBe(true);
    // Original email captured in metadata for forensic traceability —
    // operators can map a tombstoned id back to the legal request.
    expect(
      calls.find((c: any) => c.targetUserId === 'u-ripe').metadata
        .original_email_snapshot,
    ).toBe('ripe@example.test');
  });

  it('attributes cron-driven runs to actor=null + actorRole=system', async () => {
    const prisma: any = buildPrisma(baseUsers());
    const audit = buildAudit();
    const svc = new GdprScrubService(prisma, audit);
    await svc.run({ dryRun: false, now: NOW });
    const first = audit.write.mock.calls[0][0];
    expect(first.actorId).toBeNull();
    expect(first.actorRole).toBe('system');
  });

  it('attributes operator-triggered runs to the OWNER who invoked them', async () => {
    const prisma: any = buildPrisma(baseUsers());
    const audit = buildAudit();
    const svc = new GdprScrubService(prisma, audit);
    await svc.run({
      dryRun: false,
      now: NOW,
      actorUserId: 'owner-1',
      actorEmail: 'owner@example.test',
    });
    const first = audit.write.mock.calls[0][0];
    expect(first.actorId).toBe('owner-1');
    expect(first.actorRole).toBe('owner');
    expect(first.actorEmail).toBe('owner@example.test');
  });

  it('records per-user errors without short-circuiting the batch', async () => {
    const prisma: any = buildPrisma(baseUsers());
    const audit = buildAudit();
    // Make the first scrub fail with a transaction error; the second
    // still runs to completion. Mirrors the real-world case where one
    // user has a stray FK that needs operator intervention.
    let firstSeen = false;
    prisma.$transaction.mockImplementation(async (cb: any) => {
      if (!firstSeen) {
        firstSeen = true;
        throw new Error('simulated tx failure for first candidate');
      }
      return cb({
        user: prisma.user,
        userProfile: prisma.userProfile,
        notificationPreferences: prisma.notificationPreferences,
        aIDraft: prisma.aIDraft,
        coachBriefPushLedger: prisma.coachBriefPushLedger,
        coachBriefPreferences: prisma.coachBriefPreferences,
        coachDailyLog: prisma.coachDailyLog,
        coachBrief: prisma.coachBrief,
      });
    });
    const svc = new GdprScrubService(prisma, audit);
    const report = await svc.run({ dryRun: false, now: NOW });
    expect(report.considered).toBe(2);
    expect(report.scrubbed).toBe(1);
    expect(report.errors.length).toBe(1);
    expect(report.errors[0].user_id).toBe('u-old');
    // Only the surviving candidate gets an audit row.
    expect(audit.write).toHaveBeenCalledTimes(1);
  });

  it('clamps batch limit to [1, 1000]', async () => {
    const prisma: any = buildPrisma(baseUsers());
    const svc = new GdprScrubService(prisma, buildAudit());
    await svc.run({ dryRun: true, now: NOW, limit: -5 });
    expect(prisma.user.findMany).toHaveBeenLastCalledWith(
      expect.objectContaining({ take: 1 }),
    );
    await svc.run({ dryRun: true, now: NOW, limit: 99999 });
    expect(prisma.user.findMany).toHaveBeenLastCalledWith(
      expect.objectContaining({ take: 1000 }),
    );
  });

  // Regression: A1-C3-P1-1 — AIDraft.inputContext retains health PII
  // (name, age, sex, biometrics, dietary restrictions, injuries, check-in
  // notes) after a GDPR erasure request because the scrubber issues a
  // soft-delete (no physical DELETE on User) so the clientId FK cascade
  // never fires. scrubOne must explicitly delete AIDraft rows inside the
  // same transaction, before tombstoning the User row.
  it('scrubOne deletes AIDraft rows belonging to the scrubbed client inside the transaction (A1-C3-P1-1)', async () => {
    const prisma: any = buildPrisma(baseUsers());
    // Pre-seed two drafts for u-ripe (scrub candidate) and one for u-old.
    prisma.state.aiDrafts = [
      { id: 'draft-1', clientId: 'u-ripe', inputContext: { name: 'Ripe', injuries: ['knee'] } },
      { id: 'draft-2', clientId: 'u-ripe', inputContext: { name: 'Ripe', dietary_restrictions: ['vegan'] } },
      { id: 'draft-3', clientId: 'u-old',  inputContext: { name: 'Old',  age_years: 45 } },
    ];
    const audit = buildAudit();
    const svc = new GdprScrubService(prisma, audit);

    await svc.run({ dryRun: false, now: NOW });

    // aIDraft.deleteMany must have been called once per scrubbed user
    // with the correct clientId WHERE clause.
    expect(prisma.aIDraft.deleteMany).toHaveBeenCalledTimes(2);
    expect(prisma.aIDraft.deleteMany).toHaveBeenCalledWith({
      where: { clientId: 'u-old' },
    });
    expect(prisma.aIDraft.deleteMany).toHaveBeenCalledWith({
      where: { clientId: 'u-ripe' },
    });

    // All drafts for the scrubbed clients are removed from the table.
    expect(prisma.state.aiDrafts).toHaveLength(0);

    // The call must happen INSIDE the transaction — verify deleteMany was
    // called on the tx-scoped aIDraft object, not the top-level prisma one.
    // The $transaction mock forwards the tx object, so prisma.aIDraft.deleteMany
    // IS the same ref passed to the callback — this assertion confirms it was
    // called as part of each transaction invocation.
    const txCalls = prisma.$transaction.mock.calls;
    expect(txCalls.length).toBe(2); // one tx per scrubbed candidate
  });

  // Regression: A1-PR266-P1-1 — Coach Brief PII survives soft-delete scrub.
  // The four Coach Brief tables (CoachBriefPushLedger, CoachBriefPreferences,
  // CoachDailyLog, CoachBrief) all declare coach_id → User.id onDelete:
  // Cascade, but the cascade never fires because the scrubber issues a
  // soft-delete rather than a physical DELETE. CoachBrief.narrative and
  // action_items are LLM free text that may include the coach's first name
  // and per-client first names; CoachBrief.brief_context is a Json blob
  // aggregating client names, weight deltas, and message previews;
  // CoachDailyLog.content is free text the coach writes about clients.
  // All four must be hard-deleted inside the scrub transaction.
  it('scrubOne deletes all four Coach Brief tables for the scrubbed coach inside the transaction (A1-PR266-P1-1)', async () => {
    const prisma: any = buildPrisma(baseUsers());

    // Pre-seed rows for both scrub candidates (u-old and u-ripe) and one
    // row for the non-candidate u-fresh to verify isolation.
    prisma.state.coachBriefPushLedger = [
      { id: 'ledger-1', coach_id: 'u-old',  last_push_date: '2026-04-01' },
      { id: 'ledger-2', coach_id: 'u-ripe', last_push_date: '2026-04-10' },
      { id: 'ledger-3', coach_id: 'u-fresh', last_push_date: '2026-04-20' },
    ];
    prisma.state.coachBriefPreferences = [
      { id: 'prefs-1', coach_id: 'u-old',  notification_time: '05:00', timezone: 'UTC' },
      { id: 'prefs-2', coach_id: 'u-ripe', notification_time: '07:00', timezone: 'America/New_York' },
    ];
    prisma.state.coachDailyLog = [
      { id: 'log-1', coach_id: 'u-old',  content: 'Client A lost 2 lbs this week.' },
      { id: 'log-2', coach_id: 'u-ripe', content: 'Client B checked in — mood improved.' },
      { id: 'log-3', coach_id: 'u-ripe', content: 'Client C skipped workouts.' },
    ];
    prisma.state.coachBrief = [
      {
        id: 'brief-1',
        coach_id: 'u-old',
        narrative: 'Coach Old had a strong week with Client A.',
        brief_context: { clients: [{ name: 'Client A', weight_delta: -2 }] },
        action_items: ['Follow up with Client A on nutrition'],
      },
      {
        id: 'brief-2',
        coach_id: 'u-ripe',
        narrative: 'Coach Ripe noted mood improvement in Client B.',
        brief_context: { clients: [{ name: 'Client B', mood: 'good' }] },
        action_items: ['Check in with Client B tomorrow'],
      },
    ];

    const audit = buildAudit();
    const svc = new GdprScrubService(prisma, audit);
    await svc.run({ dryRun: false, now: NOW });

    // Each deleteMany must be called once per scrubbed candidate (2 users).
    expect(prisma.coachBriefPushLedger.deleteMany).toHaveBeenCalledTimes(2);
    expect(prisma.coachBriefPreferences.deleteMany).toHaveBeenCalledTimes(2);
    expect(prisma.coachDailyLog.deleteMany).toHaveBeenCalledTimes(2);
    expect(prisma.coachBrief.deleteMany).toHaveBeenCalledTimes(2);

    // Correct WHERE clause for each scrubbed coach.
    expect(prisma.coachBriefPushLedger.deleteMany).toHaveBeenCalledWith({ where: { coach_id: 'u-old' } });
    expect(prisma.coachBriefPushLedger.deleteMany).toHaveBeenCalledWith({ where: { coach_id: 'u-ripe' } });
    expect(prisma.coachBriefPreferences.deleteMany).toHaveBeenCalledWith({ where: { coach_id: 'u-old' } });
    expect(prisma.coachBriefPreferences.deleteMany).toHaveBeenCalledWith({ where: { coach_id: 'u-ripe' } });
    expect(prisma.coachDailyLog.deleteMany).toHaveBeenCalledWith({ where: { coach_id: 'u-old' } });
    expect(prisma.coachDailyLog.deleteMany).toHaveBeenCalledWith({ where: { coach_id: 'u-ripe' } });
    expect(prisma.coachBrief.deleteMany).toHaveBeenCalledWith({ where: { coach_id: 'u-old' } });
    expect(prisma.coachBrief.deleteMany).toHaveBeenCalledWith({ where: { coach_id: 'u-ripe' } });

    // All seeded rows for the scrubbed coaches are physically removed.
    expect(prisma.state.coachBriefPushLedger).toHaveLength(1); // u-fresh row survives
    expect(prisma.state.coachBriefPushLedger[0].coach_id).toBe('u-fresh');
    expect(prisma.state.coachBriefPreferences).toHaveLength(0);
    expect(prisma.state.coachDailyLog).toHaveLength(0);
    expect(prisma.state.coachBrief).toHaveLength(0);

    // Calls must happen inside the transaction — one tx per candidate.
    expect(prisma.$transaction.mock.calls).toHaveLength(2);
  });
});
