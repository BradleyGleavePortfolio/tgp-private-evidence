import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService } from '@nestjs/config';
import {
  NotFoundException,
  ServiceUnavailableException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { PrismaService } from '../src/prisma.service';
import {
  StripeConnectApiError,
  StripeConnectApiService,
} from '../src/connect/stripe-connect-api.service';
import { SupabaseService } from '../src/supabase/supabase.service';
import { GuestCheckoutService } from '../src/storefront/guest-checkout.service';
import { NotificationsService } from '../src/notifications/notifications.service';
import { CheckoutService } from '../src/checkout/checkout.service';
import { FeePolicyService } from '../src/connect/fees/fee-policy.service';

// R43 — GuestCheckoutService tests. Prisma, Stripe, and Supabase are all
// mocked. We test: package resolution, idempotency (replay path), Stripe
// 503 surfacing, recurring rejection (P1-3), handlePaymentSucceeded
// idempotency, handlePaymentFailed, durable conversion (P1-4),
// listUsers pagination beyond page 1 (P1-5), expires_at gating (P2-4),
// and destination account persistence (P2-5).

const IDEMP_KEY = '550e8400-e29b-41d4-a716-446655440000';

function makePkg(overrides: Record<string, unknown> = {}) {
  return {
    id: 'pkg-1',
    coach_id: 'coach-1',
    amount_cents: 29700,
    currency: 'usd',
    billing_type: 'one_time',
    is_active: true,
    archived_at: null,
    published_at: new Date('2026-01-01'),
    share_token: 'tok123',
    share_link_enabled: true,
    coach: {
      id: 'coach-1',
      name: 'Coach McCoach',
      connect_account: {
        stripe_account_id: 'acct_x',
        charges_enabled: true,
        payouts_enabled: true,
        details_submitted: true,
        disabled_reason: null,
      },
    },
    ...overrides,
  };
}

const baseDto = {
  guest_name: 'Jane Smith',
  guest_email: 'jane@example.com',
  idempotency_key: IDEMP_KEY,
};

interface PrismaMocks {
  coachPackage: { findUnique: jest.Mock };
  coachLandingPage: { findFirst: jest.Mock };
  guestCheckout: {
    findUnique: jest.Mock;
    create: jest.Mock;
    update: jest.Mock;
    updateMany: jest.Mock;
    deleteMany: jest.Mock;
  };
  user: {
    findUnique: jest.Mock;
    create: jest.Mock;
    update: jest.Mock;
    upsert: jest.Mock; // r48 #12 — atomic upsert path
  };
  clientPurchase: {
    findFirst: jest.Mock;
    create: jest.Mock;
    // A276-P1-4 — refund handler revokes entitlement on the
    // matching ClientPurchase row via updateMany.
    updateMany: jest.Mock;
  };
  connectAccount: { findUnique: jest.Mock };
  $transaction: jest.Mock;
}

function buildPrismaMocks(): PrismaMocks {
  const mocks: PrismaMocks = {
    coachPackage: { findUnique: jest.fn() },
    coachLandingPage: { findFirst: jest.fn() },
    guestCheckout: {
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      // A276-P1-2 — default to no-op so unrelated tests keep passing.
      // handleChargeRefunded may emit two updateMany calls (the initial
      // refunded_at stamp and the partial→full status upgrade); tests
      // that don't override the default see a benign count:0 for both.
      updateMany: jest.fn().mockResolvedValue({ count: 0 }),
      deleteMany: jest.fn().mockResolvedValue({ count: 0 }),
    },
    user: {
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      // r48 #12 — convertGuestToUser now uses tx.user.upsert.  Default
      // behaviour matches the old (findUnique → create) path: return
      // the freshly-stubbed user row on first call.
      upsert: jest.fn(),
    },
    clientPurchase: {
      findFirst: jest.fn(),
      create: jest.fn(),
      // A276-P1-4 — default to no-op so unrelated tests keep passing.
      updateMany: jest.fn().mockResolvedValue({ count: 0 }),
    },
    connectAccount: {
      findUnique: jest.fn().mockResolvedValue({ stripe_account_id: 'acct_x' }),
    },
    $transaction: jest.fn(),
  };
  // $transaction(cb) calls cb with `tx` — wire it through to the same
  // jest mocks so callers can assert on tx.<model>.<method> invocations.
  mocks.$transaction.mockImplementation((cb: (tx: unknown) => unknown) =>
    cb(mocks),
  );
  return mocks;
}

describe('GuestCheckoutService', () => {
  let service: GuestCheckoutService;
  let prisma: PrismaMocks;
  let stripe: {
    createPaymentIntent: jest.Mock;
    retrievePaymentIntent: jest.Mock;
    // A276-P0-2 — retrieveCharge resolves the Stripe-hosted receipt_url
    // when the webhook payload didn't carry it expanded.
    retrieveCharge: jest.Mock;
  };
  let supabaseAdminMock: {
    createUser: jest.Mock;
    listUsers: jest.Mock;
    generateLink: jest.Mock;
  };
  // A276-P1-4 — NotificationsService mock. Refund + dispute handlers
  // surface coach-facing alerts via createNotification; we capture the
  // call to assert on body/kind/payload.
  let notifications: { createNotification: jest.Mock };

  beforeEach(async () => {
    prisma = buildPrismaMocks();
    stripe = {
      createPaymentIntent: jest.fn(),
      retrievePaymentIntent: jest.fn(),
      // A276-P0-2 — default to a no-charge response so existing tests
      // (which don't care about receipt_url) keep passing.
      retrieveCharge: jest.fn().mockResolvedValue({ id: 'ch_default', receipt_url: null }),
    };
    notifications = {
      createNotification: jest.fn().mockResolvedValue({ id: 'notif-1' }),
    };
    supabaseAdminMock = {
      createUser: jest.fn(),
      listUsers: jest.fn(),
      // Audit #3 P1-9 — invite-link flow. Default to returning a
      // canonical Supabase action_link so the happy-path tests don't
      // have to wire it up individually.
      generateLink: jest.fn().mockResolvedValue({
        data: {
          properties: {
            action_link:
              'https://supabase.example.com/auth/v1/verify?token=abc&type=invite',
          },
        },
        error: null,
      }),
    };
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        GuestCheckoutService,
        { provide: PrismaService, useValue: prisma },
        { provide: StripeConnectApiService, useValue: stripe },
        {
          provide: SupabaseService,
          useValue: {
            getClient: () => ({
              auth: { admin: supabaseAdminMock },
            }),
          },
        },
        { provide: ConfigService, useValue: { get: () => undefined } },
        // A276-P1-4 — inject the notifier so refund/dispute tests can
        // assert on coach alerts. @Optional() in the service keeps
        // legacy hand-built test modules valid.
        { provide: NotificationsService, useValue: notifications },
        // PR-14 R2 P2-1 — CheckoutService + FeePolicyService are now HARD
        // deps on GuestCheckoutService so a wiring regression fails at
        // boot. The legacy non-recurring tests below never exercise the
        // recurring code path, so the stubs only need to be present, not
        // functional.
        {
          provide: CheckoutService,
          useValue: {
            ensurePriceForPackage: jest.fn(),
            ensureRecurringPriceForPackage: jest.fn(),
          },
        },
        {
          provide: FeePolicyService,
          useValue: {
            planFor: jest.fn(),
          },
        },
      ],
    }).compile();
    service = module.get(GuestCheckoutService);
  });

  describe('createIntent', () => {
    it('404s when the token does not resolve', async () => {
      prisma.coachPackage.findUnique.mockResolvedValueOnce(null);
      await expect(service.createIntent('bad', baseDto)).rejects.toThrow(
        NotFoundException,
      );
    });

    // PR-14 — master-plan §1 decision #1 puts recurring back on the
    // storefront. The previous A3-P1-5 422 RECURRING_NOT_SUPPORTED guard
    // is gone. The dedicated PR-14 spec block in
    // test/pr14-guest-recurring-lp-attribution.spec.ts wires the full
    // CheckoutService + FeePolicyService stubs and exercises the
    // happy-path mint, idempotent replay, combo, etc.
    // Here we just assert the legacy 422 no longer fires AND the
    // one-time PI path is NOT taken (the recurring branch is followed
    // instead — it'll fail downstream because the legacy CheckoutService
    // stub returns undefined from ensurePriceForPackage, but that's the
    // point: the guard isn't blocking anymore).
    it('does NOT reject recurring packages on the OLD A3-P1-5 422 path (PR-14 lifted the guard)', async () => {
      prisma.coachPackage.findUnique.mockResolvedValueOnce(
        makePkg({ billing_type: 'recurring', interval: 'month', interval_count: 1 }),
      );
      prisma.guestCheckout.findUnique.mockResolvedValue(null);
      prisma.guestCheckout.create.mockResolvedValueOnce({ id: 'gc-rec-old' });
      // The recurring branch is now taken (no UnprocessableEntityException
      // for billing_type=recurring); the legacy stub-thin CheckoutService
      // surfaces a downstream error rather than the 422 it used to.
      await expect(service.createIntent('tok123', baseDto)).rejects.not.toThrow(
        UnprocessableEntityException,
      );
      // The one-time PaymentIntent path is NOT taken for recurring.
      expect(stripe.createPaymentIntent).not.toHaveBeenCalled();
    });

    // Display labels in the interval column must never gate the
    // recurring guard. A `one_time` package with interval='month' is
    // still a one-off charge.
    it('allows one_time packages even when interval columns look monthly', async () => {
      prisma.coachPackage.findUnique.mockResolvedValueOnce(
        makePkg({ billing_type: 'one_time', interval: 'month', interval_count: 1 }),
      );
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(null);
      prisma.guestCheckout.create.mockResolvedValueOnce({
        id: 'gc-1',
        idempotency_key: baseDto.idempotency_key,
        package_id: 'pkg-1',
        stripe_payment_intent_id: `pending_${baseDto.idempotency_key}`,
        status: 'pending',
        guest_email: baseDto.guest_email.toLowerCase(),
      });
      stripe.createPaymentIntent.mockResolvedValueOnce({
        id: 'pi_xyz',
        client_secret: 'pi_xyz_secret',
      });
      prisma.guestCheckout.update.mockResolvedValueOnce({});
      await expect(service.createIntent('tok123', baseDto)).resolves.toMatchObject({
        payment_intent_id: 'pi_xyz',
      });
    });

    // Audit #6 P0-5 — landing_page_id propagation.
    describe('landing_page_id propagation (P0-5)', () => {
      const VALID_LP = 'cl1234567890abcdefghij';
      const otherCoachLP = 'cl0000000000xxxxxxxxxx';

      function wirePaymentSuccess() {
        prisma.coachPackage.findUnique.mockResolvedValueOnce(makePkg());
        prisma.guestCheckout.findUnique.mockResolvedValueOnce(null);
        prisma.guestCheckout.create.mockImplementationOnce(
          async (args: { data: Record<string, unknown> }) => ({
            id: 'gc-lp',
            ...args.data,
          }),
        );
        stripe.createPaymentIntent.mockResolvedValueOnce({
          id: 'pi_lp',
          client_secret: 'pi_lp_secret',
        });
        prisma.guestCheckout.update.mockResolvedValueOnce({});
      }

      it('writes landing_page_id when the page belongs to the package coach AND lists the package', async () => {
        wirePaymentSuccess();
        prisma.coachLandingPage.findFirst.mockResolvedValueOnce({
          id: VALID_LP,
          package_ids: ['pkg-1', 'pkg-2'],
        });
        await service.createIntent('tok123', baseDto, VALID_LP);
        const createCall = prisma.guestCheckout.create.mock.calls[0][0];
        expect(createCall.data.landing_page_id).toBe(VALID_LP);
      });

      it('clears landing_page_id when the page belongs to a DIFFERENT coach', async () => {
        wirePaymentSuccess();
        prisma.coachLandingPage.findFirst.mockResolvedValueOnce(null);
        await service.createIntent('tok123', baseDto, otherCoachLP);
        const createCall = prisma.guestCheckout.create.mock.calls[0][0];
        expect(createCall.data.landing_page_id).toBeNull();
      });

      it('clears landing_page_id when the page does NOT list the package', async () => {
        wirePaymentSuccess();
        prisma.coachLandingPage.findFirst.mockResolvedValueOnce({
          id: VALID_LP,
          package_ids: ['pkg-other'],
        });
        await service.createIntent('tok123', baseDto, VALID_LP);
        const createCall = prisma.guestCheckout.create.mock.calls[0][0];
        expect(createCall.data.landing_page_id).toBeNull();
      });

      it('rejects malformed landing_page_id without querying the database', async () => {
        wirePaymentSuccess();
        await service.createIntent('tok123', baseDto, '../etc/passwd');
        expect(prisma.coachLandingPage.findFirst).not.toHaveBeenCalled();
        const createCall = prisma.guestCheckout.create.mock.calls[0][0];
        expect(createCall.data.landing_page_id).toBeNull();
      });

      it('leaves landing_page_id null when no lp param is given', async () => {
        wirePaymentSuccess();
        await service.createIntent('tok123', baseDto);
        expect(prisma.coachLandingPage.findFirst).not.toHaveBeenCalled();
        const createCall = prisma.guestCheckout.create.mock.calls[0][0];
        expect(createCall.data.landing_page_id).toBeNull();
      });
    });

    it('mints a Stripe PaymentIntent and persists the sentinel row', async () => {
      prisma.coachPackage.findUnique.mockResolvedValueOnce(makePkg());
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(null);
      prisma.guestCheckout.create.mockResolvedValueOnce({
        id: 'gc-1',
        idempotency_key: IDEMP_KEY,
      });
      stripe.createPaymentIntent.mockResolvedValueOnce({
        id: 'pi_xyz',
        client_secret: 'pi_xyz_secret',
      });
      prisma.guestCheckout.update.mockResolvedValueOnce({ id: 'gc-1' });
      const result = await service.createIntent('tok123', baseDto);
      expect(result.payment_intent_id).toBe('pi_xyz');
      expect(result.client_secret).toBe('pi_xyz_secret');
      expect(result.guest_checkout_id).toBe('gc-1');
      expect(stripe.createPaymentIntent).toHaveBeenCalledTimes(1);
      const call = stripe.createPaymentIntent.mock.calls[0][0];
      // Audit #4 P1-4 — platform 2% + Stripe pass-through (2.9% + 30¢).
      // 29700 × 0.02 = 594, 29700 × 0.029 = 861.3 → floor 861, plus 30¢
      // gives 1485.
      expect(call.applicationFeeAmount).toBe(1485);
      expect(call.metadata.guest_checkout_idempotency_key).toBe(IDEMP_KEY);
      expect(call.metadata.guest_checkout_id).toBe('gc-1');
      expect(call.metadata.package_id).toBe('pkg-1');
      // Audit #3 P2-4 — guest_email and guest_name MUST NOT appear in
      // Stripe metadata. Server-side join via guest_checkout_id when we
      // need them.
      expect(call.metadata.guest_email).toBeUndefined();
      expect(call.metadata.guest_name).toBeUndefined();
      // Audit #3 P1-10 — destination-charge PaymentIntents carry
      // on_behalf_of so the connected coach is the merchant of record.
      expect(call.onBehalfOf).toBe('acct_x');
      expect(call.transferDestination).toBe('acct_x');
      // P2-3 — `customer` must not be sent as an empty string for guest
      // PaymentIntents; omit it entirely.
      expect(call.customer).toBeUndefined();
    });

    it('clamps platform fee to Stripe minimum of 50¢ plus pass-through', async () => {
      // Audit #4 P1-4 — 2% of $5 (500¢) = 10¢ (below 50¢ floor → 50¢),
      // plus Stripe pass-through 500 × 0.029 = 14.5 → floor 14, plus 30¢.
      // 50 + 14 + 30 = 94¢.
      prisma.coachPackage.findUnique.mockResolvedValueOnce(
        makePkg({ amount_cents: 500 }),
      );
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(null);
      prisma.guestCheckout.create.mockResolvedValueOnce({ id: 'gc-2' });
      stripe.createPaymentIntent.mockResolvedValueOnce({
        id: 'pi_2',
        client_secret: 's2',
      });
      prisma.guestCheckout.update.mockResolvedValueOnce({});
      await service.createIntent('tok123', baseDto);
      expect(
        stripe.createPaymentIntent.mock.calls[0][0].applicationFeeAmount,
      ).toBe(94);
    });

    // Audit #4 P1-4/P1-5 — fee table for 2% + (2.9% + 30¢) pass-through,
    // clamped at the gross. Below the $0.50 minimum charge the request
    // is rejected up front; see the AMOUNT_BELOW_MIN test below.
    //   $1.00 (100¢): max(2,50)=50 + floor(2.9)+30=32 → 82¢
    //   $100  (10000): 200 + 290 + 30 = 520¢
    //   $50   (5000):  100 + 145 + 30 = 275¢
    it.each([
      [100, 82],
      [5000, 275],
      [10000, 520],
    ])(
      'P1-4 fee table: amount=%i cents → fee=%i cents',
      async (amount, expectedFee) => {
        prisma.coachPackage.findUnique.mockResolvedValueOnce(
          makePkg({ amount_cents: amount }),
        );
        prisma.guestCheckout.findUnique.mockResolvedValueOnce(null);
        prisma.guestCheckout.create.mockResolvedValueOnce({
          id: `gc-${amount}`,
        });
        stripe.createPaymentIntent.mockResolvedValueOnce({
          id: 'pi_x',
          client_secret: 's',
        });
        prisma.guestCheckout.update.mockResolvedValueOnce({});
        await service.createIntent('tok123', baseDto);
        const fee =
          stripe.createPaymentIntent.mock.calls[0][0].applicationFeeAmount;
        expect(fee).toBe(expectedFee);
      },
    );

    // Audit #3 P2-6 — Phase 1 storefront accepts USD only.
    it.each(['eur', 'gbp', 'jpy'])(
      'rejects non-USD packages (%s) with CURRENCY_NOT_SUPPORTED',
      async (currency) => {
        prisma.coachPackage.findUnique.mockResolvedValueOnce(
          makePkg({ currency }),
        );
        prisma.guestCheckout.findUnique.mockResolvedValue(null);
        await expect(service.createIntent('tok123', baseDto)).rejects.toThrow(
          UnprocessableEntityException,
        );
        expect(stripe.createPaymentIntent).not.toHaveBeenCalled();
      },
    );

    // Audit #4 P1-5 — Stripe rejects PaymentIntent.amount < 50¢ for USD.
    it.each([0, 1, 49])(
      'rejects amount %i¢ with AMOUNT_BELOW_MIN before Stripe',
      async (amount) => {
        prisma.coachPackage.findUnique.mockResolvedValueOnce(
          makePkg({ amount_cents: amount }),
        );
        prisma.guestCheckout.findUnique.mockResolvedValue(null);
        await expect(service.createIntent('tok123', baseDto)).rejects.toThrow(
          UnprocessableEntityException,
        );
        expect(stripe.createPaymentIntent).not.toHaveBeenCalled();
      },
    );

    // Audit #4 P1-5 — defence-in-depth ceiling.
    it('rejects amount > $50,000 with AMOUNT_ABOVE_MAX before Stripe', async () => {
      prisma.coachPackage.findUnique.mockResolvedValueOnce(
        makePkg({ amount_cents: 5_000_001 }),
      );
      prisma.guestCheckout.findUnique.mockResolvedValue(null);
      await expect(service.createIntent('tok123', baseDto)).rejects.toThrow(
        UnprocessableEntityException,
      );
      expect(stripe.createPaymentIntent).not.toHaveBeenCalled();
    });

    it('replays an existing pending intent without minting a new PaymentIntent', async () => {
      prisma.coachPackage.findUnique.mockResolvedValueOnce(makePkg());
      prisma.guestCheckout.findUnique.mockResolvedValueOnce({
        id: 'gc-existing',
        package_id: 'pkg-1',
        guest_email: 'jane@example.com',
        status: 'pending',
        stripe_payment_intent_id: 'pi_prior',
        expires_at: new Date(Date.now() + 10 * 60 * 1000),
      });
      stripe.retrievePaymentIntent.mockResolvedValueOnce({
        id: 'pi_prior',
        client_secret: 'pi_prior_secret',
      });
      const result = await service.createIntent('tok123', baseDto);
      expect(result.payment_intent_id).toBe('pi_prior');
      expect(stripe.createPaymentIntent).not.toHaveBeenCalled();
    });

    // P2-2 — A stale `pending_<key>` sentinel must not 503 the retry
    // forever. createIntent should treat it as a stale reservation,
    // delete it, and mint a fresh PaymentIntent for the same idempotency
    // key.
    it('recovers from a stale pending_ sentinel by minting a new PaymentIntent', async () => {
      prisma.coachPackage.findUnique.mockResolvedValueOnce(makePkg());
      prisma.guestCheckout.findUnique.mockResolvedValueOnce({
        id: 'gc-stale',
        package_id: 'pkg-1',
        guest_email: 'jane@example.com',
        status: 'pending',
        // The previous attempt crashed before Stripe responded.
        stripe_payment_intent_id: `pending_${IDEMP_KEY}`,
        expires_at: new Date(Date.now() + 10 * 60 * 1000),
      });
      prisma.guestCheckout.deleteMany.mockResolvedValueOnce({ count: 1 });
      prisma.guestCheckout.create.mockResolvedValueOnce({ id: 'gc-fresh' });
      stripe.createPaymentIntent.mockResolvedValueOnce({
        id: 'pi_new',
        client_secret: 'pi_new_secret',
      });
      prisma.guestCheckout.update.mockResolvedValueOnce({});
      const result = await service.createIntent('tok123', baseDto);
      expect(result.payment_intent_id).toBe('pi_new');
      expect(prisma.guestCheckout.deleteMany).toHaveBeenCalled();
      expect(stripe.createPaymentIntent).toHaveBeenCalledTimes(1);
    });

    it('marks the sentinel failed when Stripe rejects the PaymentIntent', async () => {
      prisma.coachPackage.findUnique.mockResolvedValueOnce(makePkg());
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(null);
      prisma.guestCheckout.create.mockResolvedValueOnce({ id: 'gc-3' });
      stripe.createPaymentIntent.mockRejectedValueOnce(
        new StripeConnectApiError(
          'card declined',
          402,
          'card_declined',
          'card_error',
        ),
      );
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      await expect(service.createIntent('tok123', baseDto)).rejects.toThrow(
        ServiceUnavailableException,
      );
      expect(prisma.guestCheckout.updateMany).toHaveBeenCalledWith({
        where: { id: 'gc-3', status: 'pending' },
        data: { status: 'failed' },
      });
    });
  });

  describe('handlePaymentSucceeded', () => {
    it('is a no-op when no pending row exists (idempotent duplicate webhook)', async () => {
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 0 });
      await service.handlePaymentSucceeded('pi_xyz');
      expect(prisma.guestCheckout.findUnique).not.toHaveBeenCalled();
    });

    // P2-4 — the atomic claim must reject rows whose checkout link has
    // already expired. A buyer holding a stale client secret cannot push
    // a paid status past expires_at.
    it('claims with expires_at gt now (P2-4)', async () => {
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 0 });
      await service.handlePaymentSucceeded('pi_xyz');
      const call = prisma.guestCheckout.updateMany.mock.calls[0][0];
      expect(call.where.expires_at).toBeDefined();
      expect(call.where.expires_at.gt).toBeInstanceOf(Date);
    });

    // P1-4 — conversion must complete INLINE before the webhook returns.
    // The previous setImmediate path acknowledged Stripe before account
    // creation finished, so a crash between the claim and conversion
    // dropped the entitlement.
    it('runs convertGuestToUser inline (durable) and writes ClientPurchase + destination account', async () => {
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      const checkoutRow = {
        id: 'gc-paid',
        package_id: 'pkg-1',
        package: {
          coach: { id: 'coach-1' },
          coach_id: 'coach-1',
          amount_cents: 29700,
          currency: 'usd',
          billing_type: 'one_time',
          name: 'Pack',
        },
        idempotency_key: IDEMP_KEY,
        guest_email: 'jane@example.com',
        guest_name: 'Jane',
        stripe_payment_intent_id: 'pi_xyz',
        stripe_customer_id: null,
        status: 'paid',
      };
      prisma.guestCheckout.findUnique
        .mockResolvedValueOnce(checkoutRow)
        .mockResolvedValueOnce(checkoutRow); // re-read inside convertGuestToUser
      supabaseAdminMock.createUser.mockResolvedValueOnce({
        data: { user: { id: 'sb-user-1' } },
        error: null,
      });
      prisma.connectAccount.findUnique.mockResolvedValueOnce({
        stripe_account_id: 'acct_dest',
      });
      prisma.user.findUnique.mockResolvedValueOnce(null);
      // r48 #12 — convertGuestToUser now uses tx.user.upsert.
      prisma.user.upsert.mockResolvedValueOnce({
        id: 'usr-1',
        coach_id: 'coach-1',
      });
      prisma.clientPurchase.findFirst.mockResolvedValueOnce(null);
      prisma.clientPurchase.create.mockResolvedValueOnce({ id: 'cp-1' });
      prisma.guestCheckout.update.mockResolvedValueOnce({ id: 'gc-paid' });

      await service.handlePaymentSucceeded('pi_xyz');

      // Inline conversion: ClientPurchase create called WITHIN the
      // webhook turn (no setImmediate).
      expect(prisma.clientPurchase.create).toHaveBeenCalledTimes(1);
      const purchaseArgs = prisma.clientPurchase.create.mock.calls[0][0];
      // P2-5 — destination account persisted for reconciliation.
      expect(purchaseArgs.data.stripe_destination_account).toBe('acct_dest');
      // Audit #3 P1-9 — Supabase createUser MUST NOT include a password
      // and MUST NOT confirm the email up-front. The buyer verifies by
      // clicking the invite link.
      const createUserArgs = supabaseAdminMock.createUser.mock.calls[0][0];
      expect(createUserArgs.password).toBeUndefined();
      expect(createUserArgs.email_confirm).toBe(false);
      // generateLink('invite') is the only credential we ever surface
      // to the buyer.
      expect(supabaseAdminMock.generateLink).toHaveBeenCalledWith({
        type: 'invite',
        email: 'jane@example.com',
      });
    });

    // Audit #3 P1-6 — when Supabase fails after Stripe took the money,
    // the row must flip to conversion_failed_retryable so the
    // reconciliation worker can pick it up. The previous terminal `failed`
    // semantics stranded paid customers without a retry path.
    it('flips checkout to conversion_failed_retryable when Supabase user creation fails', async () => {
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      const checkoutRow = {
        id: 'gc-fail',
        package_id: 'pkg-1',
        package: {
          coach: { id: 'coach-1' },
          coach_id: 'coach-1',
          amount_cents: 29700,
          currency: 'usd',
          billing_type: 'one_time',
          name: 'Pack',
        },
        idempotency_key: IDEMP_KEY,
        guest_email: 'jane@example.com',
        guest_name: 'Jane',
        stripe_payment_intent_id: 'pi_fail',
        stripe_customer_id: null,
        status: 'paid',
        retry_count: 0,
      };
      prisma.guestCheckout.findUnique
        .mockResolvedValueOnce(checkoutRow) // claim-and-read inside handlePaymentSucceeded
        .mockResolvedValueOnce(checkoutRow) // inside convertGuestToUser pre-check
        .mockResolvedValueOnce(checkoutRow); // inside markRetryable retry_count read
      // Supabase admin throws an unrecoverable error.
      supabaseAdminMock.createUser.mockRejectedValueOnce(
        new Error('supabase down'),
      );
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });

      await service.handlePaymentSucceeded('pi_fail');

      // Second updateMany call is markRetryable: paid → conversion_failed_retryable
      const markRetryableCall = prisma.guestCheckout.updateMany.mock.calls[1];
      expect(markRetryableCall[0].where).toEqual({
        id: 'gc-fail',
        status: { in: ['paid', 'conversion_failed_retryable'] },
      });
      expect(markRetryableCall[0].data.status).toBe('conversion_failed_retryable');
      expect(markRetryableCall[0].data.retry_count).toBe(1);
      expect(typeof markRetryableCall[0].data.last_error).toBe('string');
      expect(markRetryableCall[0].data.last_error).toMatch(/^supabase:/);
    });

    // Audit #3 P1-6 — after RECONCILIATION_MAX_ATTEMPTS (5) attempts the
    // row moves to conversion_failed_terminal and pages on-call. Tests
    // that the fifth attempt flips to terminal, not retryable.
    it('flips to conversion_failed_terminal after the retry cap', async () => {
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      const checkoutRow = {
        id: 'gc-term',
        package_id: 'pkg-1',
        package: {
          coach: { id: 'coach-1' },
          coach_id: 'coach-1',
          amount_cents: 29700,
          currency: 'usd',
          billing_type: 'one_time',
          name: 'Pack',
        },
        idempotency_key: IDEMP_KEY,
        guest_email: 'jane@example.com',
        guest_name: 'Jane',
        stripe_payment_intent_id: 'pi_term',
        stripe_customer_id: null,
        status: 'paid',
        retry_count: 4, // one more failure pushes past the cap
      };
      prisma.guestCheckout.findUnique
        .mockResolvedValueOnce(checkoutRow)
        .mockResolvedValueOnce(checkoutRow)
        .mockResolvedValueOnce(checkoutRow); // markRetryable retry_count read
      supabaseAdminMock.createUser.mockRejectedValueOnce(
        new Error('supabase down'),
      );
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });

      await service.handlePaymentSucceeded('pi_term');

      const markTerminalCall = prisma.guestCheckout.updateMany.mock.calls[1];
      expect(markTerminalCall[0].data.status).toBe('conversion_failed_terminal');
      expect(markTerminalCall[0].data.retry_count).toBe(5);
    });

    // P1-5 — listUsers must page beyond the first 200 users to find an
    // existing account, otherwise paid customers on page 2+ are stranded.
    it('finds existing Supabase user on page 2 when listUsers paginates', async () => {
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      const checkoutRow = {
        id: 'gc-page2',
        package_id: 'pkg-1',
        package: {
          coach: { id: 'coach-1' },
          coach_id: 'coach-1',
          amount_cents: 29700,
          currency: 'usd',
          billing_type: 'one_time',
          name: 'Pack',
        },
        idempotency_key: IDEMP_KEY,
        guest_email: 'jane@example.com',
        guest_name: 'Jane',
        stripe_payment_intent_id: 'pi_p2',
        stripe_customer_id: null,
        status: 'paid',
      };
      prisma.guestCheckout.findUnique
        .mockResolvedValueOnce(checkoutRow)
        .mockResolvedValueOnce(checkoutRow);
      // createUser returns "already registered" — triggers listUsers
      // lookup of the existing account.
      supabaseAdminMock.createUser.mockResolvedValueOnce({
        data: null,
        error: { message: 'User already registered' },
      });
      // Page 1 — full page of non-matching users (forces pagination).
      const page1Users = Array.from({ length: 200 }).map((_, i) => ({
        id: `sb-${i}`,
        email: `other-${i}@example.com`,
      }));
      // Page 2 — contains the matching user.
      const page2Users = [
        { id: 'sb-other', email: 'someone@example.com' },
        { id: 'sb-match', email: 'jane@example.com' },
      ];
      supabaseAdminMock.listUsers
        .mockResolvedValueOnce({ data: { users: page1Users } })
        .mockResolvedValueOnce({ data: { users: page2Users } });
      prisma.user.findUnique.mockResolvedValueOnce(null);
      // r48 #12 — atomic upsert path.
      prisma.user.upsert.mockResolvedValueOnce({
        id: 'usr-2',
        coach_id: 'coach-1',
      });
      prisma.clientPurchase.findFirst.mockResolvedValueOnce(null);
      prisma.clientPurchase.create.mockResolvedValueOnce({ id: 'cp-2' });
      prisma.guestCheckout.update.mockResolvedValueOnce({});

      await service.handlePaymentSucceeded('pi_p2');

      // listUsers called twice (page 1 and page 2).
      expect(supabaseAdminMock.listUsers).toHaveBeenCalledTimes(2);
      expect(supabaseAdminMock.listUsers.mock.calls[0][0].page).toBe(1);
      expect(supabaseAdminMock.listUsers.mock.calls[1][0].page).toBe(2);
      // User row created against the matched existing Supabase id.
      // r48 #12 — upsert.where carries the supabase_id, not the create payload.
      expect(prisma.user.upsert.mock.calls[0][0].where.supabase_id).toBe(
        'sb-match',
      );
    });

    it('never throws (webhook contract) on a Prisma failure', async () => {
      prisma.guestCheckout.updateMany.mockRejectedValueOnce(
        new Error('connection lost'),
      );
      await expect(
        service.handlePaymentSucceeded('pi_xyz'),
      ).resolves.toBeUndefined();
    });
  });

  // A276-P0-2 — Stripe-hosted receipt URL is the canonical buyer-facing
  // receipt in this PR (replaces the broken local:// PDF path). The
  // welcome email must surface a pay.stripe.com link and the
  // GuestCheckout row must persist the same URL so admin tools and
  // support resends can use it. The 2% TGP application fee path must
  // remain undisturbed.
  describe('handlePaymentSucceeded — Stripe receipt_url (A276-P0-2)', () => {
    function paidCheckoutRow(overrides: Record<string, unknown> = {}) {
      return {
        id: 'gc-r',
        package_id: 'pkg-1',
        package: {
          coach: { id: 'coach-1' },
          coach_id: 'coach-1',
          amount_cents: 29700,
          currency: 'usd',
          billing_type: 'one_time',
          name: 'Pack',
        },
        idempotency_key: IDEMP_KEY,
        guest_email: 'jane@example.com',
        guest_name: 'Jane',
        stripe_payment_intent_id: 'pi_r',
        stripe_customer_id: null,
        status: 'paid',
        ...overrides,
      };
    }

    it('persists the Stripe-hosted receipt_url on the GuestCheckout row when the event payload carries it', async () => {
      // Initial pending→paid claim succeeds.
      prisma.guestCheckout.updateMany
        .mockResolvedValueOnce({ count: 1 }) // claim
        .mockResolvedValueOnce({ count: 1 }); // receipt_url persist
      const row = paidCheckoutRow();
      prisma.guestCheckout.findUnique
        .mockResolvedValueOnce(row) // post-claim read
        .mockResolvedValueOnce(row); // convertGuestToUser re-read
      supabaseAdminMock.createUser.mockResolvedValueOnce({
        data: { user: { id: 'sb-r' } },
        error: null,
      });
      prisma.connectAccount.findUnique.mockResolvedValueOnce({
        stripe_account_id: 'acct_dest',
      });
      prisma.user.upsert.mockResolvedValueOnce({ id: 'usr-r', coach_id: 'coach-1' });
      prisma.clientPurchase.findFirst.mockResolvedValueOnce(null);
      prisma.clientPurchase.create.mockResolvedValueOnce({ id: 'cp-r' });
      prisma.guestCheckout.update.mockResolvedValueOnce({ id: 'gc-r' });

      await service.handlePaymentSucceeded('pi_r', {
        chargeId: 'ch_abc',
        receiptUrl: 'https://pay.stripe.com/receipts/payment/CAcaFwoVYWNjdF9-test',
      });

      // Second updateMany call is the receipt_url persist.
      const persistCall = prisma.guestCheckout.updateMany.mock.calls[1];
      expect(persistCall[0]).toMatchObject({
        where: {
          stripe_payment_intent_id: 'pi_r',
          receipt_url: null,
        },
        data: {
          receipt_url: 'https://pay.stripe.com/receipts/payment/CAcaFwoVYWNjdF9-test',
        },
      });
      // No extra Stripe round-trip when the event already carried the URL.
      expect(stripe.retrieveCharge).not.toHaveBeenCalled();
      expect(stripe.retrievePaymentIntent).not.toHaveBeenCalled();
    });

    it('falls back to stripe.retrieveCharge when the event payload only carries chargeId', async () => {
      prisma.guestCheckout.updateMany
        .mockResolvedValueOnce({ count: 1 })
        .mockResolvedValueOnce({ count: 1 });
      const row = paidCheckoutRow();
      prisma.guestCheckout.findUnique
        .mockResolvedValueOnce(row)
        .mockResolvedValueOnce(row);
      stripe.retrieveCharge.mockResolvedValueOnce({
        id: 'ch_abc',
        receipt_url: 'https://pay.stripe.com/receipts/payment/abc',
      });
      supabaseAdminMock.createUser.mockResolvedValueOnce({
        data: { user: { id: 'sb-r2' } },
        error: null,
      });
      prisma.connectAccount.findUnique.mockResolvedValueOnce({
        stripe_account_id: 'acct_dest',
      });
      prisma.user.upsert.mockResolvedValueOnce({ id: 'usr-r2', coach_id: 'coach-1' });
      prisma.clientPurchase.findFirst.mockResolvedValueOnce(null);
      prisma.clientPurchase.create.mockResolvedValueOnce({ id: 'cp-r2' });
      prisma.guestCheckout.update.mockResolvedValueOnce({});

      await service.handlePaymentSucceeded('pi_r', {
        chargeId: 'ch_abc',
        receiptUrl: null,
      });

      expect(stripe.retrieveCharge).toHaveBeenCalledWith('ch_abc');
      const persistCall = prisma.guestCheckout.updateMany.mock.calls[1];
      expect(persistCall[0].data.receipt_url).toBe(
        'https://pay.stripe.com/receipts/payment/abc',
      );
    });

    it('rejects non-https receipt URLs (no local:// or javascript: leaks)', async () => {
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      const row = paidCheckoutRow();
      prisma.guestCheckout.findUnique
        .mockResolvedValueOnce(row)
        .mockResolvedValueOnce(row);
      stripe.retrieveCharge.mockResolvedValueOnce({
        id: 'ch_bad',
        receipt_url: 'javascript:alert(1)',
      });
      supabaseAdminMock.createUser.mockResolvedValueOnce({
        data: { user: { id: 'sb-r3' } },
        error: null,
      });
      prisma.connectAccount.findUnique.mockResolvedValueOnce({
        stripe_account_id: 'acct_dest',
      });
      prisma.user.upsert.mockResolvedValueOnce({ id: 'usr-r3', coach_id: 'coach-1' });
      prisma.clientPurchase.findFirst.mockResolvedValueOnce(null);
      prisma.clientPurchase.create.mockResolvedValueOnce({ id: 'cp-r3' });
      prisma.guestCheckout.update.mockResolvedValueOnce({});

      await service.handlePaymentSucceeded('pi_r', {
        chargeId: 'ch_bad',
        receiptUrl: null,
      });

      // The malicious URL must NOT have been persisted; only the
      // pending→paid claim updateMany ran.
      const persistAttempts = prisma.guestCheckout.updateMany.mock.calls.filter(
        (c: unknown[]) =>
          (c[0] as { data?: { receipt_url?: string } })?.data?.receipt_url !== undefined,
      );
      expect(persistAttempts).toHaveLength(0);
    });

    // A276-F2-P2-1 — degraded-path Stripe blip MUST NOT trigger a second
    // HTTP call inside the outer $transaction. BillingService signals
    // `preResolveAttempted=true` when the outside-tx Stripe lookup ran
    // (success or failure). resolveReceiptUrl honours that flag and
    // returns null immediately instead of calling stripe.retrieveCharge
    // again from inside the tx — the exact anti-pattern P1-3 was meant
    // to eliminate.
    it('A276-F2-P2-1: resolveReceiptUrl skips Stripe HTTP when preResolveAttempted=true and receiptUrl=null', async () => {
      const url = await service.resolveReceiptUrl('pi_blip', {
        chargeId: 'ch_blip',
        receiptUrl: null,
        preResolveAttempted: true,
      });
      expect(url).toBeNull();
      expect(stripe.retrieveCharge).not.toHaveBeenCalled();
      expect(stripe.retrievePaymentIntent).not.toHaveBeenCalled();
    });

    it('A276-F2-P2-1: resolveReceiptUrl still uses pre-resolved https URL when preResolveAttempted=true (happy path)', async () => {
      const url = await service.resolveReceiptUrl('pi_happy', {
        chargeId: 'ch_happy',
        receiptUrl: 'https://pay.stripe.com/receipts/abc',
        preResolveAttempted: true,
      });
      expect(url).toBe('https://pay.stripe.com/receipts/abc');
      expect(stripe.retrieveCharge).not.toHaveBeenCalled();
      expect(stripe.retrievePaymentIntent).not.toHaveBeenCalled();
    });

    it('A276-F2-P2-1: handlePaymentSucceeded with preResolveAttempted=true + null URL does NOT call retrieveCharge', async () => {
      // The degraded path: BillingService already tried, Stripe was
      // down, we proceed with null URL. The inner handler MUST NOT
      // retry Stripe (it would be inside the outer billing tx).
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      const row = paidCheckoutRow();
      prisma.guestCheckout.findUnique
        .mockResolvedValueOnce(row)
        .mockResolvedValueOnce(row);
      supabaseAdminMock.createUser.mockResolvedValueOnce({
        data: { user: { id: 'sb-blip' } },
        error: null,
      });
      prisma.connectAccount.findUnique.mockResolvedValueOnce({
        stripe_account_id: 'acct_dest',
      });
      prisma.user.upsert.mockResolvedValueOnce({
        id: 'usr-blip',
        coach_id: 'coach-1',
      });
      prisma.clientPurchase.findFirst.mockResolvedValueOnce(null);
      prisma.clientPurchase.create.mockResolvedValueOnce({ id: 'cp-blip' });
      prisma.guestCheckout.update.mockResolvedValueOnce({});

      await service.handlePaymentSucceeded('pi_r', {
        chargeId: 'ch_blip',
        receiptUrl: null,
        preResolveAttempted: true,
      });

      // No in-tx Stripe HTTP fired on the degraded path.
      expect(stripe.retrieveCharge).not.toHaveBeenCalled();
      expect(stripe.retrievePaymentIntent).not.toHaveBeenCalled();
      // receipt_url is never persisted (still null).
      const persistAttempts = prisma.guestCheckout.updateMany.mock.calls.filter(
        (c: unknown[]) =>
          (c[0] as { data?: { receipt_url?: string } })?.data?.receipt_url !==
          undefined,
      );
      expect(persistAttempts).toHaveLength(0);
    });

    // Regression — application_fee_amount (2% TGP platform fee plus the
    // Stripe pass-through estimate) is unchanged by the receipt wiring.
    // The PI create path runs at createIntent time; receipt resolution
    // runs at payment_intent.succeeded time and must NOT touch the fee.
    it('does not disturb the 2% application_fee_amount (regression)', async () => {
      prisma.coachPackage.findUnique.mockResolvedValueOnce(makePkg());
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(null);
      prisma.guestCheckout.create.mockResolvedValueOnce({
        id: 'gc-fee',
        idempotency_key: IDEMP_KEY,
      });
      stripe.createPaymentIntent.mockResolvedValueOnce({
        id: 'pi_fee',
        client_secret: 's',
      });
      prisma.guestCheckout.update.mockResolvedValueOnce({});
      await service.createIntent('tok123', baseDto);
      // Same fee as the canonical PI-create test — 1485¢ for $297 package.
      expect(
        stripe.createPaymentIntent.mock.calls[0][0].applicationFeeAmount,
      ).toBe(1485);
    });
  });

  describe('handlePaymentFailed', () => {
    it('transitions a pending row to failed', async () => {
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      await service.handlePaymentFailed('pi_failed');
      expect(prisma.guestCheckout.updateMany).toHaveBeenCalledWith({
        where: { stripe_payment_intent_id: 'pi_failed', status: 'pending' },
        data: { status: 'failed' },
      });
    });

    it('swallows errors so the webhook returns 200', async () => {
      prisma.guestCheckout.updateMany.mockRejectedValueOnce(
        new Error('db down'),
      );
      await expect(
        service.handlePaymentFailed('pi_x'),
      ).resolves.toBeUndefined();
    });
  });

  // A276-P1-4 — refund must revoke entitlement on a full refund and
  // notify the selling coach. A partial refund stamps refunded_at but
  // leaves entitlement_active alone. A dispute notifies the coach at
  // high priority but MUST NOT revoke entitlement (it can be won).
  describe('handleChargeRefunded (A276-P1-4)', () => {
    function refundedGuestRow(overrides: Record<string, unknown> = {}) {
      return {
        id: 'gc-ref-1',
        stripe_payment_intent_id: 'pi_ref',
        status: 'paid',
        refunded_at: null,
        package: { coach_id: 'coach-1' },
        ...overrides,
      };
    }

    it('full refund: revokes ClientPurchase entitlement, stamps GuestCheckout, notifies coach', async () => {
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(refundedGuestRow());
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      prisma.clientPurchase.updateMany.mockResolvedValueOnce({ count: 1 });

      const result = await service.handleChargeRefunded('pi_ref', 29700, 29700);

      expect(result).toEqual({ claimed: true });
      // GuestCheckout flipped to 'refunded' with refunded_at stamped.
      const gcCall = prisma.guestCheckout.updateMany.mock.calls[0];
      expect(gcCall[0]).toMatchObject({
        where: { stripe_payment_intent_id: 'pi_ref', refunded_at: null },
        data: { status: 'refunded' },
      });
      expect(gcCall[0].data.refunded_at).toBeInstanceOf(Date);
      // ClientPurchase entitlement revoked.
      expect(prisma.clientPurchase.updateMany).toHaveBeenCalledWith({
        where: {
          stripe_payment_intent_id: 'pi_ref',
          entitlement_active: true,
        },
        data: { entitlement_active: false, status: 'refunded' },
      });
      // Both writes ran inside one transaction.
      expect(prisma.$transaction).toHaveBeenCalledTimes(1);
      // Coach was notified.
      expect(notifications.createNotification).toHaveBeenCalledTimes(1);
      const notif = notifications.createNotification.mock.calls[0][0];
      expect(notif).toMatchObject({
        user_id: 'coach-1',
        kind: 'coach_alert',
        channel: 'inapp',
      });
      expect(notif.body).toContain('$297.00');
      expect(notif.payload).toMatchObject({
        event: 'refund_processed',
        fully_refunded: true,
        entitlement_revoked: true,
        payment_intent_id: 'pi_ref',
      });
    });

    it('partial refund: stamps GuestCheckout but does NOT revoke entitlement', async () => {
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(refundedGuestRow());
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });

      // 100 of 29700 refunded — partial.
      const result = await service.handleChargeRefunded('pi_ref', 29700, 100);

      expect(result).toEqual({ claimed: true });
      // ClientPurchase entitlement-revoke updateMany must NOT have fired.
      expect(prisma.clientPurchase.updateMany).not.toHaveBeenCalled();
      // Coach is still notified, but with fully_refunded:false.
      expect(notifications.createNotification).toHaveBeenCalledTimes(1);
      const notif = notifications.createNotification.mock.calls[0][0];
      expect(notif.body).toContain('Partial refund');
      expect(notif.body).toContain('$1.00');
      expect(notif.payload).toMatchObject({
        fully_refunded: false,
        entitlement_revoked: false,
      });
    });

    it('idempotent on re-delivery: second call no-ops the entitlement revoke', async () => {
      // First delivery flipped both rows.
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(
        refundedGuestRow({ status: 'refunded', refunded_at: new Date() }),
      );
      // updateMany WHERE refunded_at:null catches nothing.
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 0 });
      // ClientPurchase WHERE entitlement_active:true also catches nothing.
      prisma.clientPurchase.updateMany.mockResolvedValueOnce({ count: 0 });

      const result = await service.handleChargeRefunded('pi_ref', 29700, 29700);

      // Still claimed (the row exists), but no notification fired since
      // nothing actually changed in this delivery.
      expect(result).toEqual({ claimed: true });
      expect(notifications.createNotification).not.toHaveBeenCalled();
    });

    it('returns claimed:false when no GuestCheckout AND no ClientPurchase matches', async () => {
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(null);
      prisma.clientPurchase.updateMany.mockResolvedValueOnce({ count: 0 });

      const result = await service.handleChargeRefunded('pi_unknown', 1000, 1000);

      expect(result).toEqual({ claimed: false });
      expect(notifications.createNotification).not.toHaveBeenCalled();
    });

    it('notification failure does not roll back the refund write', async () => {
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(refundedGuestRow());
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      prisma.clientPurchase.updateMany.mockResolvedValueOnce({ count: 1 });
      notifications.createNotification.mockRejectedValueOnce(
        new Error('expo down'),
      );

      const result = await service.handleChargeRefunded('pi_ref', 29700, 29700);

      expect(result).toEqual({ claimed: true });
      // The refund + entitlement-revoke writes still ran.
      expect(prisma.guestCheckout.updateMany).toHaveBeenCalledTimes(1);
      expect(prisma.clientPurchase.updateMany).toHaveBeenCalledTimes(1);
    });

    // A276-P1-2 (refix) — Stripe delivers charge.refunded once per
    // refund. A partial-then-full sequence is two distinct events; the
    // first stamps refunded_at on GuestCheckout but leaves status='paid'
    // (or 'converted'), and on the second delivery the original
    // updateMany WHERE refunded_at:null guard would skip GuestCheckout
    // entirely, leaving its status desynced from ClientPurchase.status=
    // 'refunded'. The fix issues a second updateMany when the first
    // claims zero and the cumulative amount is fully refunded.
    it('partial-then-full: second delivery upgrades GuestCheckout.status to refunded even though refunded_at was set on the first', async () => {
      // Second delivery: refunded_at already stamped from a prior
      // partial refund, so the row.status is still 'paid' and
      // refunded_at is non-null.
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(
        refundedGuestRow({ status: 'paid', refunded_at: new Date() }),
      );
      // First updateMany (WHERE refunded_at:null) claims zero.
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 0 });
      // Second updateMany (the partial→full upgrade) claims one.
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      // ClientPurchase entitlement-revoke claims one (this is the
      // delivery that completes the full refund).
      prisma.clientPurchase.updateMany.mockResolvedValueOnce({ count: 1 });

      const result = await service.handleChargeRefunded('pi_ref', 29700, 29700);

      expect(result).toEqual({ claimed: true });
      // Both updateMany calls fired.
      expect(prisma.guestCheckout.updateMany).toHaveBeenCalledTimes(2);
      // First call: original stamp guard.
      expect(prisma.guestCheckout.updateMany.mock.calls[0][0]).toMatchObject({
        where: { stripe_payment_intent_id: 'pi_ref', refunded_at: null },
        data: { status: 'refunded' },
      });
      // Second call: the partial→full status upgrade. MUST guard on
      // status != 'refunded' so a third re-delivery is a no-op, and
      // MUST NOT re-stamp refunded_at (preserves original timestamp).
      const upgradeCall = prisma.guestCheckout.updateMany.mock.calls[1][0];
      expect(upgradeCall).toMatchObject({
        where: {
          stripe_payment_intent_id: 'pi_ref',
          status: { not: 'refunded' },
        },
        data: { status: 'refunded' },
      });
      expect(upgradeCall.data.refunded_at).toBeUndefined();
      // ClientPurchase entitlement was revoked.
      expect(prisma.clientPurchase.updateMany).toHaveBeenCalledTimes(1);
      // Coach was notified — the partial→full transition is exactly
      // the moment a coach needs to know entitlement just flipped.
      expect(notifications.createNotification).toHaveBeenCalledTimes(1);
      const notif = notifications.createNotification.mock.calls[0][0];
      expect(notif.payload).toMatchObject({
        fully_refunded: true,
        entitlement_revoked: true,
      });
    });

    // A276-P1-2 (refix) — third re-delivery after a partial→full
    // completion must be a no-op in both branches.
    it('partial-then-full: third re-delivery (status already refunded) is a no-op and does not re-notify', async () => {
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(
        refundedGuestRow({ status: 'refunded', refunded_at: new Date() }),
      );
      // WHERE refunded_at:null guard catches nothing.
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 0 });
      // WHERE status:{not:'refunded'} also catches nothing.
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 0 });
      prisma.clientPurchase.updateMany.mockResolvedValueOnce({ count: 0 });

      const result = await service.handleChargeRefunded('pi_ref', 29700, 29700);

      expect(result).toEqual({ claimed: true });
      expect(notifications.createNotification).not.toHaveBeenCalled();
    });

    // A276-P1-2 (refix) — also covers the converted-guest case where
    // the row's status is 'converted' (post-conversion partial refund
    // through the guest-checkout webhook fallback path).
    it('partial-then-full on converted row: upgrades converted→refunded on the closing delivery', async () => {
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(
        refundedGuestRow({ status: 'converted', refunded_at: new Date() }),
      );
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 0 });
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      prisma.clientPurchase.updateMany.mockResolvedValueOnce({ count: 1 });

      const result = await service.handleChargeRefunded('pi_ref', 29700, 29700);

      expect(result).toEqual({ claimed: true });
      expect(prisma.guestCheckout.updateMany.mock.calls[1][0]).toMatchObject({
        where: {
          stripe_payment_intent_id: 'pi_ref',
          status: { not: 'refunded' },
        },
        data: { status: 'refunded' },
      });
    });
  });

  describe('handleDisputeOpened (A276-P1-4)', () => {
    function disputedRow(overrides: Record<string, unknown> = {}) {
      return {
        id: 'gc-disp-1',
        stripe_payment_intent_id: 'pi_disp',
        status: 'paid',
        disputed_at: null,
        package: { coach_id: 'coach-1' },
        ...overrides,
      };
    }

    it('stamps disputed_at + dispute_reason, notifies coach, does NOT revoke entitlement', async () => {
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 1 });
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(disputedRow());

      const result = await service.handleDisputeOpened(
        'pi_disp',
        'fraudulent',
      );

      expect(result).toEqual({ claimed: true });
      const call = prisma.guestCheckout.updateMany.mock.calls[0];
      expect(call[0]).toMatchObject({
        where: { stripe_payment_intent_id: 'pi_disp', disputed_at: null },
        data: { status: 'disputed', dispute_reason: 'fraudulent' },
      });
      // CRITICAL — dispute MUST NOT revoke entitlement.
      expect(prisma.clientPurchase.updateMany).not.toHaveBeenCalled();
      // Coach notified.
      expect(notifications.createNotification).toHaveBeenCalledTimes(1);
      const notif = notifications.createNotification.mock.calls[0][0];
      expect(notif).toMatchObject({
        user_id: 'coach-1',
        kind: 'coach_alert',
      });
      expect(notif.body).toContain('Chargeback');
      expect(notif.payload).toMatchObject({
        event: 'dispute_opened',
        payment_intent_id: 'pi_disp',
        reason: 'fraudulent',
      });
    });

    it('idempotent on re-delivery: no second notification', async () => {
      // Row already stamped on prior delivery — updateMany no-ops.
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 0 });
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(
        disputedRow({ disputed_at: new Date(), status: 'disputed' }),
      );

      const result = await service.handleDisputeOpened('pi_disp', 'fraudulent');

      expect(result).toEqual({ claimed: true });
      expect(notifications.createNotification).not.toHaveBeenCalled();
    });

    it('claims:false when PaymentIntent is unknown to GuestCheckout', async () => {
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 0 });
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(null);

      const result = await service.handleDisputeOpened('pi_unknown', 'fraudulent');

      expect(result).toEqual({ claimed: false });
      expect(notifications.createNotification).not.toHaveBeenCalled();
    });
  });

  // A276-P1-5 — BillingService.handleEvent wraps every webhook dispatch
  // in a Prisma \$transaction whose final write is
  // StripeProcessedEvent.handler_completed_at.  If the refund / dispute
  // handlers swallow errors and return { claimed: false }, the dedup row
  // commits, Stripe ack's the delivery, and the refund row stays stuck
  // in 'paid' forever.  These tests pin the new behaviour: a Prisma /
  // notifier-internal error during the writes MUST re-throw so the
  // outer transaction rolls back and Stripe retries.
  //
  // A legitimate soft no-op (PI unknown to either table) is NOT an error
  // — it returns { claimed: false } cleanly so other handlers can take
  // the event.
  describe('handler error propagation (A276-P1-5 / Fix 7)', () => {
    it('handleChargeRefunded re-throws when the $transaction errors (Stripe retry)', async () => {
      prisma.guestCheckout.findUnique.mockResolvedValueOnce({
        id: 'gc-x',
        stripe_payment_intent_id: 'pi_boom',
        status: 'paid',
        refunded_at: null,
        package: { coach_id: 'coach-1' },
      });
      // Simulate a transient DB error inside the transaction.
      prisma.$transaction.mockImplementationOnce(() => {
        throw new Error('db connection lost');
      });

      await expect(
        service.handleChargeRefunded('pi_boom', 1000, 1000),
      ).rejects.toThrow('db connection lost');
      // Coach must NOT have been notified for a failed write — the
      // transaction rolled back, the refund state didn't change.
      expect(notifications.createNotification).not.toHaveBeenCalled();
    });

    it('handleDisputeOpened re-throws when the $transaction errors (Stripe retry)', async () => {
      prisma.$transaction.mockImplementationOnce(() => {
        throw new Error('db connection lost');
      });

      await expect(
        service.handleDisputeOpened('pi_boom', 'fraudulent'),
      ).rejects.toThrow('db connection lost');
      expect(notifications.createNotification).not.toHaveBeenCalled();
    });

    // Soft no-op stays soft: PI unknown is NOT a retryable error.
    it('handleChargeRefunded returns claimed:false (no throw) for unknown PI', async () => {
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(null);
      prisma.clientPurchase.updateMany.mockResolvedValueOnce({ count: 0 });
      await expect(
        service.handleChargeRefunded('pi_never_seen', 1000, 1000),
      ).resolves.toEqual({ claimed: false });
    });

    it('handleDisputeOpened returns claimed:false (no throw) for unknown PI', async () => {
      prisma.guestCheckout.updateMany.mockResolvedValueOnce({ count: 0 });
      prisma.guestCheckout.findUnique.mockResolvedValueOnce(null);
      await expect(
        service.handleDisputeOpened('pi_never_seen', 'fraudulent'),
      ).resolves.toEqual({ claimed: false });
    });
  });
});
