# House rules — growth-project-backend

This file is the canonical doctrine for code, copy, and commit
discipline on this repository. Every PR must comply.

It is owned by Bradley Gleave and updated as the rules evolve.
Last revised: 2026-05-10 (Team Mode v1 audit — added HTTP status semantics).

## Code discipline

- Strict TypeScript posture. No `any`. No `@ts-ignore` and no
  `@ts-expect-error` without an inline justification comment that
  names the constraint and the planned fix.
- Lint must pass. `no-empty` is `error` with `allowEmptyCatch: false` —
  every `catch` must either rethrow, log, or annotate.
- Every PR carries an updated README section or a standalone RFC
  document. The PR body alone does not satisfy the rule.

## Copy discipline

- No emoji. Anywhere. Includes commit messages, PR bodies, code
  comments, log lines, error strings, and user-facing copy.
- No exclamation points. Anywhere. Same scope as the emoji rule.
- No marketing superlatives in user-facing copy. Plain English.
  "Approximately 11x" is fine; "incredible 11x" is not.

## Forbidden token list

The following tokens are forbidden in source code, comments, copy
strings, DB enum values, and DTOs. Any occurrence in a PR is a
review blocker.

- `Income` (the word, not domain terms like `debt_to_income` or
  `savings / income` which are accepted finance terminology — the
  rule is meant to catch marketing copy like "manage your income"
  rather than well-named ratio fields)
- `netWorth`
- `confetti`
- `trophy`
- `revolutionary`
- `gamechang*` (any inflection — `gamechanger`, `gamechanging`)

The forbidden list is doctrine, not currently enforced by ESLint.
Adding a `no-restricted-syntax` rule is a separate decision: today
the rule is enforced by code review and by this document.

### Carve-outs and exceptions

The following tokens are explicitly permitted because they name
load-bearing parts of the product domain:

- `finance` — TGP is a multi-pillar product spanning fitness,
  finance, and business coaching. The federation surface
  (`/federation/insights/finance-summary`), the cross-pillar
  insights envelope (`status: 'finance_unavailable'`), and the
  user-facing copy ("connect your finance account to unlock
  cross-pillar insights") all reference this pillar by name.
  Banning the token would force renames on every cross-pillar
  surface and produce worse copy. The token stays.

The carve-out applies repository-wide. There is no need to escape
`finance` in tests, controllers, services, types, or docs.

## Brand

- Oxblood `#4A0404` is the brand accent. Backend repo rarely needs
  it; when it does (e.g. PDF stylesheet for a coach report), use
  the exact hex literal once and reuse via constant.

## Migrations

- Additive only. No `DROP TABLE` / `DROP COLUMN` / data-destructive
  `ALTER COLUMN` against tables with rows in production.
- Migration directory names are `YYYYMMDDHHMMSS_short_slug`. Do
  not reuse a timestamp prefix that already exists on `main` —
  Prisma keys on the full directory name, but two migrations
  sharing a numeric prefix make `_prisma_migrations` listings hard
  to read and break tooling that sorts by prefix alone.
- Every new table gets indexes that match its read patterns. FK
  cascade behavior is `CASCADE` for owned children (e.g. plan
  exercises) and `RESTRICT` where archive-not-delete is the
  expected lifecycle (e.g. meal templates referenced by daily
  plans).
- Reversibility is documented at the bottom of each migration as
  a `DROP TABLE … CASCADE;` block in reverse order.

## Auth and tenancy

- `JwtAuthGuard` is global via `APP_GUARD`. Public routes use the
  `@Public()` decorator.
- `CoachGuard` is per-route. Every route under a coach surface
  (`/coach/...`, `/workout-plans`, `/coach/clients/:id/...`) must
  carry `@UseGuards(JwtAuthGuard, CoachGuard)`. Tenancy
  (coach-can-only-touch-their-own-clients) is enforced inside the
  service, but the role boundary is enforced by the guard.
- Tenancy guards in services use the 404-not-403 convention: a
  cross-tenant lookup returns `NotFoundException`, not
  `ForbiddenException`, so the existence of a row owned by
  another tenant is not leaked.

## Testing

- Jest config: `roots: ['<rootDir>/test']`. Colocated specs in
  `src/**/*.spec.ts` are NOT picked up by `npm test` today. New
  tests go in `test/`. (This is a known wrinkle; fix is
  out-of-scope for Sprint B.)
- Each new controller class ships with at least one guard test
  and at least one happy-path test. Tenancy edge cases are
  covered when the service is non-trivial.

## Agentic commit messages and PR bodies

Claude Code, Cursor, and similar coding agents emit a default
trailer on commits and PR bodies that looks like one of:

```
Generated with Claude Code  (with a robot emoji prefix)
Co-Authored-By: Claude <noreply@anthropic.com>
```

Both forms are forbidden on this repository. The emoji breaks the
no-emoji rule. The `Co-Authored-By: Claude` line is misleading
attribution on a commit Bradley owns and reviews; the agent is a
tool, not a co-author. There is no `.gitmessage`, husky hook, or
`.claude/` config in this repository that adds these — they come
from the agent's own default behaviour and must be suppressed at
the agent layer.

Agents working on this repo MUST:

- Strip every robot emoji and any `Generated with [Claude Code]`
  block from commit messages BEFORE running `git commit`.
- Strip every `Co-Authored-By: Claude` (and variants:
  `Co-authored-by: Claude Code`, `Claude Agent`, `Claude Opus`,
  etc.) line from commit messages BEFORE running `git commit`.
- Strip the same trailer from PR bodies BEFORE running
  `gh pr create` or `gh pr edit --body`.
- Pass commit messages via a HEREDOC literal that does not include
  the trailer, rather than relying on the agent's default
  template.

If a PR slips through with the trailer, fix it before merge with
either:

- `gh pr edit <num> --body "<clean body>"` — works for the PR body
  but the in-repo commits still carry the trailer until they are
  squash-merged. Use squash-merge to keep main clean.
- For a non-squash merge path: rewrite the offending commits with
  `git rebase -i` and force-push (only when no one else has the
  branch checked out).

Squash-merge is the default merge mode on this repo specifically
because it lets a clean PR body subject become the main commit
message regardless of branch commit hygiene. Use it.

## HTTP status semantics

Pick the status code based on what is actually wrong, not what feels
"protective". Mobile clients route on status code first and envelope
second; conflating them sends users to the wrong screen.

- **400 BadRequest** — the request body or query string is malformed
  (e.g. unknown enum value, missing required field after DTO bypass,
  out-of-range integer). The fix is on the caller: change the
  request shape.
- **401 Unauthorized** — no valid authentication token. The caller
  needs to log in.
- **403 Forbidden** — authenticated, but the role or tier or
  ownership boundary forbids this action. The fix is account-side:
  upgrade tier, request access, or be added to the team. Mobile
  clients show an upsell or "ask your coach" screen.
- **404 NotFound** — the resource does not exist OR is owned by a
  different tenant. Return 404 (not 403) when leaking existence
  itself would breach tenancy.
- **409 Conflict** — the request would violate a stable invariant
  (e.g. cap exceeded, idempotency key collision, optimistic-lock
  failure). The fix is to check current state and try again.
- **422 UnprocessableEntity** — the request is well-formed but the
  business rule rejects it (rarely needed in NestJS — class-validator
  failures emit 400 by default; keep it that way unless you have a
  specific reason).
- **429 TooManyRequests** — throttler. Set automatically by
  `@Throttle`; do not throw manually.
- **5xx** — never thrown by service code on a known failure path.
  Reserve for unhandled exceptions.

Concrete examples from this repo:

- `event_kind=not_a_real_kind` on `GET /team/audit-events` -> 400 with
  `{ kind: 'invalid_event_kind', allowed: [...] }`. NOT 403.
- Growth coach calling `POST /team/sub-coaches` -> 403 with
  `{ kind: 'team_mode_locked', current_tier: 'growth', required_tier: 'pro', upsell_url: '/pricing' }`.
- Pro coach trying to assign a 3rd head coach to a sub-coach already
  capped at 2 -> 409 with
  `{ kind: 'sub_coach_head_cap_exceeded', cap: 2, message: '...' }`.
- Coach A's subscription rows are not visible to Coach B -> 404, not
  403, when Coach B asks for them by id.
